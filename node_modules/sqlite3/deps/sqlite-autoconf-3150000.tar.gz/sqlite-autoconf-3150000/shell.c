/*
** 2001 September 15
**
** The author disclaims copyright to this source code.  In place of
** a legal notice, here is a blessing:
**
**    May you do good and not evil.
**    May you find forgiveness for yourself and forgive others.
**    May you share freely, never taking more than you give.
**
*************************************************************************
** This file contains code to implement the "sqlite" command line
** utility for accessing SQLite databases.
*/
#if (defined(_WIN32) || defined(WIN32)) && !defined(_CRT_SECURE_NO_WARNINGS)
/* This needs to come before any includes for MSVC compiler */
#define _CRT_SECURE_NO_WARNINGS
#endif

/*
** If requested, include the SQLite compiler options file for MSVC.
*/
#if defined(INCLUDE_MSVC_H)
#include "msvc.h"
#endif

/*
** No support for loadable extensions in VxWorks.
*/
#if (defined(__RTP__) || defined(_WRS_KERNEL)) && !SQLITE_OMIT_LOAD_EXTENSION
# define SQLITE_OMIT_LOAD_EXTENSION 1
#endif

/*
** Enable large-file support for fopen() and friends on unix.
*/
#ifndef SQLITE_DISABLE_LFS
# define _LARGE_FILE       1
# ifndef _FILE_OFFSET_BITS
#   define _FILE_OFFSET_BITS 64
# endif
# define _LARGEFILE_SOURCE 1
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "sqlite3.h"
#if SQLITE_USER_AUTHENTICATION
# include "sqlite3userauth.h"
#endif
#include <ctype.h>
#include <stdarg.h>

#if !defined(_WIN32) && !defined(WIN32)
# include <signal.h>
# if !defined(__RTP__) && !defined(_WRS_KERNEL)
#  include <pwd.h>
# endif
# include <unistd.h>
# include <sys/types.h>
#endif

#if HAVE_READLINE
# include <readline/readline.h>
# include <readline/history.h>
#endif

#if HAVE_EDITLINE
# include <editline/readline.h>
#endif

#if HAVE_EDITLINE || HAVE_READLINE

# define shell_add_history(X) add_history(X)
# define shell_read_history(X) read_history(X)
# define shell_write_history(X) write_history(X)
# define shell_stifle_history(X) stifle_history(X)
# define shell_readline(X) readline(X)

#elif HAVE_LINENOISE

# include "linenoise.h"
# define shell_add_history(X) linenoiseHistoryAdd(X)
# define shell_read_history(X) linenoiseHistoryLoad(X)
# define shell_write_history(X) linenoiseHistorySave(X)
# define shell_stifle_history(X) linenoiseHistorySetMaxLen(X)
# define shell_readline(X) linenoise(X)

#else

# define shell_read_history(X)
# define shell_write_history(X)
# define shell_stifle_history(X)

# define SHELL_USE_LOCAL_GETLINE 1
#endif


#if defined(_WIN32) || defined(WIN32)
# include <io.h>
# include <fcntl.h>
# define isatty(h) _isatty(h)
# ifndef access
#  define access(f,m) _access((f),(m))
# endif
# undef popen
# define popen _popen
# undef pclose
# define pclose _pclose
#else
 /* Make sure isatty() has a prototype. */
 extern int isatty(int);

# if !defined(__RTP__) && !defined(_WRS_KERNEL)
  /* popen and pclose are not C89 functions and so are
  ** sometimes omitted from the <stdio.h> header */
   extern FILE *popen(const char*,const char*);
   extern int pclose(FILE*);
# else
#  define SQLITE_OMIT_POPEN 1
# endif
#endif

#if defined(_WIN32_WCE)
/* Windows CE (arm-wince-mingw32ce-gcc) does not provide isatty()
 * thus we always assume that we have a console. That can be
 * overridden with the -batch command line option.
 */
#define isatty(x) 1
#endif

/* ctype macros that work with signed characters */
#define IsSpace(X)  isspace((unsigned char)X)
#define IsDigit(X)  isdigit((unsigned char)X)
#define ToLower(X)  (char)tolower((unsigned char)X)

#if defined(_WIN32) || defined(WIN32)
#include <windows.h>

/* string conversion routines only needed on Win32 */
extern char *sqlite3_win32_unicode_to_utf8(LPCWSTR);
extern char *sqlite3_win32_mbcs_to_utf8_v2(const char *, int);
extern char *sqlite3_win32_utf8_to_mbcs_v2(const char *, int);
extern LPWSTR sqlite3_win32_utf8_to_unicode(const char *zText);
#endif

/* On Windows, we normally run with output mode of TEXT so that \n characters
** are automatically translated into \r\n.  However, this behavior needs
** to be disabled in some cases (ex: when generating CSV output and when
** rendering quoted strings that contain \n characters).  The following
** routines take care of that.
*/
#if defined(_WIN32) || defined(WIN32)
static void setBinaryMode(FILE *file, int isOutput){
  if( isOutput ) fflush(file);
  _setmode(_fileno(file), _O_BINARY);
}
static void setTextMode(FILE *file, int isOutput){
  if( isOutput ) fflush(file);
  _setmode(_fileno(file), _O_TEXT);
}
#else
# define setBinaryMode(X,Y)
# define setTextMode(X,Y)
#endif


/* True if the timer is enabled */
static int enableTimer = 0;

/* Return the current wall-clock time */
static sqlite3_int64 timeOfDay(void){
  static sqlite3_vfs *clockVfs = 0;
  sqlite3_int64 t;
  if( clockVfs==0 ) clockVfs = sqlite3_vfs_find(0);
  if( clockVfs->iVersion>=2 && clockVfs->xCurrentTimeInt64!=0 ){
    clockVfs->xCurrentTimeInt64(clockVfs, &t);
  }else{
    double r;
    clockVfs->xCurrentTime(clockVfs, &r);
    t = (sqlite3_int64)(r*86400000.0);
  }
  return t;
}

#if !defined(_WIN32) && !defined(WIN32) && !defined(__minux)
#include <sys/time.h>
#include <sys/resource.h>

/* VxWorks does not support getrusage() as far as we can determine */
#if defined(_WRS_KERNEL) || defined(__RTP__)
struct rusage {
  struct timeval ru_utime; /* user CPU time used */
  struct timeval ru_stime; /* system CPU time used */
};
#define getrusage(A,B) memset(B,0,sizeof(*B))
#endif

/* Saved resource information for the beginning of an operation */
static struct rusage sBegin;  /* CPU time at start */
static sqlite3_int64 iBegin;  /* Wall-clock time at start */

/*
** Begin timing an operation
*/
static void beginTimer(void){
  if( enableTimer ){
    getrusage(RUSAGE_SELF, &sBegin);
    iBegin = timeOfDay();
  }
}

/* Return the difference of two time_structs in seconds */
static double timeDiff(struct timeval *pStart, struct timeval *pEnd){
  return (pEnd->tv_usec - pStart->tv_usec)*0.000001 +
         (double)(pEnd->tv_sec - pStart->tv_sec);
}

/*
** Print the timing results.
*/
static void endTimer(void){
  if( enableTimer ){
    sqlite3_int64 iEnd = timeOfDay();
    struct rusage sEnd;
    getrusage(RUSAGE_SELF, &sEnd);
    printf("Run Time: real %.3f user %f sys %f\n",
       (iEnd - iBegin)*0.001,
       timeDiff(&sBegin.ru_utime, &sEnd.ru_utime),
       timeDiff(&sBegin.ru_stime, &sEnd.ru_stime));
  }
}

#define BEGIN_TIMER beginTimer()
#define END_TIMER endTimer()
#define HAS_TIMER 1

#elif (defined(_WIN32) || defined(WIN32))

/* Saved resource information for the beginning of an operation */
static HANDLE hProcess;
static FILETIME ftKernelBegin;
static FILETIME ftUserBegin;
static sqlite3_int64 ftWallBegin;
typedef BOOL (WINAPI *GETPROCTIMES)(HANDLE, LPFILETIME, LPFILETIME,
                                    LPFILETIME, LPFILETIME);
static GETPROCTIMES getProcessTimesAddr = NULL;

/*
** Check to see if we have timer support.  Return 1 if necessary
** support found (or found previously).
*/
static int hasTimer(void){
  if( getProcessTimesAddr ){
    return 1;
  } else {
    /* GetProcessTimes() isn't supported in WIN95 and some other Windows
    ** versions. See if the version we are running on has it, and if it
    ** does, save off a pointer to it and the current process handle.
    */
    hProcess = GetCurrentProcess();
    if( hProcess ){
      HINSTANCE hinstLib = LoadLibrary(TEXT("Kernel32.dll"));
      if( NULL != hinstLib ){
        getProcessTimesAddr =
            (GETPROCTIMES) GetProcAddress(hinstLib, "GetProcessTimes");
        if( NULL != getProcessTimesAddr ){
          return 1;
        }
        FreeLibrary(hinstLib);
      }
    }
  }
  return 0;
}

/*
** Begin timing an operation
*/
static void beginTimer(void){
  if( enableTimer && getProcessTimesAddr ){
    FILETIME ftCreation, ftExit;
    getProcessTimesAddr(hProcess,&ftCreation,&ftExit,
                        &ftKernelBegin,&ftUserBegin);
    ftWallBegin = timeOfDay();
  }
}

/* Return the difference of two FILETIME structs in seconds */
static double timeDiff(FILETIME *pStart, FILETIME *pEnd){
  sqlite_int64 i64Start = *((sqlite_int64 *) pStart);
  sqlite_int64 i64End = *((sqlite_int64 *) pEnd);
  return (double) ((i64End - i64Start) / 10000000.0);
}

/*
** Print the timing results.
*/
static void endTimer(void){
  if( enableTimer && getProcessTimesAddr){
    FILETIME ftCreation, ftExit, ftKernelEnd, ftUserEnd;
    sqlite3_int64 ftWallEnd = timeOfDay();
    getProcessTimesAddr(hProcess,&ftCreation,&ftExit,&ftKernelEnd,&ftUserEnd);
    printf("Run Time: real %.3f user %f sys %f\n",
       (ftWallEnd - ftWallBegin)*0.001,
       timeDiff(&ftUserBegin, &ftUserEnd),
       timeDiff(&ftKernelBegin, &ftKernelEnd));
  }
}

#define BEGIN_TIMER beginTimer()
#define END_TIMER endTimer()
#define HAS_TIMER hasTimer()

#else
#define BEGIN_TIMER
#define END_TIMER
#define HAS_TIMER 0
#endif

/*
** Used to prevent warnings about unused parameters
*/
#define UNUSED_PARAMETER(x) (void)(x)

/*
** If the following flag is set, then command execution stops
** at an error if we are not interactive.
*/
static int bail_on_error = 0;

/*
** Threat stdin as an interactive input if the following variable
** is true.  Otherwise, assume stdin is connected to a file or pipe.
*/
static int stdin_is_interactive = 1;

/*
** On Windows systems we have to know if standard output is a console
** in order to translate UTF-8 into MBCS.  The following variable is
** true if translation is required.
*/
static int stdout_is_console = 1;

/*
** The following is the open SQLite database.  We make a pointer
** to this database a static variable so that it can be accessed
** by the SIGINT handler to interrupt database processing.
*/
static sqlite3 *globalDb = 0;

/*
** True if an interrupt (Control-C) has been received.
*/
static volatile int seenInterrupt = 0;

/*
** This is the name of our program. It is set in main(), used
** in a number of other places, mostly for error messages.
*/
static char *Argv0;

/*
** Prompt strings. Initialized in main. Settable with
**   .prompt main continue
*/
static char mainPrompt[20];     /* First line prompt. default: "sqlite> "*/
static char continuePrompt[20]; /* Continuation prompt. default: "   ...> " */

/*
** Render output like fprintf().  Except, if the output is going to the
** console and if this is running on a Windows machine, translate the
** output from UTF-8 into MBCS.
*/
#if defined(_WIN32) || defined(WIN32)
void utf8_printf(FILE *out, const char *zFormat, ...){
  va_list ap;
  va_start(ap, zFormat);
  if( stdout_is_console && (out==stdout || out==stderr) ){
    char *z1 = sqlite3_vmprintf(zFormat, ap);
    char *z2 = sqlite3_win32_utf8_to_mbcs_v2(z1, 0);
    sqlite3_free(z1);
    fputs(z2, out);
    sqlite3_free(z2);
  }else{
    vfprintf(out, zFormat, ap);
  }
  va_end(ap);
}
#elif !defined(utf8_printf)
# define utf8_printf fprintf
#endif

/*
** Render output like fprintf().  This should not be used on anything that
** includes string formatting (e.g. "%s").
*/
#if !defined(raw_printf)
# define raw_printf fprintf
#endif

/*
** Write I/O traces to the following stream.
*/
#ifdef SQLITE_ENABLE_IOTRACE
static FILE *iotrace = 0;
#endif

/*
** This routine works like printf in that its first argument is a
** format string and subsequent arguments are values to be substituted
** in place of % fields.  The result of formatting this string
** is written to iotrace.
*/
#ifdef SQLITE_ENABLE_IOTRACE
static void SQLITE_CDECL iotracePrintf(const char *zFormat, ...){
  va_list ap;
  char *z;
  if( iotrace==0 ) return;
  va_start(ap, zFormat);
  z = sqlite3_vmprintf(zFormat, ap);
  va_end(ap);
  utf8_printf(iotrace, "%s", z);
  sqlite3_free(z);
}
#endif


/*
** Determines if a string is a number of not.
*/
static int isNumber(const char *z, int *realnum){
  if( *z=='-' || *z=='+' ) z++;
  if( !IsDigit(*z) ){
    return 0;
  }
  z++;
  if( realnum ) *realnum = 0;
  while( IsDigit(*z) ){ z++; }
  if( *z=='.' ){
    z++;
    if( !IsDigit(*z) ) return 0;
    while( IsDigit(*z) ){ z++; }
    if( realnum ) *realnum = 1;
  }
  if( *z=='e' || *z=='E' ){
    z++;
    if( *z=='+' || *z=='-' ) z++;
    if( !IsDigit(*z) ) return 0;
    while( IsDigit(*z) ){ z++; }
    if( realnum ) *realnum = 1;
  }
  return *z==0;
}

/*
** A global char* and an SQL function to access its current value
** from within an SQL statement. This program used to use the
** sqlite_exec_printf() API to substitue a string into an SQL statement.
** The correct way to do this with sqlite3 is to use the bind API, but
** since the shell is built around the callback paradigm it would be a lot
** of work. Instead just use this hack, which is quite harmless.
*/
static const char *zShellStatic = 0;
static void shellstaticFunc(
  sqlite3_context *context,
  int argc,
  sqlite3_value **argv
){
  assert( 0==argc );
  assert( zShellStatic );
  UNUSED_PARAMETER(argc);
  UNUSED_PARAMETER(argv);
  sqlite3_result_text(context, zShellStatic, -1, SQLITE_STATIC);
}


/*
** Compute a string length that is limited to what can be stored in
** lower 30 bits of a 32-bit signed integer.
*/
static int strlen30(const char *z){
  const char *z2 = z;
  while( *z2 ){ z2++; }
  return 0x3fffffff & (int)(z2 - z);
}

/*
** This routine reads a line of text from FILE in, stores
** the text in memory obtained from malloc() and returns a pointer
** to the text.  NULL is returned at end of file, or if malloc()
** fails.
**
** If zLine is not NULL then it is a malloced buffer returned from
** a previous call to this routine that may be reused.
*/
static char *local_getline(char *zLine, FILE *in){
  int nLine = zLine==0 ? 0 : 100;
  int n = 0;

  while( 1 ){
    if( n+100>nLine ){
      nLine = nLine*2 + 100;
      zLine = realloc(zLine, nLine);
      if( zLine==0 ) return 0;
    }
    if( fgets(&zLine[n], nLine - n, in)==0 ){
      if( n==0 ){
        free(zLine);
        return 0;
      }
      zLine[n] = 0;
      break;
    }
    while( zLine[n] ) n++;
    if( n>0 && zLine[n-1]=='\n' ){
      n--;
      if( n>0 && zLine[n-1]=='\r' ) n--;
      zLine[n] = 0;
      break;
    }
  }
#if defined(_WIN32) || defined(WIN32)
  /* For interactive input on Windows systems, translate the
  ** multi-byte characterset characters into UTF-8. */
  if( stdin_is_interactive && in==stdin ){
    char *zTrans = sqlite3_win32_mbcs_to_utf8_v2(zLine, 0);
    if( zTrans ){
      int nTrans = strlen30(zTrans)+1;
      if( nTrans>nLine ){
        zLine = realloc(zLine, nTrans);
        if( zLine==0 ){
          sqlite3_free(zTrans);
          return 0;
        }
      }
      memcpy(zLine, zTrans, nTrans);
      sqlite3_free(zTrans);
    }
  }
#endif /* defined(_WIN32) || defined(WIN32) */
  return zLine;
}

/*
** Retrieve a single line of input text.
**
** If in==0 then read from standard input and prompt before each line.
** If isContinuation is true, then a continuation prompt is appropriate.
** If isContinuation is zero, then the main prompt should be used.
**
** If zPrior is not NULL then it is a buffer from a prior call to this
** routine that can be reused.
**
** The result is stored in space obtained from malloc() and must either
** be freed by the caller or else passed back into this routine via the
** zPrior argument for reuse.
*/
static char *one_input_line(FILE *in, char *zPrior, int isContinuation){
  char *zPrompt;
  char *zResult;
  if( in!=0 ){
    zResult = local_getline(zPrior, in);
  }else{
    zPrompt = isContinuation ? continuePrompt : mainPrompt;
#if SHELL_USE_LOCAL_GETLINE
    printf("%s", zPrompt);
    fflush(stdout);
    zResult = local_getline(zPrior, stdin);
#else
    free(zPrior);
    zResult = shell_readline(zPrompt);
    if( zResult && *zResult ) shell_add_history(zResult);
#endif
  }
  return zResult;
}

#if defined(SQLITE_ENABLE_SESSION)
/*
** State information for a single open session
*/
typedef struct OpenSession OpenSession;
struct OpenSession {
  char *zName;             /* Symbolic name for this session */
  int nFilter;             /* Number of xFilter rejection GLOB patterns */
  char **azFilter;         /* Array of xFilter rejection GLOB patterns */
  sqlite3_session *p;      /* The open session */
};
#endif

/*
** Shell output mode information from before ".explain on",
** saved so that it can be restored by ".explain off"
*/
typedef struct SavedModeInfo SavedModeInfo;
struct SavedModeInfo {
  int valid;          /* Is there legit data in here? */
  int mode;           /* Mode prior to ".explain on" */
  int showHeader;     /* The ".header" setting prior to ".explain on" */
  int colWidth[100];  /* Column widths prior to ".explain on" */
};

/*
** State information about the database connection is contained in an
** instance of the following structure.
*/
typedef struct ShellState ShellState;
struct ShellState {
  sqlite3 *db;           /* The database */
  int echoOn;            /* True to echo input commands */
  int autoExplain;       /* Automatically turn on .explain mode */
  int autoEQP;           /* Run EXPLAIN QUERY PLAN prior to seach SQL stmt */
  int statsOn;           /* True to display memory stats before each finalize */
  int scanstatsOn;       /* True to display scan stats before each finalize */
  int countChanges;      /* True to display change counts */
  int backslashOn;       /* Resolve C-style \x escapes in SQL input text */
  int outCount;          /* Revert to stdout when reaching zero */
  int cnt;               /* Number of records displayed so far */
  FILE *out;             /* Write results here */
  FILE *traceOut;        /* Output for sqlite3_trace() */
  int nErr;              /* Number of errors seen */
  int mode;              /* An output mode setting */
  int cMode;             /* temporary output mode for the current query */
  int normalMode;        /* Output mode before ".explain on" */
  int writableSchema;    /* True if PRAGMA writable_schema=ON */
  int showHeader;        /* True to show column names in List or Column mode */
  int nCheck;            /* Number of ".check" commands run */
  unsigned shellFlgs;    /* Various flags */
  char *zDestTable;      /* Name of destination table when MODE_Insert */
  char zTestcase[30];    /* Name of current test case */
  char colSeparator[20]; /* Column separator character for several modes */
  char rowSeparator[20]; /* Row separator character for MODE_Ascii */
  int colWidth[100];     /* Requested width of each column when in column mode*/
  int actualWidth[100];  /* Actual width of each column */
  char nullValue[20];    /* The text to print when a NULL comes back from
                         ** the database */
  char outfile[FILENAME_MAX]; /* Filename for *out */
  const char *zDbFilename;    /* name of the database file */
  char *zFreeOnClose;         /* Filename to free when closing */
  const char *zVfs;           /* Name of VFS to use */
  sqlite3_stmt *pStmt;   /* Current statement if any. */
  FILE *pLog;            /* Write log output here */
  int *aiIndent;         /* Array of indents used in MODE_Explain */
  int nIndent;           /* Size of array aiIndent[] */
  int iIndent;           /* Index of current op in aiIndent[] */
#if defined(SQLITE_ENABLE_SESSION)
  int nSession;             /* Number of active sessions */
  OpenSession aSession[4];  /* Array of sessions.  [0] is in focus. */
#endif
};

/*
** These are the allowed shellFlgs values
*/
#define SHFLG_Scratch     0x00001     /* The --scratch option is used */
#define SHFLG_Pagecache   0x00002     /* The --pagecache option is used */
#define SHFLG_Lookaside   0x00004     /* Lookaside memory is used */

/*
** These are the allowed modes.
*/
#define MODE_Line     0  /* One column per line.  Blank line between records */
#define MODE_Column   1  /* One record per line in neat columns */
#define MODE_List     2  /* One record per line with a separator */
#define MODE_Semi     3  /* Same as MODE_List but append ";" to each line */
#define MODE_Html     4  /* Generate an XHTML table */
#define MODE_Insert   5  /* Generate SQL "insert" statements */
#define MODE_Tcl      6  /* Generate ANSI-C or TCL quoted elements */
#define MODE_Csv      7  /* Quote strings, numbers are plain */
#define MODE_Explain  8  /* Like MODE_Column, but do not truncate data */
#define MODE_Ascii    9  /* Use ASCII unit and record separators (0x1F/0x1E) */
#define MODE_Pretty  10  /* Pretty-print schemas */

static const char *modeDescr[] = {
  "line",
  "column",
  "list",
  "semi",
  "html",
  "insert",
  "tcl",
  "csv",
  "explain",
  "ascii",
  "prettyprint",
};

/*
** These are the column/row/line separators used by the various
** import/export modes.
*/
#define SEP_Column    "|"
#define SEP_Row       "\n"
#define SEP_Tab       "\t"
#define SEP_Space     " "
#define SEP_Comma     ","
#define SEP_CrLf      "\r\n"
#define SEP_Unit      "\x1F"
#define SEP_Record    "\x1E"

/*
** Number of elements in an array
*/
#define ArraySize(X)  (int)(sizeof(X)/sizeof(X[0]))

/*
** A callback for the sqlite3_log() interface.
*/
static void shellLog(void *pArg, int iErrCode, const char *zMsg){
  ShellState *p = (ShellState*)pArg;
  if( p->pLog==0 ) return;
  utf8_printf(p->pLog, "(%d) %s\n", iErrCode, zMsg);
  fflush(p->pLog);
}

/*
** Output the given string as a hex-encoded blob (eg. X'1234' )
*/
static void output_hex_blob(FILE *out, const void *pBlob, int nBlob){
  int i;
  char *zBlob = (char *)pBlob;
  raw_printf(out,"X'");
  for(i=0; i<nBlob; i++){ raw_printf(out,"%02x",zBlob[i]&0xff); }
  raw_printf(out,"'");
}

/*
** Output the given string as a quoted string using SQL quoting conventions.
*/
static void output_quoted_string(FILE *out, const char *z){
  int i;
  int nSingle = 0;
  setBinaryMode(out, 1);
  for(i=0; z[i]; i++){
    if( z[i]=='\'' ) nSingle++;
  }
  if( nSingle==0 ){
    utf8_printf(out,"'%s'",z);
  }else{
    raw_printf(out,"'");
    while( *z ){
      for(i=0; z[i] && z[i]!='\''; i++){}
      if( i==0 ){
        raw_printf(out,"''");
        z++;
      }else if( z[i]=='\'' ){
        utf8_printf(out,"%.*s''",i,z);
        z += i+1;
      }else{
        utf8_printf(out,"%s",z);
        break;
      }
    }
    raw_printf(out,"'");
  }
  setTextMode(out, 1);
}

/*
** Output the given string as a quoted according to C or TCL quoting rules.
*/
static void output_c_string(FILE *out, const char *z){
  unsigned int c;
  fputc('"', out);
  while( (c = *(z++))!=0 ){
    if( c=='\\' ){
      fputc(c, out);
      fputc(c, out);
    }else if( c=='"' ){
      fputc('\\', out);
      fputc('"', out);
    }else if( c=='\t' ){
      fputc('\\', out);
      fputc('t', out);
    }else if( c=='\n' ){
      fputc('\\', out);
      fputc('n', out);
    }else if( c=='\r' ){
      fputc('\\', out);
      fputc('r', out);
    }else if( !isprint(c&0xff) ){
      raw_printf(out, "\\%03o", c&0xff);
    }else{
      fputc(c, out);
    }
  }
  fputc('"', out);
}

/*
** Output the given string with characters that are special to
** HTML escaped.
*/
static void output_html_string(FILE *out, const char *z){
  int i;
  if( z==0 ) z = "";
  while( *z ){
    for(i=0;   z[i]
            && z[i]!='<'
            && z[i]!='&'
            && z[i]!='>'
            && z[i]!='\"'
            && z[i]!='\'';
        i++){}
    if( i>0 ){
      utf8_printf(out,"%.*s",i,z);
    }
    if( z[i]=='<' ){
      raw_printf(out,"&lt;");
    }else if( z[i]=='&' ){
      raw_printf(out,"&amp;");
    }else if( z[i]=='>' ){
      raw_printf(out,"&gt;");
    }else if( z[i]=='\"' ){
      raw_printf(out,"&quot;");
    }else if( z[i]=='\'' ){
      raw_printf(out,"&#39;");
    }else{
      break;
    }
    z += i + 1;
  }
}

/*
** If a field contains any character identified by a 1 in the following
** array, then the string must be quoted for CSV.
*/
static const char needCsvQuote[] = {
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,
  1, 0, 1, 0, 0, 0, 0, 1,   0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 1,
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1,   1, 1, 1, 1, 1, 1, 1, 1,
};

/*
** Output a single term of CSV.  Actually, p->colSeparator is used for
** the separator, which may or may not be a comma.  p->nullValue is
** the null value.  Strings are quoted if necessary.  The separator
** is only issued if bSep is true.
*/
static void output_csv(ShellState *p, const char *z, int bSep){
  FILE *out = p->out;
  if( z==0 ){
    utf8_printf(out,"%s",p->nullValue);
  }else{
    int i;
    int nSep = strlen30(p->colSeparator);
    for(i=0; z[i]; i++){
      if( needCsvQuote[((unsigned char*)z)[i]]
         || (z[i]==p->colSeparator[0] &&
             (nSep==1 || memcmp(z, p->colSeparator, nSep)==0)) ){
        i = 0;
        break;
      }
    }
    if( i==0 ){
      putc('"', out);
      for(i=0; z[i]; i++){
        if( z[i]=='"' ) putc('"', out);
        putc(z[i], out);
      }
      putc('"', out);
    }else{
      utf8_printf(out, "%s", z);
    }
  }
  if( bSep ){
    utf8_printf(p->out, "%s", p->colSeparator);
  }
}

#ifdef SIGINT
/*
** This routine runs when the user presses Ctrl-C
*/
static void interrupt_handler(int NotUsed){
  UNUSED_PARAMETER(NotUsed);
  seenInterrupt++;
  if( seenInterrupt>2 ) exit(1);
  if( globalDb ) sqlite3_interrupt(globalDb);
}
#endif

#ifndef SQLITE_OMIT_AUTHORIZATION
/*
** When the ".auth ON" is set, the following authorizer callback is
** invoked.  It always returns SQLITE_OK.
*/
static int shellAuth(
  void *pClientData,
  int op,
  const char *zA1,
  const char *zA2,
  const char *zA3,
  const char *zA4
){
  ShellState *p = (ShellState*)pClientData;
  static const char *azAction[] = { 0,
     "CREATE_INDEX",         "CREATE_TABLE",         "CREATE_TEMP_INDEX",
     "CREATE_TEMP_TABLE",    "CREATE_TEMP_TRIGGER",  "CREATE_TEMP_VIEW",
     "CREATE_TRIGGER",       "CREATE_VIEW",          "DELETE",
     "DROP_INDEX",           "DROP_TABLE",           "DROP_TEMP_INDEX",
     "DROP_TEMP_TABLE",      "DROP_TEMP_TRIGGER",    "DROP_TEMP_VIEW",
     "DROP_TRIGGER",         "DROP_VIEW",            "INSERT",
     "PRAGMA",               "READ",                 "SELECT",
     "TRANSACTION",          "UPDATE",               "ATTACH",
     "DETACH",               "ALTER_TABLE",          "REINDEX",
     "ANALYZE",              "CREATE_VTABLE",        "DROP_VTABLE",
     "FUNCTION",             "SAVEPOINT",            "RECURSIVE"
  };
  int i;
  const char *az[4];
  az[0] = zA1;
  az[1] = zA2;
  az[2] = zA3;
  az[3] = zA4;
  utf8_printf(p->out, "authorizer: %s", azAction[op]);
  for(i=0; i<4; i++){
    raw_printf(p->out, " ");
    if( az[i] ){
      output_c_string(p->out, az[i]);
    }else{
      raw_printf(p->out, "NULL");
    }
  }
  raw_printf(p->out, "\n");
  return SQLITE_OK;
}
#endif


/*
** This is the callback routine that the shell
** invokes for each row of a query result.
*/
static int shell_callback(
  void *pArg,
  int nArg,        /* Number of result columns */
  char **azArg,    /* Text of each result column */
  char **azCol,    /* Column names */
  int *aiType      /* Column types */
){
  int i;
  ShellState *p = (ShellState*)pArg;

  switch( p->cMode ){
    case MODE_Line: {
      int w = 5;
      if( azArg==0 ) break;
      for(i=0; i<nArg; i++){
        int len = strlen30(azCol[i] ? azCol[i] : "");
        if( len>w ) w = len;
      }
      if( p->cnt++>0 ) utf8_printf(p->out, "%s", p->rowSeparator);
      for(i=0; i<nArg; i++){
        utf8_printf(p->out,"%*s = %s%s", w, azCol[i],
                azArg[i] ? azArg[i] : p->nullValue, p->rowSeparator);
      }
      break;
    }
    case MODE_Explain:
    case MODE_Column: {
      static const int aExplainWidths[] = {4, 13, 4, 4, 4, 13, 2, 13};
      const int *colWidth;
      int showHdr;
      char *rowSep;
      if( p->cMode==MODE_Column ){
        colWidth = p->colWidth;
        showHdr = p->showHeader;
        rowSep = p->rowSeparator;
      }else{
        colWidth = aExplainWidths;
        showHdr = 1;
        rowSep = SEP_Row;
      }
      if( p->cnt++==0 ){
        for(i=0; i<nArg; i++){
          int w, n;
          if( i<ArraySize(p->colWidth) ){
            w = colWidth[i];
          }else{
            w = 0;
          }
          if( w==0 ){
            w = strlen30(azCol[i] ? azCol[i] : "");
            if( w<10 ) w = 10;
            n = strlen30(azArg && azArg[i] ? azArg[i] : p->nullValue);
            if( w<n ) w = n;
          }
          if( i<ArraySize(p->actualWidth) ){
            p->actualWidth[i] = w;
          }
          if( showHdr ){
            if( w<0 ){
              utf8_printf(p->out,"%*.*s%s",-w,-w,azCol[i],
                      i==nArg-1 ? rowSep : "  ");
            }else{
              utf8_printf(p->out,"%-*.*s%s",w,w,azCol[i],
                      i==nArg-1 ? rowSep : "  ");
            }
          }
        }
        if( showHdr ){
          for(i=0; i<nArg; i++){
            int w;
            if( i<ArraySize(p->actualWidth) ){
               w = p->actualWidth[i];
               if( w<0 ) w = -w;
            }else{
               w = 10;
            }
            utf8_printf(p->out,"%-*.*s%s",w,w,
                   "----------------------------------------------------------"
                   "----------------------------------------------------------",
                    i==nArg-1 ? rowSep : "  ");
          }
        }
      }
      if( azArg==0 ) break;
      for(i=0; i<nArg; i++){
        int w;
        if( i<ArraySize(p->actualWidth) ){
           w = p->actualWidth[i];
        }else{
           w = 10;
        }
        if( p->cMode==MODE_Explain && azArg[i] && strlen30(azArg[i])>w ){
          w = strlen30(azArg[i]);
        }
        if( i==1 && p->aiIndent && p->pStmt ){
          if( p->iIndent<p->nIndent ){
            utf8_printf(p->out, "%*.s", p->aiIndent[p->iIndent], "");
          }
          p->iIndent++;
        }
        if( w<0 ){
          utf8_printf(p->out,"%*.*s%s",-w,-w,
              azArg[i] ? azArg[i] : p->nullValue,
              i==nArg-1 ? rowSep : "  ");
        }else{
          utf8_printf(p->out,"%-*.*s%s",w,w,
              azArg[i] ? azArg[i] : p->nullValue,
              i==nArg-1 ? rowSep : "  ");
        }
      }
      break;
    }
    case MODE_Semi: {   /* .schema and .fullschema output */
      utf8_printf(p->out, "%s;\n", azArg[0]);
      break;
    }
    case MODE_Pretty: {  /* .schema and .fullschema with --indent */
      char *z;
      int j;
      int nParen = 0;
      char cEnd = 0;
      char c;
      int nLine = 0;
      assert( nArg==1 );
      if( azArg[0]==0 ) break;
      if( sqlite3_strlike("CREATE VIEW%", azArg[0], 0)==0
       || sqlite3_strlike("CREATE TRIG%", azArg[0], 0)==0
      ){
        utf8_printf(p->out, "%s;\n", azArg[0]);
        break;
      }
      z = sqlite3_mprintf("%s", azArg[0]);
      j = 0;
      for(i=0; IsSpace(z[i]); i++){}
      for(; (c = z[i])!=0; i++){
        if( IsSpace(c) ){
          if( IsSpace(z[j-1]) || z[j-1]=='(' ) continue;
        }else if( (c=='(' || c==')') && j>0 && IsSpace(z[j-1]) ){
          j--;
        }
        z[j++] = c;
      }
      while( j>0 && IsSpace(z[j-1]) ){ j--; }
      z[j] = 0;
      if( strlen30(z)>=79 ){
        for(i=j=0; (c = z[i])!=0; i++){
          if( c==cEnd ){
            cEnd = 0;
          }else if( c=='"' || c=='\'' || c=='`' ){
            cEnd = c;
          }else if( c=='[' ){
            cEnd = ']';
          }else if( c=='(' ){
            nParen++;
          }else if( c==')' ){
            nParen--;
            if( nLine>0 && nParen==0 && j>0 ){
              utf8_printf(p->out, "%.*s\n", j, z);
              j = 0;
            }
          }
          z[j++] = c;
          if( nParen==1 && (c=='(' || c==',' || c=='\n') ){
            if( c=='\n' ) j--;
            utf8_printf(p->out, "%.*s\n  ", j, z);
            j = 0;
            nLine++;
            while( IsSpace(z[i+1]) ){ i++; }
          }
        }
        z[j] = 0;
      }
      utf8_printf(p->out, "%s;\n", z);
      sqlite3_free(z);
      break;
    }
    case MODE_List: {
      if( p->cnt++==0 && p->showHeader ){
        for(i=0; i<nArg; i++){
          utf8_printf(p->out,"%s%s",azCol[i],
                  i==nArg-1 ? p->rowSeparator : p->colSeparator);
        }
      }
      if( azArg==0 ) break;
      for(i=0; i<nArg; i++){
        char *z = azArg[i];
        if( z==0 ) z = p->nullValue;
        utf8_printf(p->out, "%s", z);
        if( i<nArg-1 ){
          utf8_printf(p->out, "%s", p->colSeparator);
        }else{
          utf8_printf(p->out, "%s", p->rowSeparator);
        }
      }
      break;
    }
    case MODE_Html: {
      if( p->cnt++==0 && p->showHeader ){
        raw_printf(p->out,"<TR>");
        for(i=0; i<nArg; i++){
          raw_printf(p->out,"<TH>");
          output_html_string(p->out, azCol[i]);
          raw_printf(p->out,"</TH>\n");
        }
        raw_printf(p->out,"</TR>\n");
      }
      if( azArg==0 ) break;
      raw_printf(p->out,"<TR>");
      for(i=0; i<nArg; i++){
        raw_printf(p->out,"<TD>");
        output_html_string(p->out, azArg[i] ? azArg[i] : p->nullValue);
        raw_printf(p->out,"</TD>\n");
      }
      raw_printf(p->out,"</TR>\n");
      break;
    }
    case MODE_Tcl: {
      if( p->cnt++==0 && p->showHeader ){
        for(i=0; i<nArg; i++){
          output_c_string(p->out,azCol[i] ? azCol[i] : "");
          if(i<nArg-1) utf8_printf(p->out, "%s", p->colSeparator);
        }
        utf8_printf(p->out, "%s", p->rowSeparator);
      }
      if( azArg==0 ) break;
      for(i=0; i<nArg; i++){
        output_c_string(p->out, azArg[i] ? azArg[i] : p->nullValue);
        if(i<nArg-1) utf8_printf(p->out, "%s", p->colSeparator);
      }
      utf8_printf(p->out, "%s", p->rowSeparator);
      break;
    }
    case MODE_Csv: {
      setBinaryMode(p->out, 1);
      if( p->cnt++==0 && p->showHeader ){
        for(i=0; i<nArg; i++){
          output_csv(p, azCol[i] ? azCol[i] : "", i<nArg-1);
        }
        utf8_printf(p->out, "%s", p->rowSeparator);
      }
      if( nArg>0 ){
        for(i=0; i<nArg; i++){
          output_csv(p, azArg[i], i<nArg-1);
        }
        utf8_printf(p->out, "%s", p->rowSeparator);
      }
      setTextMode(p->out, 1);
      break;
    }
    case MODE_Insert: {
      p->cnt++;
      if( azArg==0 ) break;
      utf8_printf(p->out,"INSERT INTO %s",p->zDestTable);
      if( p->showHeader ){
        raw_printf(p->out,"(");
        for(i=0; i<nArg; i++){
          char *zSep = i>0 ? ",": "";
          utf8_printf(p->out, "%s%s", zSep, azCol[i]);
        }
        raw_printf(p->out,")");
      }
      raw_printf(p->out," VALUES(");
      for(i=0; i<nArg; i++){
        char *zSep = i>0 ? ",": "";
        if( (azArg[i]==0) || (aiType && aiType[i]==SQLITE_NULL) ){
          utf8_printf(p->out,"%sNULL",zSep);
        }else if( aiType && aiType[i]==SQLITE_TEXT ){
          if( zSep[0] ) utf8_printf(p->out,"%s",zSep);
          output_quoted_string(p->out, azArg[i]);
        }else if( aiType && (aiType[i]==SQLITE_INTEGER
                             || aiType[i]==SQLITE_FLOAT) ){
          utf8_printf(p->out,"%s%s",zSep, azArg[i]);
        }else if( aiType && aiType[i]==SQLITE_BLOB && p->pStmt ){
          const void *pBlob = sqlite3_column_blob(p->pStmt, i);
          int nBlob = sqlite3_column_bytes(p->pStmt, i);
          if( zSep[0] ) utf8_printf(p->out,"%s",zSep);
          output_hex_blob(p->out, pBlob, nBlob);
        }else if( isNumber(azArg[i], 0) ){
          utf8_printf(p->out,"%s%s",zSep, azArg[i]);
        }else{
          if( zSep[0] ) utf8_printf(p->out,"%s",zSep);
          output_quoted_string(p->out, azArg[i]);
        }
      }
      raw_printf(p->out,");\n");
      break;
    }
    case MODE_Ascii: {
      if( p->cnt++==0 && p->showHeader ){
        for(i=0; i<nArg; i++){
          if( i>0 ) utf8_printf(p->out, "%s", p->colSeparator);
          utf8_printf(p->out,"%s",azCol[i] ? azCol[i] : "");
        }
        utf8_printf(p->out, "%s", p->rowSeparator);
      }
      if( azArg==0 ) break;
      for(i=0; i<nArg; i++){
        if( i>0 ) utf8_printf(p->out, "%s", p->colSeparator);
        utf8_printf(p->out,"%s",azArg[i] ? azArg[i] : p->nullValue);
      }
      utf8_printf(p->out, "%s", p->rowSeparator);
      break;
    }
  }
  return 0;
}

/*
** This is the callback routine that the SQLite library
** invokes for each row of a query result.
*/
static int callback(void *pArg, int nArg, char **azArg, char **azCol){
  /* since we don't have type info, call the shell_callback with a NULL value */
  return shell_callback(pArg, nArg, azArg, azCol, NULL);
}

/*
** Set the destination table field of the ShellState structure to
** the name of the table given.  Escape any quote characters in the
** table name.
*/
static void set_table_name(ShellState *p, const char *zName){
  int i, n;
  int needQuote;
  char *z;

  if( p->zDestTable ){
    free(p->zDestTable);
    p->zDestTable = 0;
  }
  if( zName==0 ) return;
  needQuote = !isalpha((unsigned char)*zName) && *zName!='_';
  for(i=n=0; zName[i]; i++, n++){
    if( !isalnum((unsigned char)zName[i]) && zName[i]!='_' ){
      needQuote = 1;
      if( zName[i]=='\'' ) n++;
    }
  }
  if( needQuote ) n += 2;
  z = p->zDestTable = malloc( n+1 );
  if( z==0 ){
    raw_printf(stderr,"Error: out of memory\n");
    exit(1);
  }
  n = 0;
  if( needQuote ) z[n++] = '\'';
  for(i=0; zName[i]; i++){
    z[n++] = zName[i];
    if( zName[i]=='\'' ) z[n++] = '\'';
  }
  if( needQuote ) z[n++] = '\'';
  z[n] = 0;
}

/* zIn is either a pointer to a NULL-terminated string in memory obtained
** from malloc(), or a NULL pointer. The string pointed to by zAppend is
** added to zIn, and the result returned in memory obtained from malloc().
** zIn, if it was not NULL, is freed.
**
** If the third argument, quote, is not '\0', then it is used as a
** quote character for zAppend.
*/
static char *appendText(char *zIn, char const *zAppend, char quote){
  int len;
  int i;
  int nAppend = strlen30(zAppend);
  int nIn = (zIn?strlen30(zIn):0);

  len = nAppend+nIn+1;
  if( quote ){
    len += 2;
    for(i=0; i<nAppend; i++){
      if( zAppend[i]==quote ) len++;
    }
  }

  zIn = (char *)realloc(zIn, len);
  if( !zIn ){
    return 0;
  }

  if( quote ){
    char *zCsr = &zIn[nIn];
    *zCsr++ = quote;
    for(i=0; i<nAppend; i++){
      *zCsr++ = zAppend[i];
      if( zAppend[i]==quote ) *zCsr++ = quote;
    }
    *zCsr++ = quote;
    *zCsr++ = '\0';
    assert( (zCsr-zIn)==len );
  }else{
    memcpy(&zIn[nIn], zAppend, nAppend);
    zIn[len-1] = '\0';
  }

  return zIn;
}


/*
** Execute a query statement that will generate SQL output.  Print
** the result columns, comma-separated, on a line and then add a
** semicolon terminator to the end of that line.
**
** If the number of columns is 1 and that column contains text "--"
** then write the semicolon on a separate line.  That way, if a
** "--" comment occurs at the end of the statement, the comment
** won't consume the semicolon terminator.
*/
static int run_table_dump_query(
  ShellState *p,           /* Query context */
  const char *zSelect,     /* SELECT statement to extract content */
  const char *zFirstRow    /* Print before first row, if not NULL */
){
  sqlite3_stmt *pSelect;
  int rc;
  int nResult;
  int i;
  const char *z;
  rc = sqlite3_prepare_v2(p->db, zSelect, -1, &pSelect, 0);
  if( rc!=SQLITE_OK || !pSelect ){
    utf8_printf(p->out, "/**** ERROR: (%d) %s *****/\n", rc,
                sqlite3_errmsg(p->db));
    if( (rc&0xff)!=SQLITE_CORRUPT ) p->nErr++;
    return rc;
  }
  rc = sqlite3_step(pSelect);
  nResult = sqlite3_column_count(pSelect);
  while( rc==SQLITE_ROW ){
    if( zFirstRow ){
      utf8_printf(p->out, "%s", zFirstRow);
      zFirstRow = 0;
    }
    z = (const char*)sqlite3_column_text(pSelect, 0);
    utf8_printf(p->out, "%s", z);
    for(i=1; i<nResult; i++){
      utf8_printf(p->out, ",%s", sqlite3_column_text(pSelect, i));
    }
    if( z==0 ) z = "";
    while( z[0] && (z[0]!='-' || z[1]!='-') ) z++;
    if( z[0] ){
      raw_printf(p->out, "\n;\n");
    }else{
      raw_printf(p->out, ";\n");
    }
    rc = sqlite3_step(pSelect);
  }
  rc = sqlite3_finalize(pSelect);
  if( rc!=SQLITE_OK ){
    utf8_printf(p->out, "/**** ERROR: (%d) %s *****/\n", rc,
                sqlite3_errmsg(p->db));
    if( (rc&0xff)!=SQLITE_CORRUPT ) p->nErr++;
  }
  return rc;
}

/*
** Allocate space and save off current error string.
*/
static char *save_err_msg(
  sqlite3 *db            /* Database to query */
){
  int nErrMsg = 1+strlen30(sqlite3_errmsg(db));
  char *zErrMsg = sqlite3_malloc64(nErrMsg);
  if( zErrMsg ){
    memcpy(zErrMsg, sqlite3_errmsg(db), nErrMsg);
  }
  return zErrMsg;
}

#ifdef __linux__
/*
** Attempt to display I/O stats on Linux using /proc/PID/io
*/
static void displayLinuxIoStats(FILE *out){
  FILE *in;
  char z[200];
  sqlite3_snprintf(sizeof(z), z, "/proc/%d/io", getpid());
  in = fopen(z, "rb");
  if( in==0 ) return;
  while( fgets(z, sizeof(z), in)!=0 ){
    static const struct {
      const char *zPattern;
      const char *zDesc;
    } aTrans[] = {
      { "rchar: ",                  "Bytes received by read():" },
      { "wchar: ",                  "Bytes sent to write():"    },
      { "syscr: ",                  "Read() system calls:"      },
      { "syscw: ",                  "Write() system calls:"     },
      { "read_bytes: ",             "Bytes read from storage:"  },
      { "write_bytes: ",            "Bytes written to storage:" },
      { "cancelled_write_bytes: ",  "Cancelled write bytes:"    },
    };
    int i;
    for(i=0; i<ArraySize(aTrans); i++){
      int n = (int)strlen(aTrans[i].zPattern);
      if( strncmp(aTrans[i].zPattern, z, n)==0 ){
        utf8_printf(out, "%-36s %s", aTrans[i].zDesc, &z[n]);
        break;
      }
    }
  }
  fclose(in);
}
#endif


/*
** Display memory stats.
*/
static int display_stats(
  sqlite3 *db,                /* Database to query */
  ShellState *pArg,           /* Pointer to ShellState */
  int bReset                  /* True to reset the stats */
){
  int iCur;
  int iHiwtr;

  if( pArg && pArg->out ){

    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_MEMORY_USED, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out,
            "Memory Used:                         %d (max %d) bytes\n",
            iCur, iHiwtr);
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_MALLOC_COUNT, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out, "Number of Outstanding Allocations:   %d (max %d)\n",
            iCur, iHiwtr);
    if( pArg->shellFlgs & SHFLG_Pagecache ){
      iHiwtr = iCur = -1;
      sqlite3_status(SQLITE_STATUS_PAGECACHE_USED, &iCur, &iHiwtr, bReset);
      raw_printf(pArg->out,
              "Number of Pcache Pages Used:         %d (max %d) pages\n",
              iCur, iHiwtr);
    }
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_PAGECACHE_OVERFLOW, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out,
            "Number of Pcache Overflow Bytes:     %d (max %d) bytes\n",
            iCur, iHiwtr);
    if( pArg->shellFlgs & SHFLG_Scratch ){
      iHiwtr = iCur = -1;
      sqlite3_status(SQLITE_STATUS_SCRATCH_USED, &iCur, &iHiwtr, bReset);
      raw_printf(pArg->out,
              "Number of Scratch Allocations Used:  %d (max %d)\n",
              iCur, iHiwtr);
    }
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_SCRATCH_OVERFLOW, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out,
            "Number of Scratch Overflow Bytes:    %d (max %d) bytes\n",
            iCur, iHiwtr);
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_MALLOC_SIZE, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out, "Largest Allocation:                  %d bytes\n",
            iHiwtr);
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_PAGECACHE_SIZE, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out, "Largest Pcache Allocation:           %d bytes\n",
            iHiwtr);
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_SCRATCH_SIZE, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out, "Largest Scratch Allocation:          %d bytes\n",
            iHiwtr);
#ifdef YYTRACKMAXSTACKDEPTH
    iHiwtr = iCur = -1;
    sqlite3_status(SQLITE_STATUS_PARSER_STACK, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out, "Deepest Parser Stack:                %d (max %d)\n",
            iCur, iHiwtr);
#endif
  }

  if( pArg && pArg->out && db ){
    if( pArg->shellFlgs & SHFLG_Lookaside ){
      iHiwtr = iCur = -1;
      sqlite3_db_status(db, SQLITE_DBSTATUS_LOOKASIDE_USED,
                        &iCur, &iHiwtr, bReset);
      raw_printf(pArg->out,
              "Lookaside Slots Used:                %d (max %d)\n",
              iCur, iHiwtr);
      sqlite3_db_status(db, SQLITE_DBSTATUS_LOOKASIDE_HIT,
                        &iCur, &iHiwtr, bReset);
      raw_printf(pArg->out, "Successful lookaside attempts:       %d\n",
              iHiwtr);
      sqlite3_db_status(db, SQLITE_DBSTATUS_LOOKASIDE_MISS_SIZE,
                        &iCur, &iHiwtr, bReset);
      raw_printf(pArg->out, "Lookaside failures due to size:      %d\n",
              iHiwtr);
      sqlite3_db_status(db, SQLITE_DBSTATUS_LOOKASIDE_MISS_FULL,
                        &iCur, &iHiwtr, bReset);
      raw_printf(pArg->out, "Lookaside failures due to OOM:       %d\n",
              iHiwtr);
    }
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_CACHE_USED, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out, "Pager Heap Usage:                    %d bytes\n",
            iCur);
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_CACHE_HIT, &iCur, &iHiwtr, 1);
    raw_printf(pArg->out, "Page cache hits:                     %d\n", iCur);
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_CACHE_MISS, &iCur, &iHiwtr, 1);
    raw_printf(pArg->out, "Page cache misses:                   %d\n", iCur);
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_CACHE_WRITE, &iCur, &iHiwtr, 1);
    raw_printf(pArg->out, "Page cache writes:                   %d\n", iCur);
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_SCHEMA_USED, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out, "Schema Heap Usage:                   %d bytes\n",
            iCur);
    iHiwtr = iCur = -1;
    sqlite3_db_status(db, SQLITE_DBSTATUS_STMT_USED, &iCur, &iHiwtr, bReset);
    raw_printf(pArg->out, "Statement Heap/Lookaside Usage:      %d bytes\n",
            iCur);
  }

  if( pArg && pArg->out && db && pArg->pStmt ){
    iCur = sqlite3_stmt_status(pArg->pStmt, SQLITE_STMTSTATUS_FULLSCAN_STEP,
                               bReset);
    raw_printf(pArg->out, "Fullscan Steps:                      %d\n", iCur);
    iCur = sqlite3_stmt_status(pArg->pStmt, SQLITE_STMTSTATUS_SORT, bReset);
    raw_printf(pArg->out, "Sort Operations:                     %d\n", iCur);
    iCur = sqlite3_stmt_status(pArg->pStmt, SQLITE_STMTSTATUS_AUTOINDEX,bReset);
    raw_printf(pArg->out, "Autoindex Inserts:                   %d\n", iCur);
    iCur = sqlite3_stmt_status(pArg->pStmt, SQLITE_STMTSTATUS_VM_STEP, bReset);
    raw_printf(pArg->out, "Virtual Machine Steps:               %d\n", iCur);
  }

#ifdef __linux__
  displayLinuxIoStats(pArg->out);
#endif

  /* Do not remove this machine readable comment: extra-stats-output-here */

  return 0;
}

/*
** Display scan stats.
*/
static void display_scanstats(
  sqlite3 *db,                    /* Database to query */
  ShellState *pArg                /* Pointer to ShellState */
){
#ifndef SQLITE_ENABLE_STMT_SCANSTATUS
  UNUSED_PARAMETER(db);
  UNUSED_PARAMETER(pArg);
#else
  int i, k, n, mx;
  raw_printf(pArg->out, "-------- scanstats --------\n");
  mx = 0;
  for(k=0; k<=mx; k++){
    double rEstLoop = 1.0;
    for(i=n=0; 1; i++){
      sqlite3_stmt *p = pArg->pStmt;
      sqlite3_int64 nLoop, nVisit;
      double rEst;
      int iSid;
      const char *zExplain;
      if( sqlite3_stmt_scanstatus(p, i, SQLITE_SCANSTAT_NLOOP, (void*)&nLoop) ){
        break;
      }
      sqlite3_stmt_scanstatus(p, i, SQLITE_SCANSTAT_SELECTID, (void*)&iSid);
      if( iSid>mx ) mx = iSid;
      if( iSid!=k ) continue;
      if( n==0 ){
        rEstLoop = (double)nLoop;
        if( k>0 ) raw_printf(pArg->out, "-------- subquery %d -------\n", k);
      }
      n++;
      sqlite3_stmt_scanstatus(p, i, SQLITE_SCANSTAT_NVISIT, (void*)&nVisit);
      sqlite3_stmt_scanstatus(p, i, SQLITE_SCANSTAT_EST, (void*)&rEst);
      sqlite3_stmt_scanstatus(p, i, SQLITE_SCANSTAT_EXPLAIN, (void*)&zExplain);
      utf8_printf(pArg->out, "Loop %2d: %s\n", n, zExplain);
      rEstLoop *= rEst;
      raw_printf(pArg->out,
          "         nLoop=%-8lld nRow=%-8lld estRow=%-8lld estRow/Loop=%-8g\n",
          nLoop, nVisit, (sqlite3_int64)(rEstLoop+0.5), rEst
      );
    }
  }
  raw_printf(pArg->out, "---------------------------\n");
#endif
}

/*
** Parameter azArray points to a zero-terminated array of strings. zStr
** points to a single nul-terminated string. Return non-zero if zStr
** is equal, according to strcmp(), to any of the strings in the array.
** Otherwise, return zero.
*/
static int str_in_array(const char *zStr, const char **azArray){
  int i;
  for(i=0; azArray[i]; i++){
    if( 0==strcmp(zStr, azArray[i]) ) return 1;
  }
  return 0;
}

/*
** If compiled statement pSql appears to be an EXPLAIN statement, allocate
** and populate the ShellState.aiIndent[] array with the number of
** spaces each opcode should be indented before it is output.
**
** The indenting rules are:
**
**     * For each "Next", "Prev", "VNext" or "VPrev" instruction, indent
**       all opcodes that occur between the p2 jump destination and the opcode
**       itself by 2 spaces.
**
**     * For each "Goto", if the jump destination is earlier in the program
**       and ends on one of:
**          Yield  SeekGt  SeekLt  RowSetRead  Rewind
**       or if the P1 parameter is one instead of zero,
**       then indent all opcodes between the earlier instruction
**       and "Goto" by 2 spaces.
*/
static void explain_data_prepare(ShellState *p, sqlite3_stmt *pSql){
  const char *zSql;               /* The text of the SQL statement */
  const char *z;                  /* Used to check if this is an EXPLAIN */
  int *abYield = 0;               /* True if op is an OP_Yield */
  int nAlloc = 0;                 /* Allocated size of p->aiIndent[], abYield */
  int iOp;                        /* Index of operation in p->aiIndent[] */

  const char *azNext[] = { "Next", "Prev", "VPrev", "VNext", "SorterNext",
                           "NextIfOpen", "PrevIfOpen", 0 };
  const char *azYield[] = { "Yield", "SeekLT", "SeekGT", "RowSetRead",
                            "Rewind", 0 };
  const char *azGoto[] = { "Goto", 0 };

  /* Try to figure out if this is really an EXPLAIN statement. If this
  ** cannot be verified, return early.  */
  if( sqlite3_column_count(pSql)!=8 ){
    p->cMode = p->mode;
    return;
  }
  zSql = sqlite3_sql(pSql);
  if( zSql==0 ) return;
  for(z=zSql; *z==' ' || *z=='\t' || *z=='\n' || *z=='\f' || *z=='\r'; z++);
  if( sqlite3_strnicmp(z, "explain", 7) ){
    p->cMode = p->mode;
    return;
  }

  for(iOp=0; SQLITE_ROW==sqlite3_step(pSql); iOp++){
    int i;
    int iAddr = sqlite3_column_int(pSql, 0);
    const char *zOp = (const char*)sqlite3_column_text(pSql, 1);

    /* Set p2 to the P2 field of the current opcode. Then, assuming that
    ** p2 is an instruction address, set variable p2op to the index of that
    ** instruction in the aiIndent[] array. p2 and p2op may be different if
    ** the current instruction is part of a sub-program generated by an
    ** SQL trigger or foreign key.  */
    int p2 = sqlite3_column_int(pSql, 3);
    int p2op = (p2 + (iOp-iAddr));

    /* Grow the p->aiIndent array as required */
    if( iOp>=nAlloc ){
      if( iOp==0 ){
        /* Do further verfication that this is explain output.  Abort if
        ** it is not */
        static const char *explainCols[] = {
           "addr", "opcode", "p1", "p2", "p3", "p4", "p5", "comment" };
        int jj;
        for(jj=0; jj<ArraySize(explainCols); jj++){
          if( strcmp(sqlite3_column_name(pSql,jj),explainCols[jj])!=0 ){
            p->cMode = p->mode;
            sqlite3_reset(pSql);
            return;
          }
        }
      }
      nAlloc += 100;
      p->aiIndent = (int*)sqlite3_realloc64(p->aiIndent, nAlloc*sizeof(int));
      abYield = (int*)sqlite3_realloc64(abYield, nAlloc*sizeof(int));
    }
    abYield[iOp] = str_in_array(zOp, azYield);
    p->aiIndent[iOp] = 0;
    p->nIndent = iOp+1;

    if( str_in_array(zOp, azNext) ){
      for(i=p2op; i<iOp; i++) p->aiIndent[i] += 2;
    }
    if( str_in_array(zOp, azGoto) && p2op<p->nIndent
     && (abYield[p2op] || sqlite3_column_int(pSql, 2))
    ){
      for(i=p2op; i<iOp; i++) p->aiIndent[i] += 2;
    }
  }

  p->iIndent = 0;
  sqlite3_free(abYield);
  sqlite3_reset(pSql);
}

/*
** Free the array allocated by explain_data_prepare().
*/
static void explain_data_delete(ShellState *p){
  sqlite3_free(p->aiIndent);
  p->aiIndent = 0;
  p->nIndent = 0;
  p->iIndent = 0;
}

/*
** Disable and restore .wheretrace and .selecttrace settings.
*/
#if defined(SQLITE_DEBUG) && defined(SQLITE_ENABLE_SELECTTRACE)
extern int sqlite3SelectTrace;
static int savedSelectTrace;
#endif
#if defined(SQLITE_DEBUG) && defined(SQLITE_ENABLE_WHERETRACE)
extern int sqlite3WhereTrace;
static int savedWhereTrace;
#endif
static void disable_debug_trace_modes(void){
#if defined(SQLITE_DEBUG) && defined(SQLITE_ENABLE_SELECTTRACE)
  savedSelectTrace = sqlite3SelectTrace;
  sqlite3SelectTrace = 0;
#endif
#if defined(SQLITE_DEBUG) && defined(SQLITE_ENABLE_WHERETRACE)
  savedWhereTrace = sqlite3WhereTrace;
  sqlite3WhereTrace = 0;
#endif
}
static void restore_debug_trace_modes(void){
#if defined(SQLITE_DEBUG) && defined(SQLITE_ENABLE_SELECTTRACE)
  sqlite3SelectTrace = savedSelectTrace;
#endif
#if defined(SQLITE_DEBUG) && defined(SQLITE_ENABLE_WHERETRACE)
  sqlite3WhereTrace = savedWhereTrace;
#endif
}

/*
** Run a prepared statement
*/
static void exec_prepared_stmt(
  ShellState *pArg,                                /* Pointer to ShellState */
  sqlite3_stmt *pStmt,                             /* Statment to run */
  int (*xCallback)(void*,int,char**,char**,int*)   /* Callback function */
){
  int rc;

  /* perform the first step.  this will tell us if we
  ** have a result set or not and how wide it is.
  */
  rc = sqlite3_step(pStmt);
  /* if we have a result set... */
  if( SQLITE_ROW == rc ){
    /* if we have a callback... */
    if( xCallback ){
      /* allocate space for col name ptr, value ptr, and type */
      int nCol = sqlite3_column_count(pStmt);
      void *pData = sqlite3_malloc64(3*nCol*sizeof(const char*) + 1);
      if( !pData ){
        rc = SQLITE_NOMEM;
      }else{
        char **azCols = (char **)pData;      /* Names of result columns */
        char **azVals = &azCols[nCol];       /* Results */
        int *aiTypes = (int *)&azVals[nCol]; /* Result types */
        int i, x;
        assert(sizeof(int) <= sizeof(char *));
        /* save off ptrs to column names */
        for(i=0; i<nCol; i++){
          azCols[i] = (char *)sqlite3_column_name(pStmt, i);
        }
        do{
          /* extract the data and data types */
          for(i=0; i<nCol; i++){
            aiTypes[i] = x = sqlite3_column_type(pStmt, i);
            if( x==SQLITE_BLOB && pArg && pArg->cMode==MODE_Insert ){
              azVals[i] = "";
            }else{
              azVals[i] = (char*)sqlite3_column_text(pStmt, i);
            }
            if( !azVals[i] && (aiTypes[i]!=SQLITE_NULL) ){
              rc = SQLITE_NOMEM;
              break; /* from for */
            }
          } /* end for */

          /* if data and types extracted successfully... */
          if( SQLITE_ROW == rc ){
            /* call the supplied callback with the result row data */
            if( xCallback(pArg, nCol, azVals, azCols, aiTypes) ){
              rc = SQLITE_ABORT;
            }else{
              rc = sqlite3_step(pStmt);
            }
          }
        } while( SQLITE_ROW == rc );
        sqlite3_free(pData);
      }
    }else{
      do{
        rc = sqlite3_step(pStmt);
      } while( rc == SQLITE_ROW );
    }
  }
}

/*
** Execute a statement or set of statements.  Print
** any result rows/columns depending on the current mode
** set via the supplied callback.
**
** This is very similar to SQLite's built-in sqlite3_exec()
** function except it takes a slightly different callback
** and callback data argument.
*/
static int shell_exec(
  sqlite3 *db,                              /* An open database */
  const char *zSql,                         /* SQL to be evaluated */
  int (*xCallback)(void*,int,char**,char**,int*),   /* Callback function */
                                            /* (not the same as sqlite3_exec) */
  ShellState *pArg,                         /* Pointer to ShellState */
  char **pzErrMsg                           /* Error msg written here */
){
  sqlite3_stmt *pStmt = NULL;     /* Statement to execute. */
  int rc = SQLITE_OK;             /* Return Code */
  int rc2;
  const char *zLeftover;          /* Tail of unprocessed SQL */

  if( pzErrMsg ){
    *pzErrMsg = NULL;
  }

  while( zSql[0] && (SQLITE_OK == rc) ){
    static const char *zStmtSql;
    rc = sqlite3_prepare_v2(db, zSql, -1, &pStmt, &zLeftover);
    if( SQLITE_OK != rc ){
      if( pzErrMsg ){
        *pzErrMsg = save_err_msg(db);
      }
    }else{
      if( !pStmt ){
        /* this happens for a comment or white-space */
        zSql = zLeftover;
        while( IsSpace(zSql[0]) ) zSql++;
        continue;
      }
      zStmtSql = sqlite3_sql(pStmt);
      while( IsSpace(zStmtSql[0]) ) zStmtSql++;

      /* save off the prepared statment handle and reset row count */
      if( pArg ){
        pArg->pStmt = pStmt;
        pArg->cnt = 0;
      }

      /* echo the sql statement if echo on */
      if( pArg && pArg->echoOn ){
        utf8_printf(pArg->out, "%s\n", zStmtSql ? zStmtSql : zSql);
      }

      /* Show the EXPLAIN QUERY PLAN if .eqp is on */
      if( pArg && pArg->autoEQP && sqlite3_strlike("EXPLAIN%",zStmtSql,0)!=0 ){
        sqlite3_stmt *pExplain;
        char *zEQP;
        disable_debug_trace_modes();
        zEQP = sqlite3_mprintf("EXPLAIN QUERY PLAN %s", zStmtSql);
        rc = sqlite3_prepare_v2(db, zEQP, -1, &pExplain, 0);
        if( rc==SQLITE_OK ){
          while( sqlite3_step(pExplain)==SQLITE_ROW ){
            raw_printf(pArg->out,"--EQP-- %d,",sqlite3_column_int(pExplain, 0));
            raw_printf(pArg->out,"%d,", sqlite3_column_int(pExplain, 1));
            raw_printf(pArg->out,"%d,", sqlite3_column_int(pExplain, 2));
            utf8_printf(pArg->out,"%s\n", sqlite3_column_text(pExplain, 3));
          }
        }
        sqlite3_finalize(pExplain);
        sqlite3_free(zEQP);
        if( pArg->autoEQP>=2 ){
          /* Also do an EXPLAIN for ".eqp full" mode */
          zEQP = sqlite3_mprintf("EXPLAIN %s", zStmtSql);
          rc = sqlite3_prepare_v2(db, zEQP, -1, &pExplain, 0);
          if( rc==SQLITE_OK ){
            pArg->cMode = MODE_Explain;
            explain_data_prepare(pArg, pExplain);
            exec_prepared_stmt(pArg, pExplain, xCallback);
            explain_data_delete(pArg);
          }
          sqlite3_finalize(pExplain);
          sqlite3_free(zEQP);
        }
        restore_debug_trace_modes();
      }

      if( pArg ){
        pArg->cMode = pArg->mode;
        if( pArg->autoExplain
         && sqlite3_column_count(pStmt)==8
         && sqlite3_strlike("EXPLAIN%", zStmtSql,0)==0
        ){
          pArg->cMode = MODE_Explain;
        }

        /* If the shell is currently in ".explain" mode, gather the extra
        ** data required to add indents to the output.*/
        if( pArg->cMode==MODE_Explain ){
          explain_data_prepare(pArg, pStmt);
        }
      }

      exec_prepared_stmt(pArg, pStmt, xCallback);
      explain_data_delete(pArg);

      /* print usage stats if stats on */
      if( pArg && pArg->statsOn ){
        display_stats(db, pArg, 0);
      }

      /* print loop-counters if required */
      if( pArg && pArg->scanstatsOn ){
        display_scanstats(db, pArg);
      }

      /* Finalize the statement just executed. If this fails, save a
      ** copy of the error message. Otherwise, set zSql to point to the
      ** next statement to execute. */
      rc2 = sqlite3_finalize(pStmt);
      if( rc!=SQLITE_NOMEM ) rc = rc2;
      if( rc==SQLITE_OK ){
        zSql = zLeftover;
        while( IsSpace(zSql[0]) ) zSql++;
      }else if( pzErrMsg ){
        *pzErrMsg = save_err_msg(db);
      }

      /* clear saved stmt handle */
      if( pArg ){
        pArg->pStmt = NULL;
      }
    }
  } /* end while */

  return rc;
}


/*
** This is a different callback routine used for dumping the database.
** Each row received by this callback consists of a table name,
** the table type ("index" or "table") and SQL to create the table.
** This routine should print text sufficient to recreate the table.
*/
static int dump_callback(void *pArg, int nArg, char **azArg, char **azCol){
  int rc;
  const char *zTable;
  const char *zType;
  const char *zSql;
  const char *zPrepStmt = 0;
  ShellState *p = (ShellState *)pArg;

  UNUSED_PARAMETER(azCol);
  if( nArg!=3 ) return 1;
  zTable = azArg[0];
  zType = azArg[1];
  zSql = azArg[2];

  if( strcmp(zTable, "sqlite_sequence")==0 ){
    zPrepStmt = "DELETE FROM sqlite_sequence;\n";
  }else if( sqlite3_strglob("sqlite_stat?", zTable)==0 ){
    raw_printf(p->out, "ANALYZE sqlite_master;\n");
  }else if( strncmp(zTable, "sqlite_", 7)==0 ){
    return 0;
  }else if( strncmp(zSql, "CREATE VIRTUAL TABLE", 20)==0 ){
    char *zIns;
    if( !p->writableSchema ){
      raw_printf(p->out, "PRAGMA writable_schema=ON;\n");
      p->writableSchema = 1;
    }
    zIns = sqlite3_mprintf(
       "INSERT INTO sqlite_master(type,name,tbl_name,rootpage,sql)"
       "VALUES('table','%q','%q',0,'%q');",
       zTable, zTable, zSql);
    utf8_printf(p->out, "%s\n", zIns);
    sqlite3_free(zIns);
    return 0;
  }else{
    utf8_printf(p->out, "%s;\n", zSql);
  }

  if( strcmp(zType, "table")==0 ){
    sqlite3_stmt *pTableInfo = 0;
    char *zSelect = 0;
    char *zTableInfo = 0;
    char *zTmp = 0;
    int nRow = 0;

    zTableInfo = appendText(zTableInfo, "PRAGMA table_info(", 0);
    zTableInfo = appendText(zTableInfo, zTable, '"');
    zTableInfo = appendText(zTableInfo, ");", 0);

    rc = sqlite3_prepare_v2(p->db, zTableInfo, -1, &pTableInfo, 0);
    free(zTableInfo);
    if( rc!=SQLITE_OK || !pTableInfo ){
      return 1;
    }

    zSelect = appendText(zSelect, "SELECT 'INSERT INTO ' || ", 0);
    /* Always quote the table name, even if it appears to be pure ascii,
    ** in case it is a keyword. Ex:  INSERT INTO "table" ... */
    zTmp = appendText(zTmp, zTable, '"');
    if( zTmp ){
      zSelect = appendText(zSelect, zTmp, '\'');
      free(zTmp);
    }
    zSelect = appendText(zSelect, " || ' VALUES(' || ", 0);
    rc = sqlite3_step(pTableInfo);
    while( rc==SQLITE_ROW ){
      const char *zText = (const char *)sqlite3_column_text(pTableInfo, 1);
      zSelect = appendText(zSelect, "quote(", 0);
      zSelect = appendText(zSelect, zText, '"');
      rc = sqlite3_step(pTableInfo);
      if( rc==SQLITE_ROW ){
        zSelect = appendText(zSelect, "), ", 0);
      }else{
        zSelect = appendText(zSelect, ") ", 0);
      }
      nRow++;
    }
    rc = sqlite3_finalize(pTableInfo);
    if( rc!=SQLITE_OK || nRow==0 ){
      free(zSelect);
      return 1;
    }
    zSelect = appendText(zSelect, "|| ')' FROM  ", 0);
    zSelect = appendText(zSelect, zTable, '"');

    rc = run_table_dump_query(p, zSelect, zPrepStmt);
    if( rc==SQLITE_CORRUPT ){
      zSelect = appendText(zSelect, " ORDER BY rowid DESC", 0);
      run_table_dump_query(p, zSelect, 0);
    }
    free(zSelect);
  }
  return 0;
}

/*
** Run zQuery.  Use dump_callback() as the callback routine so that
** the contents of the query are output as SQL statements.
**
** If we get a SQLITE_CORRUPT error, rerun the query after appending
** "ORDER BY rowid DESC" to the end.
*/
static int run_schema_dump_query(
  ShellState *p,
  const char *zQuery
){
  int rc;
  char *zErr = 0;
  rc = sqlite3_exec(p->db, zQuery, dump_callback, p, &zErr);
  if( rc==SQLITE_CORRUPT ){
    char *zQ2;
    int len = strlen30(zQuery);
    raw_printf(p->out, "/****** CORRUPTION ERROR *******/\n");
    if( zErr ){
      utf8_printf(p->out, "/****** %s ******/\n", zErr);
      sqlite3_free(zErr);
      zErr = 0;
    }
    zQ2 = malloc( len+100 );
    if( zQ2==0 ) return rc;
    sqlite3_snprintf(len+100, zQ2, "%s ORDER BY rowid DESC", zQuery);
    rc = sqlite3_exec(p->db, zQ2, dump_callback, p, &zErr);
    if( rc ){
      utf8_printf(p->out, "/****** ERROR: %s ******/\n", zErr);
    }else{
      rc = SQLITE_CORRUPT;
    }
    sqlite3_free(zErr);
    free(zQ2);
  }
  return rc;
}

/*
** Text of a help message
*/
static char zHelp[] =
#ifndef SQLITE_OMIT_AUTHORIZATION
  ".auth ON|OFF           Show authorizer callbacks\n"
#endif
  ".backup ?DB? FILE      Backup DB (default \"main\") to FILE\n"
  ".bail on|off           Stop after hitting an error.  Default OFF\n"
  ".binary on|off         Turn binary output on or off.  Default OFF\n"
  ".changes on|off        Show number of rows changed by SQL\n"
  ".check GLOB            Fail if output since .testcase does not match\n"
  ".clone NEWDB           Clone data into NEWDB from the existing database\n"
  ".databases             List names and files of attached databases\n"
  ".dbinfo ?DB?           Show status information about the database\n"
  ".dump ?TABLE? ...      Dump the database in an SQL text format\n"
  "                         If TABLE specified, only dump tables matching\n"
  "                         LIKE pattern TABLE.\n"
  ".echo on|off           Turn command echo on or off\n"
  ".eqp on|off|full       Enable or disable automatic EXPLAIN QUERY PLAN\n"
  ".exit                  Exit this program\n"
  ".explain ?on|off|auto? Turn EXPLAIN output mode on or off or to automatic\n"
  ".fullschema ?--indent? Show schema and the content of sqlite_stat tables\n"
  ".headers on|off        Turn display of headers on or off\n"
  ".help                  Show this message\n"
  ".import FILE TABLE     Import data from FILE into TABLE\n"
  ".indexes ?TABLE?       Show names of all indexes\n"
  "                         If TABLE specified, only show indexes for tables\n"
  "                         matching LIKE pattern TABLE.\n"
#ifdef SQLITE_ENABLE_IOTRACE
  ".iotrace FILE          Enable I/O diagnostic logging to FILE\n"
#endif
  ".limit ?LIMIT? ?VAL?   Display or change the value of an SQLITE_LIMIT\n"
#ifndef SQLITE_OMIT_LOAD_EXTENSION
  ".load FILE ?ENTRY?     Load an extension library\n"
#endif
  ".log FILE|off          Turn logging on or off.  FILE can be stderr/stdout\n"
  ".mode MODE ?TABLE?     Set output mode where MODE is one of:\n"
  "                         ascii    Columns/rows delimited by 0x1F and 0x1E\n"
  "                         csv      Comma-separated values\n"
  "                         column   Left-aligned columns.  (See .width)\n"
  "                         html     HTML <table> code\n"
  "                         insert   SQL insert statements for TABLE\n"
  "                         line     One value per line\n"
  "                         list     Values delimited by .separator strings\n"
  "                         tabs     Tab-separated values\n"
  "                         tcl      TCL list elements\n"
  ".nullvalue STRING      Use STRING in place of NULL values\n"
  ".once FILENAME         Output for the next SQL command only to FILENAME\n"
  ".open ?--new? ?FILE?   Close existing database and reopen FILE\n"
  "                         The --new starts with an empty file\n"
  ".output ?FILENAME?     Send output to FILENAME or stdout\n"
  ".print STRING...       Print literal STRING\n"
  ".prompt MAIN CONTINUE  Replace the standard prompts\n"
  ".quit                  Exit this program\n"
  ".read FILENAME         Execute SQL in FILENAME\n"
  ".restore ?DB? FILE     Restore content of DB (default \"main\") from FILE\n"
  ".save FILE             Write in-memory database into FILE\n"
  ".scanstats on|off      Turn sqlite3_stmt_scanstatus() metrics on or off\n"
  ".schema ?PATTERN?      Show the CREATE statements matching PATTERN\n"
  "                          Add --indent for pretty-printing\n"
  ".separator COL ?ROW?   Change the column separator and optionally the row\n"
  "                         separator for both the output mode and .import\n"
#if defined(SQLITE_ENABLE_SESSION)
  ".session CMD ...       Create or control sessions\n"
#endif
  ".shell CMD ARGS...     Run CMD ARGS... in a system shell\n"
  ".show                  Show the current values for various settings\n"
  ".stats ?on|off?        Show stats or turn stats on or off\n"
  ".system CMD ARGS...    Run CMD ARGS... in a system shell\n"
  ".tables ?TABLE?        List names of tables\n"
  "                         If TABLE specified, only list tables matching\n"
  "                         LIKE pattern TABLE.\n"
  ".testcase NAME         Begin redirecting output to 'testcase-out.txt'\n"
  ".timeout MS            Try opening locked tables for MS milliseconds\n"
  ".timer on|off          Turn SQL timer on or off\n"
  ".trace FILE|off        Output each SQL statement as it is run\n"
  ".vfsinfo ?AUX?         Information about the top-level VFS\n"
  ".vfslist               List all available VFSes\n"
  ".vfsname ?AUX?         Print the name of the VFS stack\n"
  ".width NUM1 NUM2 ...   Set column widths for \"column\" mode\n"
  "                         Negative values right-justify\n"
;

#if defined(SQLITE_ENABLE_SESSION)
/*
** Print help information for the ".sessions" command
*/
void session_help(ShellState *p){
  raw_printf(p->out,
    ".session ?NAME? SUBCOMMAND ?ARGS...?\n"
    "If ?NAME? is omitted, the first defined session is used.\n"
    "Subcommands:\n"
    "   attach TABLE             Attach TABLE\n"
    "   changeset FILE           Write a changeset into FILE\n"
    "   close                    Close one session\n"
    "   enable ?BOOLEAN?         Set or query the enable bit\n"
    "   filter GLOB...           Reject tables matching GLOBs\n"
    "   indirect ?BOOLEAN?       Mark or query the indirect status\n"
    "   isempty                  Query whether the session is empty\n"
    "   list                     List currently open session names\n"
    "   open DB NAME             Open a new session on DB\n"
    "   patchset FILE            Write a patchset into FILE\n"
  );
}
#endif


/* Forward reference */
static int process_input(ShellState *p, FILE *in);


/*
** Read the content of a file into memory obtained from sqlite3_malloc64().
** The caller is responsible for freeing the memory.
**
** NULL is returned if any error is encountered.
*/
static char *readFile(const char *zName){
  FILE *in = fopen(zName, "rb");
  long nIn;
  size_t nRead;
  char *pBuf;
  if( in==0 ) return 0;
  fseek(in, 0, SEEK_END);
  nIn = ftell(in);
  rewind(in);
  pBuf = sqlite3_malloc64( nIn+1 );
  if( pBuf==0 ) return 0;
  nRead = fread(pBuf, nIn, 1, in);
  fclose(in);
  if( nRead!=1 ){
    sqlite3_free(pBuf);
    return 0;
  }
  pBuf[nIn] = 0;
  return pBuf;
}

/*
** Implementation of the "readfile(X)" SQL function.  The entire content
** of the file named X is read and returned as a BLOB.  NULL is returned
** if the file does not exist or is unreadable.
*/
static void readfileFunc(
  sqlite3_context *context,
  int argc,
  sqlite3_value **argv
){
  const char *zName;
  void *pBuf;

  UNUSED_PARAMETER(argc);
  zName = (const char*)sqlite3_value_text(argv[0]);
  if( zName==0 ) return;
  pBuf = readFile(zName);
  if( pBuf ) sqlite3_result_blob(context, pBuf, -1, sqlite3_free);
}

/*
** Implementation of the "writefile(X,Y)" SQL function.  The argument Y
** is written into file X.  The number of bytes written is returned.  Or
** NULL is returned if something goes wrong, such as being unable to open
** file X for writing.
*/
static void writefileFunc(
  sqlite3_context *context,
  int argc,
  sqlite3_value **argv
){
  FILE *out;
  const char *z;
  sqlite3_int64 rc;
  const char *zFile;

  UNUSED_PARAMETER(argc);
  zFile = (const char*)sqlite3_value_text(argv[0]);
  if( zFile==0 ) return;
  out = fopen(zFile, "wb");
  if( out==0 ) return;
  z = (const char*)sqlite3_value_blob(argv[1]);
  if( z==0 ){
    rc = 0;
  }else{
    rc = fwrite(z, 1, sqlite3_value_bytes(argv[1]), out);
  }
  fclose(out);
  sqlite3_result_int64(context, rc);
}

#if defined(SQLITE_ENABLE_SESSION)
/*
** Close a single OpenSession object and release all of its associated
** resources.
*/
static void session_close(OpenSession *pSession){
  int i;
  sqlite3session_delete(pSession->p);
  sqlite3_free(pSession->zName);
  for(i=0; i<pSession->nFilter; i++){
    sqlite3_free(pSession->azFilter[i]);
  }
  sqlite3_free(pSession->azFilter);
  memset(pSession, 0, sizeof(OpenSession));
}
#endif

/*
** Close all OpenSession objects and release all associated resources.
*/
#if defined(SQLITE_ENABLE_SESSION)
static void session_close_all(ShellState *p){
  int i;
  for(i=0; i<p->nSession; i++){
    session_close(&p->aSession[i]);
  }
  p->nSession = 0;
}
#else
# define session_close_all(X)
#endif

/*
** Implementation of the xFilter function for an open session.  Omit
** any tables named by ".session filter" but let all other table through.
*/
#if defined(SQLITE_ENABLE_SESSION)
static int session_filter(void *pCtx, const char *zTab){
  OpenSession *pSession = (OpenSession*)pCtx;
  int i;
  for(i=0; i<pSession->nFilter; i++){
    if( sqlite3_strglob(pSession->azFilter[i], zTab)==0 ) return 0;
  }
  return 1;
}
#endif

/*
** Make sure the database is open.  If it is not, then open it.  If
** the database fails to open, print an error message and exit.
*/
static void open_db(ShellState *p, int keepAlive){
  if( p->db==0 ){
    sqlite3_initialize();
    sqlite3_open(p->zDbFilename, &p->db);
    globalDb = p->db;
    if( p->db && sqlite3_errcode(p->db)==SQLITE_OK ){
      sqlite3_create_function(p->db, "shellstatic", 0, SQLITE_UTF8, 0,
          shellstaticFunc, 0, 0);
    }
    if( p->db==0 || SQLITE_OK!=sqlite3_errcode(p->db) ){
      utf8_printf(stderr,"Error: unable to open database \"%s\": %s\n",
          p->zDbFilename, sqlite3_errmsg(p->db));
      if( keepAlive ) return;
      exit(1);
    }
#ifndef SQLITE_OMIT_LOAD_EXTENSION
    sqlite3_enable_load_extension(p->db, 1);
#endif
    sqlite3_create_function(p->db, "readfile", 1, SQLITE_UTF8, 0,
                            readfileFunc, 0, 0);
    sqlite3_create_function(p->db, "writefile", 2, SQLITE_UTF8, 0,
                            writefileFunc, 0, 0);
  }
}

/*
** Do C-language style dequoting.
**
**    \a    -> alarm
**    \b    -> backspace
**    \t    -> tab
**    \n    -> newline
**    \v    -> vertical tab
**    \f    -> form feed
**    \r    -> carriage return
**    \s    -> space
**    \"    -> "
**    \'    -> '
**    \\    -> backslash
**    \NNN  -> ascii character NNN in octal
*/
static void resolve_backslashes(char *z){
  int i, j;
  char c;
  while( *z && *z!='\\' ) z++;
  for(i=j=0; (c = z[i])!=0; i++, j++){
    if( c=='\\' && z[i+1]!=0 ){
      c = z[++i];
      if( c=='a' ){
        c = '\a';
      }else if( c=='b' ){
        c = '\b';
      }else if( c=='t' ){
        c = '\t';
      }else if( c=='n' ){
        c = '\n';
      }else if( c=='v' ){
        c = '\v';
      }else if( c=='f' ){
        c = '\f';
      }else if( c=='r' ){
        c = '\r';
      }else if( c=='"' ){
        c = '"';
      }else if( c=='\'' ){
        c = '\'';
      }else if( c=='\\' ){
        c = '\\';
      }else if( c>='0' && c<='7' ){
        c -= '0';
        if( z[i+1]>='0' && z[i+1]<='7' ){
          i++;
          c = (c<<3) + z[i] - '0';
          if( z[i+1]>='0' && z[i+1]<='7' ){
            i++;
            c = (c<<3) + z[i] - '0';
          }
        }
      }
    }
    z[j] = c;
  }
  if( j<i ) z[j] = 0;
}

/*
** Return the value of a hexadecimal digit.  Return -1 if the input
** is not a hex digit.
*/
static int hexDigitValue(char c){
  if( c>='0' && c<='9' ) return c - '0';
  if( c>='a' && c<='f' ) return c - 'a' + 10;
  if( c>='A' && c<='F' ) return c - 'A' + 10;
  return -1;
}

/*
** Interpret zArg as an integer value, possibly with suffixes.
*/
static sqlite3_int64 integerValue(const char *zArg){
  sqlite3_int64 v = 0;
  static const struct { char *zSuffix; int iMult; } aMult[] = {
    { "KiB", 1024 },
    { "MiB", 1024*1024 },
    { "GiB", 1024*1024*1024 },
    { "KB",  1000 },
    { "MB",  1000000 },
    { "GB",  1000000000 },
    { "K",   1000 },
    { "M",   1000000 },
    { "G",   1000000000 },
  };
  int i;
  int isNeg = 0;
  if( zArg[0]=='-' ){
    isNeg = 1;
    zArg++;
  }else if( zArg[0]=='+' ){
    zArg++;
  }
  if( zArg[0]=='0' && zArg[1]=='x' ){
    int x;
    zArg += 2;
    while( (x = hexDigitValue(zArg[0]))>=0 ){
      v = (v<<4) + x;
      zArg++;
    }
  }else{
    while( IsDigit(zArg[0]) ){
      v = v*10 + zArg[0] - '0';
      zArg++;
    }
  }
  for(i=0; i<ArraySize(aMult); i++){
    if( sqlite3_stricmp(aMult[i].zSuffix, zArg)==0 ){
      v *= aMult[i].iMult;
      break;
    }
  }
  return isNeg? -v : v;
}

/*
** Interpret zArg as either an integer or a boolean value.  Return 1 or 0
** for TRUE and FALSE.  Return the integer value if appropriate.
*/
static int booleanValue(char *zArg){
  int i;
  if( zArg[0]=='0' && zArg[1]=='x' ){
    for(i=2; hexDigitValue(zArg[i])>=0; i++){}
  }else{
    for(i=0; zArg[i]>='0' && zArg[i]<='9'; i++){}
  }
  if( i>0 && zArg[i]==0 ) return (int)(integerValue(zArg) & 0xffffffff);
  if( sqlite3_stricmp(zArg, "on")==0 || sqlite3_stricmp(zArg,"yes")==0 ){
    return 1;
  }
  if( sqlite3_stricmp(zArg, "off")==0 || sqlite3_stricmp(zArg,"no")==0 ){
    return 0;
  }
  utf8_printf(stderr, "ERROR: Not a boolean value: \"%s\". Assuming \"no\".\n",
          zArg);
  return 0;
}

/*
** Close an output file, assuming it is not stderr or stdout
*/
static void output_file_close(FILE *f){
  if( f && f!=stdout && f!=stderr ) fclose(f);
}

/*
** Try to open an output file.   The names "stdout" and "stderr" are
** recognized and do the right thing.  NULL is returned if the output
** filename is "off".
*/
static FILE *output_file_open(const char *zFile){
  FILE *f;
  if( strcmp(zFile,"stdout")==0 ){
    f = stdout;
  }else if( strcmp(zFile, "stderr")==0 ){
    f = stderr;
  }else if( strcmp(zFile, "off")==0 ){
    f = 0;
  }else{
    f = fopen(zFile, "wb");
    if( f==0 ){
      utf8_printf(stderr, "Error: cannot open \"%s\"\n", zFile);
    }
  }
  return f;
}

/*
** A routine for handling output from sqlite3_trace().
*/
static int sql_trace_callback(
  unsigned mType,
  void *pArg,
  void *pP,
  void *pX
){
  FILE *f = (FILE*)pArg;
  UNUSED_PARAMETER(mType);
  UNUSED_PARAMETER(pP);
  if( f ){
    const char *z = (const char*)pX;
    int i = (int)strlen(z);
    while( i>0 && z[i-1]==';' ){ i--; }
    utf8_printf(f, "%.*s;\n", i, z);
  }
  return 0;
}

/*
** A no-op routine that runs with the ".breakpoint" doc-command.  This is
** a useful spot to set a debugger breakpoint.
*/
static void test_breakpoint(void){
  static int nCall = 0;
  nCall++;
}

/*
** An object used to read a CSV and other files for import.
*/
typedef struct ImportCtx ImportCtx;
struct ImportCtx {
  const char *zFile;  /* Name of the input file */
  FILE *in;           /* Read the CSV text from this input stream */
  char *z;            /* Accumulated text for a field */
  int n;              /* Number of bytes in z */
  int nAlloc;         /* Space allocated for z[] */
  int nLine;          /* Current line number */
  int cTerm;          /* Character that terminated the most recent field */
  int cColSep;        /* The column separator character.  (Usually ",") */
  int cRowSep;        /* The row separator character.  (Usually "\n") */
};

/* Append a single byte to z[] */
static void import_append_char(ImportCtx *p, int c){
  if( p->n+1>=p->nAlloc ){
    p->nAlloc += p->nAlloc + 100;
    p->z = sqlite3_realloc64(p->z, p->nAlloc);
    if( p->z==0 ){
      raw_printf(stderr, "out of memory\n");
      exit(1);
    }
  }
  p->z[p->n++] = (char)c;
}

/* Read a single field of CSV text.  Compatible with rfc4180 and extended
** with the option of having a separator other than ",".
**
**   +  Input comes from p->in.
**   +  Store results in p->z of length p->n.  Space to hold p->z comes
**      from sqlite3_malloc64().
**   +  Use p->cSep as the column separator.  The default is ",".
**   +  Use p->rSep as the row separator.  The default is "\n".
**   +  Keep track of the line number in p->nLine.
**   +  Store the character that terminates the field in p->cTerm.  Store
**      EOF on end-of-file.
**   +  Report syntax errors on stderr
*/
static char *SQLITE_CDECL csv_read_one_field(ImportCtx *p){
  int c;
  int cSep = p->cColSep;
  int rSep = p->cRowSep;
  p->n = 0;
  c = fgetc(p->in);
  if( c==EOF || seenInterrupt ){
    p->cTerm = EOF;
    return 0;
  }
  if( c=='"' ){
    int pc, ppc;
    int startLine = p->nLine;
    int cQuote = c;
    pc = ppc = 0;
    while( 1 ){
      c = fgetc(p->in);
      if( c==rSep ) p->nLine++;
      if( c==cQuote ){
        if( pc==cQuote ){
          pc = 0;
          continue;
        }
      }
      if( (c==cSep && pc==cQuote)
       || (c==rSep && pc==cQuote)
       || (c==rSep && pc=='\r' && ppc==cQuote)
       || (c==EOF && pc==cQuote)
      ){
        do{ p->n--; }while( p->z[p->n]!=cQuote );
        p->cTerm = c;
        break;
      }
      if( pc==cQuote && c!='\r' ){
        utf8_printf(stderr, "%s:%d: unescaped %c character\n",
                p->zFile, p->nLine, cQuote);
      }
      if( c==EOF ){
        utf8_printf(stderr, "%s:%d: unterminated %c-quoted field\n",
                p->zFile, startLine, cQuote);
        p->cTerm = c;
        break;
      }
      import_append_char(p, c);
      ppc = pc;
      pc = c;
    }
  }else{
    while( c!=EOF && c!=cSep && c!=rSep ){
      import_append_char(p, c);
      c = fgetc(p->in);
    }
    if( c==rSep ){
      p->nLine++;
      if( p->n>0 && p->z[p->n-1]=='\r' ) p->n--;
    }
    p->cTerm = c;
  }
  if( p->z ) p->z[p->n] = 0;
  return p->z;
}

/* Read a single field of ASCII delimited text.
**
**   +  Input comes from p->in.
**   +  Store results in p->z of length p->n.  Space to hold p->z comes
**      from sqlite3_malloc64().
**   +  Use p->cSep as the column separator.  The default is "\x1F".
**   +  Use p->rSep as the row separator.  The default is "\x1E".
**   +  Keep track of the row number in p->nLine.
**   +  Store the character that terminates the field in p->cTerm.  Store
**      EOF on end-of-file.
**   +  Report syntax errors on stderr
*/
static char *SQLITE_CDECL ascii_read_one_field(ImportCtx *p){
  int c;
  int cSep = p->cColSep;
  int rSep = p->cRowSep;
  p->n = 0;
  c = fgetc(p->in);
  if( c==EOF || seenInterrupt ){
    p->cTerm = EOF;
    return 0;
  }
  while( c!=EOF && c!=cSep && c!=rSep ){
    import_append_char(p, c);
    c = fgetc(p->in);
  }
  if( c==rSep ){
    p->nLine++;
  }
  p->cTerm = c;
  if( p->z ) p->z[p->n] = 0;
  return p->z;
}

/*
** Try to transfer data for table zTable.  If an error is seen while
** moving forward, try to go backwards.  The backwards movement won't
** work for WITHOUT ROWID tables.
*/
static void tryToCloneData(
  ShellState *p,
  sqlite3 *newDb,
  const char *zTable
){
  sqlite3_stmt *pQuery = 0;
  sqlite3_stmt *pInsert = 0;
  char *zQuery = 0;
  char *zInsert = 0;
  int rc;
  int i, j, n;
  int nTable = (int)strlen(zTable);
  int k = 0;
  int cnt = 0;
  const int spinRate = 10000;

  zQuery = sqlite3_mprintf("SELECT * FROM \"%w\"", zTable);
  rc = sqlite3_prepare_v2(p->db, zQuery, -1, &pQuery, 0);
  if( rc ){
    utf8_printf(stderr, "Error %d: %s on [%s]\n",
            sqlite3_extended_errcode(p->db), sqlite3_errmsg(p->db),
            zQuery);
    goto end_data_xfer;
  }
  n = sqlite3_column_count(pQuery);
  zInsert = sqlite3_malloc64(200 + nTable + n*3);
  if( zInsert==0 ){
    raw_printf(stderr, "out of memory\n");
    goto end_data_xfer;
  }
  sqlite3_snprintf(200+nTable,zInsert,
                   "INSERT OR IGNORE INTO \"%s\" VALUES(?", zTable);
  i = (int)strlen(zInsert);
  for(j=1; j<n; j++){
    memcpy(zInsert+i, ",?", 2);
    i += 2;
  }
  memcpy(zInsert+i, ");", 3);
  rc = sqlite3_prepare_v2(newDb, zInsert, -1, &pInsert, 0);
  if( rc ){
    utf8_printf(stderr, "Error %d: %s on [%s]\n",
            sqlite3_extended_errcode(newDb), sqlite3_errmsg(newDb),
            zQuery);
    goto end_data_xfer;
  }
  for(k=0; k<2; k++){
    while( (rc = sqlite3_step(pQuery))==SQLITE_ROW ){
      for(i=0; i<n; i++){
        switch( sqlite3_column_type(pQuery, i) ){
          case SQLITE_NULL: {
            sqlite3_bind_null(pInsert, i+1);
            break;
          }
          case SQLITE_INTEGER: {
            sqlite3_bind_int64(pInsert, i+1, sqlite3_column_int64(pQuery,i));
            break;
          }
          case SQLITE_FLOAT: {
            sqlite3_bind_double(pInsert, i+1, sqlite3_column_double(pQuery,i));
            break;
          }
          case SQLITE_TEXT: {
            sqlite3_bind_text(pInsert, i+1,
                             (const char*)sqlite3_column_text(pQuery,i),
                             -1, SQLITE_STATIC);
            break;
          }
          case SQLITE_BLOB: {
            sqlite3_bind_blob(pInsert, i+1, sqlite3_column_blob(pQuery,i),
                                            sqlite3_column_bytes(pQuery,i),
                                            SQLITE_STATIC);
            break;
          }
        }
      } /* End for */
      rc = sqlite3_step(pInsert);
      if( rc!=SQLITE_OK && rc!=SQLITE_ROW && rc!=SQLITE_DONE ){
        utf8_printf(stderr, "Error %d: %s\n", sqlite3_extended_errcode(newDb),
                        sqlite3_errmsg(newDb));
      }
      sqlite3_reset(pInsert);
      cnt++;
      if( (cnt%spinRate)==0 ){
        printf("%c\b", "|/-\\"[(cnt/spinRate)%4]);
        fflush(stdout);
      }
    } /* End while */
    if( rc==SQLITE_DONE ) break;
    sqlite3_finalize(pQuery);
    sqlite3_free(zQuery);
    zQuery = sqlite3_mprintf("SELECT * FROM \"%w\" ORDER BY rowid DESC;",
                             zTable);
    rc = sqlite3_prepare_v2(p->db, zQuery, -1, &pQuery, 0);
    if( rc ){
      utf8_printf(stderr, "Warning: cannot step \"%s\" backwards", zTable);
      break;
    }
  } /* End for(k=0...) */

end_data_xfer:
  sqlite3_finalize(pQuery);
  sqlite3_finalize(pInsert);
  sqlite3_free(zQuery);
  sqlite3_free(zInsert);
}


/*
** Try to transfer all rows of the schema that match zWhere.  For
** each row, invoke xForEach() on the object defined by that row.
** If an error is encountered while moving forward through the
** sqlite_master table, try again moving backwards.
*/
static void tryToCloneSchema(
  ShellState *p,
  sqlite3 *newDb,
  const char *zWhere,
  void (*xForEach)(ShellState*,sqlite3*,const char*)
){
  sqlite3_stmt *pQuery = 0;
  char *zQuery = 0;
  int rc;
  const unsigned char *zName;
  const unsigned char *zSql;
  char *zErrMsg = 0;

  zQuery = sqlite3_mprintf("SELECT name, sql FROM sqlite_master"
                           " WHERE %s", zWhere);
  rc = sqlite3_prepare_v2(p->db, zQuery, -1, &pQuery, 0);
  if( rc ){
    utf8_printf(stderr, "Error: (%d) %s on [%s]\n",
                    sqlite3_extended_errcode(p->db), sqlite3_errmsg(p->db),
                    zQuery);
    goto end_schema_xfer;
  }
  while( (rc = sqlite3_step(pQuery))==SQLITE_ROW ){
    zName = sqlite3_column_text(pQuery, 0);
    zSql = sqlite3_column_text(pQuery, 1);
    printf("%s... ", zName); fflush(stdout);
    sqlite3_exec(newDb, (const char*)zSql, 0, 0, &zErrMsg);
    if( zErrMsg ){
      utf8_printf(stderr, "Error: %s\nSQL: [%s]\n", zErrMsg, zSql);
      sqlite3_free(zErrMsg);
      zErrMsg = 0;
    }
    if( xForEach ){
      xForEach(p, newDb, (const char*)zName);
    }
    printf("done\n");
  }
  if( rc!=SQLITE_DONE ){
    sqlite3_finalize(pQuery);
    sqlite3_free(zQuery);
    zQuery = sqlite3_mprintf("SELECT name, sql FROM sqlite_master"
                             " WHERE %s ORDER BY rowid DESC", zWhere);
    rc = sqlite3_prepare_v2(p->db, zQuery, -1, &pQuery, 0);
    if( rc ){
      utf8_printf(stderr, "Error: (%d) %s on [%s]\n",
                      sqlite3_extended_errcode(p->db), sqlite3_errmsg(p->db),
                      zQuery);
      goto end_schema_xfer;
    }
    while( (rc = sqlite3_step(pQuery))==SQLITE_ROW ){
      zName = sqlite3_column_text(pQuery, 0);
      zSql = sqlite3_column_text(pQuery, 1);
      printf("%s... ", zName); fflush(stdout);
      sqlite3_exec(newDb, (const char*)zSql, 0, 0, &zErrMsg);
      if( zErrMsg ){
        utf8_printf(stderr, "Error: %s\nSQL: [%s]\n", zErrMsg, zSql);
        sqlite3_free(zErrMsg);
        zErrMsg = 0;
      }
      if( xForEach ){
        xForEach(p, newDb, (const char*)zName);
      }
      printf("done\n");
    }
  }
end_schema_xfer:
  sqlite3_finalize(pQuery);
  sqlite3_free(zQuery);
}

/*
** Open a new database file named "zNewDb".  Try to recover as much information
** as possible out of the main database (which might be corrupt) and write it
** into zNewDb.
*/
static void tryToClone(ShellState *p, const char *zNewDb){
  int rc;
  sqlite3 *newDb = 0;
  if( access(zNewDb,0)==0 ){
    utf8_printf(stderr, "File \"%s\" already exists.\n", zNewDb);
    return;
  }
  rc = sqlite3_open(zNewDb, &newDb);
  if( rc ){
    utf8_printf(stderr, "Cannot create output database: %s\n",
            sqlite3_errmsg(newDb));
  }else{
    sqlite3_exec(p->db, "PRAGMA writable_schema=ON;", 0, 0, 0);
    sqlite3_exec(newDb, "BEGIN EXCLUSIVE;", 0, 0, 0);
    tryToCloneSchema(p, newDb, "type='table'", tryToCloneData);
    tryToCloneSchema(p, newDb, "type!='table'", 0);
    sqlite3_exec(newDb, "COMMIT;", 0, 0, 0);
    sqlite3_exec(p->db, "PRAGMA writable_schema=OFF;", 0, 0, 0);
  }
  sqlite3_close(newDb);
}

/*
** Change the output file back to stdout
*/
static void output_reset(ShellState *p){
  if( p->outfile[0]=='|' ){
#ifndef SQLITE_OMIT_POPEN
    pclose(p->out);
#endif
  }else{
    output_file_close(p->out);
  }
  p->outfile[0] = 0;
  p->out = stdout;
}

/*
** Run an SQL command and return the single integer result.
*/
static int db_int(ShellState *p, const char *zSql){
  sqlite3_stmt *pStmt;
  int res = 0;
  sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0);
  if( pStmt && sqlite3_step(pStmt)==SQLITE_ROW ){
    res = sqlite3_column_int(pStmt,0);
  }
  sqlite3_finalize(pStmt);
  return res;
}

/*
** Convert a 2-byte or 4-byte big-endian integer into a native integer
*/
static unsigned int get2byteInt(unsigned char *a){
  return (a[0]<<8) + a[1];
}
static unsigned int get4byteInt(unsigned char *a){
  return (a[0]<<24) + (a[1]<<16) + (a[2]<<8) + a[3];
}

/*
** Implementation of the ".info" command.
**
** Return 1 on error, 2 to exit, and 0 otherwise.
*/
static int shell_dbinfo_command(ShellState *p, int nArg, char **azArg){
  static const struct { const char *zName; int ofst; } aField[] = {
     { "file change counter:",  24  },
     { "database page count:",  28  },
     { "freelist page count:",  36  },
     { "schema cookie:",        40  },
     { "schema format:",        44  },
     { "default cache size:",   48  },
     { "autovacuum top root:",  52  },
     { "incremental vacuum:",   64  },
     { "text encoding:",        56  },
     { "user version:",         60  },
     { "application id:",       68  },
     { "software version:",     96  },
  };
  static const struct { const char *zName; const char *zSql; } aQuery[] = {
     { "number of tables:",
       "SELECT count(*) FROM %s WHERE type='table'" },
     { "number of indexes:",
       "SELECT count(*) FROM %s WHERE type='index'" },
     { "number of triggers:",
       "SELECT count(*) FROM %s WHERE type='trigger'" },
     { "number of views:",
       "SELECT count(*) FROM %s WHERE type='view'" },
     { "schema size:",
       "SELECT total(length(sql)) FROM %s" },
  };
  sqlite3_file *pFile = 0;
  int i;
  char *zSchemaTab;
  char *zDb = nArg>=2 ? azArg[1] : "main";
  unsigned char aHdr[100];
  open_db(p, 0);
  if( p->db==0 ) return 1;
  sqlite3_file_control(p->db, zDb, SQLITE_FCNTL_FILE_POINTER, &pFile);
  if( pFile==0 || pFile->pMethods==0 || pFile->pMethods->xRead==0 ){
    return 1;
  }
  i = pFile->pMethods->xRead(pFile, aHdr, 100, 0);
  if( i!=SQLITE_OK ){
    raw_printf(stderr, "unable to read database header\n");
    return 1;
  }
  i = get2byteInt(aHdr+16);
  if( i==1 ) i = 65536;
  utf8_printf(p->out, "%-20s %d\n", "database page size:", i);
  utf8_printf(p->out, "%-20s %d\n", "write format:", aHdr[18]);
  utf8_printf(p->out, "%-20s %d\n", "read format:", aHdr[19]);
  utf8_printf(p->out, "%-20s %d\n", "reserved bytes:", aHdr[20]);
  for(i=0; i<ArraySize(aField); i++){
    int ofst = aField[i].ofst;
    unsigned int val = get4byteInt(aHdr + ofst);
    utf8_printf(p->out, "%-20s %u", aField[i].zName, val);
    switch( ofst ){
      case 56: {
        if( val==1 ) raw_printf(p->out, " (utf8)");
        if( val==2 ) raw_printf(p->out, " (utf16le)");
        if( val==3 ) raw_printf(p->out, " (utf16be)");
      }
    }
    raw_printf(p->out, "\n");
  }
  if( zDb==0 ){
    zSchemaTab = sqlite3_mprintf("main.sqlite_master");
  }else if( strcmp(zDb,"temp")==0 ){
    zSchemaTab = sqlite3_mprintf("%s", "sqlite_temp_master");
  }else{
    zSchemaTab = sqlite3_mprintf("\"%w\".sqlite_master", zDb);
  }
  for(i=0; i<ArraySize(aQuery); i++){
    char *zSql = sqlite3_mprintf(aQuery[i].zSql, zSchemaTab);
    int val = db_int(p, zSql);
    sqlite3_free(zSql);
    utf8_printf(p->out, "%-20s %d\n", aQuery[i].zName, val);
  }
  sqlite3_free(zSchemaTab);
  return 0;
}

/*
** Print the current sqlite3_errmsg() value to stderr and return 1.
*/
static int shellDatabaseError(sqlite3 *db){
  const char *zErr = sqlite3_errmsg(db);
  utf8_printf(stderr, "Error: %s\n", zErr);
  return 1;
}

/*
** Print an out-of-memory message to stderr and return 1.
*/
static int shellNomemError(void){
  raw_printf(stderr, "Error: out of memory\n");
  return 1;
}

/*
** Compare the pattern in zGlob[] against the text in z[].  Return TRUE
** if they match and FALSE (0) if they do not match.
**
** Globbing rules:
**
**      '*'       Matches any sequence of zero or more characters.
**
**      '?'       Matches exactly one character.
**
**     [...]      Matches one character from the enclosed list of
**                characters.
**
**     [^...]     Matches one character not in the enclosed list.
**
**      '#'       Matches any sequence of one or more digits with an
**                optional + or - sign in front
**
**      ' '       Any span of whitespace matches any other span of
**                whitespace.
**
** Extra whitespace at the end of z[] is ignored.
*/
static int testcase_glob(const char *zGlob, const char *z){
  int c, c2;
  int invert;
  int seen;

  while( (c = (*(zGlob++)))!=0 ){
    if( IsSpace(c) ){
      if( !IsSpace(*z) ) return 0;
      while( IsSpace(*zGlob) ) zGlob++;
      while( IsSpace(*z) ) z++;
    }else if( c=='*' ){
      while( (c=(*(zGlob++))) == '*' || c=='?' ){
        if( c=='?' && (*(z++))==0 ) return 0;
      }
      if( c==0 ){
        return 1;
      }else if( c=='[' ){
        while( *z && testcase_glob(zGlob-1,z)==0 ){
          z++;
        }
        return (*z)!=0;
      }
      while( (c2 = (*(z++)))!=0 ){
        while( c2!=c ){
          c2 = *(z++);
          if( c2==0 ) return 0;
        }
        if( testcase_glob(zGlob,z) ) return 1;
      }
      return 0;
    }else if( c=='?' ){
      if( (*(z++))==0 ) return 0;
    }else if( c=='[' ){
      int prior_c = 0;
      seen = 0;
      invert = 0;
      c = *(z++);
      if( c==0 ) return 0;
      c2 = *(zGlob++);
      if( c2=='^' ){
        invert = 1;
        c2 = *(zGlob++);
      }
      if( c2==']' ){
        if( c==']' ) seen = 1;
        c2 = *(zGlob++);
      }
      while( c2 && c2!=']' ){
        if( c2=='-' && zGlob[0]!=']' && zGlob[0]!=0 && prior_c>0 ){
          c2 = *(zGlob++);
          if( c>=prior_c && c<=c2 ) seen = 1;
          prior_c = 0;
        }else{
          if( c==c2 ){
            seen = 1;
          }
          prior_c = c2;
        }
        c2 = *(zGlob++);
      }
      if( c2==0 || (seen ^ invert)==0 ) return 0;
    }else if( c=='#' ){
      if( (z[0]=='-' || z[0]=='+') && IsDigit(z[1]) ) z++;
      if( !IsDigit(z[0]) ) return 0;
      z++;
      while( IsDigit(z[0]) ){ z++; }
    }else{
      if( c!=(*(z++)) ) return 0;
    }
  }
  while( IsSpace(*z) ){ z++; }
  return *z==0;
}


/*
** Compare the string as a command-line option with either one or two
** initial "-" characters.
*/
static int optionMatch(const char *zStr, const char *zOpt){
  if( zStr[0]!='-' ) return 0;
  zStr++;
  if( zStr[0]=='-' ) zStr++;
  return strcmp(zStr, zOpt)==0;
}

/*
** Delete a file.
*/
int shellDeleteFile(const char *zFilename){
  int rc;
#ifdef _WIN32
  wchar_t *z = sqlite3_win32_utf8_to_unicode(zFilename);
  rc = _wunlink(z);
  sqlite3_free(z);
#else
  rc = unlink(zFilename);
#endif
  return rc;
}

/*
** If an input line begins with "." then invoke this routine to
** process that line.
**
** Return 1 on error, 2 to exit, and 0 otherwise.
*/
static int do_meta_command(char *zLine, ShellState *p){
  int h = 1;
  int nArg = 0;
  int n, c;
  int rc = 0;
  char *azArg[50];

  /* Parse the input line into tokens.
  */
  while( zLine[h] && nArg<ArraySize(azArg) ){
    while( IsSpace(zLine[h]) ){ h++; }
    if( zLine[h]==0 ) break;
    if( zLine[h]=='\'' || zLine[h]=='"' ){
      int delim = zLine[h++];
      azArg[nArg++] = &zLine[h];
      while( zLine[h] && zLine[h]!=delim ){
        if( zLine[h]=='\\' && delim=='"' && zLine[h+1]!=0 ) h++;
        h++;
      }
      if( zLine[h]==delim ){
        zLine[h++] = 0;
      }
      if( delim=='"' ) resolve_backslashes(azArg[nArg-1]);
    }else{
      azArg[nArg++] = &zLine[h];
      while( zLine[h] && !IsSpace(zLine[h]) ){ h++; }
      if( zLine[h] ) zLine[h++] = 0;
      resolve_backslashes(azArg[nArg-1]);
    }
  }

  /* Process the input line.
  */
  if( nArg==0 ) return 0; /* no tokens, no error */
  n = strlen30(azArg[0]);
  c = azArg[0][0];

#ifndef SQLITE_OMIT_AUTHORIZATION
  if( c=='a' && strncmp(azArg[0], "auth", n)==0 ){
    if( nArg!=2 ){
      raw_printf(stderr, "Usage: .auth ON|OFF\n");
      rc = 1;
      goto meta_command_exit;
    }
    open_db(p, 0);
    if( booleanValue(azArg[1]) ){
      sqlite3_set_authorizer(p->db, shellAuth, p);
    }else{
      sqlite3_set_authorizer(p->db, 0, 0);
    }
  }else
#endif

  if( (c=='b' && n>=3 && strncmp(azArg[0], "backup", n)==0)
   || (c=='s' && n>=3 && strncmp(azArg[0], "save", n)==0)
  ){
    const char *zDestFile = 0;
    const char *zDb = 0;
    sqlite3 *pDest;
    sqlite3_backup *pBackup;
    int j;
    for(j=1; j<nArg; j++){
      const char *z = azArg[j];
      if( z[0]=='-' ){
        while( z[0]=='-' ) z++;
        /* No options to process at this time */
        {
          utf8_printf(stderr, "unknown option: %s\n", azArg[j]);
          return 1;
        }
      }else if( zDestFile==0 ){
        zDestFile = azArg[j];
      }else if( zDb==0 ){
        zDb = zDestFile;
        zDestFile = azArg[j];
      }else{
        raw_printf(stderr, "too many arguments to .backup\n");
        return 1;
      }
    }
    if( zDestFile==0 ){
      raw_printf(stderr, "missing FILENAME argument on .backup\n");
      return 1;
    }
    if( zDb==0 ) zDb = "main";
    rc = sqlite3_open(zDestFile, &pDest);
    if( rc!=SQLITE_OK ){
      utf8_printf(stderr, "Error: cannot open \"%s\"\n", zDestFile);
      sqlite3_close(pDest);
      return 1;
    }
    open_db(p, 0);
    pBackup = sqlite3_backup_init(pDest, "main", p->db, zDb);
    if( pBackup==0 ){
      utf8_printf(stderr, "Error: %s\n", sqlite3_errmsg(pDest));
      sqlite3_close(pDest);
      return 1;
    }
    while(  (rc = sqlite3_backup_step(pBackup,100))==SQLITE_OK ){}
    sqlite3_backup_finish(pBackup);
    if( rc==SQLITE_DONE ){
      rc = 0;
    }else{
      utf8_printf(stderr, "Error: %s\n", sqlite3_errmsg(pDest));
      rc = 1;
    }
    sqlite3_close(pDest);
  }else

  if( c=='b' && n>=3 && strncmp(azArg[0], "bail", n)==0 ){
    if( nArg==2 ){
      bail_on_error = booleanValue(azArg[1]);
    }else{
      raw_printf(stderr, "Usage: .bail on|off\n");
      rc = 1;
    }
  }else

  if( c=='b' && n>=3 && strncmp(azArg[0], "binary", n)==0 ){
    if( nArg==2 ){
      if( booleanValue(azArg[1]) ){
        setBinaryMode(p->out, 1);
      }else{
        setTextMode(p->out, 1);
      }
    }else{
      raw_printf(stderr, "Usage: .binary on|off\n");
      rc = 1;
    }
  }else

  /* The undocumented ".breakpoint" command causes a call to the no-op
  ** routine named test_breakpoint().
  */
  if( c=='b' && n>=3 && strncmp(azArg[0], "breakpoint", n)==0 ){
    test_breakpoint();
  }else

  if( c=='c' && n>=3 && strncmp(azArg[0], "changes", n)==0 ){
    if( nArg==2 ){
      p->countChanges = booleanValue(azArg[1]);
    }else{
      raw_printf(stderr, "Usage: .changes on|off\n");
      rc = 1;
    }
  }else

  /* Cancel output redirection, if it is currently set (by .testcase)
  ** Then read the content of the testcase-out.txt file and compare against
  ** azArg[1].  If there are differences, report an error and exit.
  */
  if( c=='c' && n>=3 && strncmp(azArg[0], "check", n)==0 ){
    char *zRes = 0;
    output_reset(p);
    if( nArg!=2 ){
      raw_printf(stderr, "Usage: .check GLOB-PATTERN\n");
      rc = 2;
    }else if( (zRes = readFile("testcase-out.txt"))==0 ){
      raw_printf(stderr, "Error: cannot read 'testcase-out.txt'\n");
      rc = 2;
    }else if( testcase_glob(azArg[1],zRes)==0 ){
      utf8_printf(stderr,
                 "testcase-%s FAILED\n Expected: [%s]\n      Got: [%s]\n",
                 p->zTestcase, azArg[1], zRes);
      rc = 2;
    }else{
      utf8_printf(stdout, "testcase-%s ok\n", p->zTestcase);
      p->nCheck++;
    }
    sqlite3_free(zRes);
  }else

  if( c=='c' && strncmp(azArg[0], "clone", n)==0 ){
    if( nArg==2 ){
      tryToClone(p, azArg[1]);
    }else{
      raw_printf(stderr, "Usage: .clone FILENAME\n");
      rc = 1;
    }
  }else

  if( c=='d' && n>1 && strncmp(azArg[0], "databases", n)==0 ){
    ShellState data;
    char *zErrMsg = 0;
    open_db(p, 0);
    memcpy(&data, p, sizeof(data));
    data.showHeader = 1;
    data.cMode = data.mode = MODE_Column;
    data.colWidth[0] = 3;
    data.colWidth[1] = 15;
    data.colWidth[2] = 58;
    data.cnt = 0;
    sqlite3_exec(p->db, "PRAGMA database_list; ", callback, &data, &zErrMsg);
    if( zErrMsg ){
      utf8_printf(stderr,"Error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      rc = 1;
    }
  }else

  if( c=='d' && strncmp(azArg[0], "dbinfo", n)==0 ){
    rc = shell_dbinfo_command(p, nArg, azArg);
  }else

  if( c=='d' && strncmp(azArg[0], "dump", n)==0 ){
    open_db(p, 0);
    /* When playing back a "dump", the content might appear in an order
    ** which causes immediate foreign key constraints to be violated.
    ** So disable foreign-key constraint enforcement to prevent problems. */
    if( nArg!=1 && nArg!=2 ){
      raw_printf(stderr, "Usage: .dump ?LIKE-PATTERN?\n");
      rc = 1;
      goto meta_command_exit;
    }
    raw_printf(p->out, "PRAGMA foreign_keys=OFF;\n");
    raw_printf(p->out, "BEGIN TRANSACTION;\n");
    p->writableSchema = 0;
    sqlite3_exec(p->db, "SAVEPOINT dump; PRAGMA writable_schema=ON", 0, 0, 0);
    p->nErr = 0;
    if( nArg==1 ){
      run_schema_dump_query(p,
        "SELECT name, type, sql FROM sqlite_master "
        "WHERE sql NOT NULL AND type=='table' AND name!='sqlite_sequence'"
      );
      run_schema_dump_query(p,
        "SELECT name, type, sql FROM sqlite_master "
        "WHERE name=='sqlite_sequence'"
      );
      run_table_dump_query(p,
        "SELECT sql FROM sqlite_master "
        "WHERE sql NOT NULL AND type IN ('index','trigger','view')", 0
      );
    }else{
      int i;
      for(i=1; i<nArg; i++){
        zShellStatic = azArg[i];
        run_schema_dump_query(p,
          "SELECT name, type, sql FROM sqlite_master "
          "WHERE tbl_name LIKE shellstatic() AND type=='table'"
          "  AND sql NOT NULL");
        run_table_dump_query(p,
          "SELECT sql FROM sqlite_master "
          "WHERE sql NOT NULL"
          "  AND type IN ('index','trigger','view')"
          "  AND tbl_name LIKE shellstatic()", 0
        );
        zShellStatic = 0;
      }
    }
    if( p->writableSchema ){
      raw_printf(p->out, "PRAGMA writable_schema=OFF;\n");
      p->writableSchema = 0;
    }
    sqlite3_exec(p->db, "PRAGMA writable_schema=OFF;", 0, 0, 0);
    sqlite3_exec(p->db, "RELEASE dump;", 0, 0, 0);
    raw_printf(p->out, p->nErr ? "ROLLBACK; -- due to errors\n" : "COMMIT;\n");
  }else

  if( c=='e' && strncmp(azArg[0], "echo", n)==0 ){
    if( nArg==2 ){
      p->echoOn = booleanValue(azArg[1]);
    }else{
      raw_printf(stderr, "Usage: .echo on|off\n");
      rc = 1;
    }
  }else

  if( c=='e' && strncmp(azArg[0], "eqp", n)==0 ){
    if( nArg==2 ){
      if( strcmp(azArg[1],"full")==0 ){
        p->autoEQP = 2;
      }else{
        p->autoEQP = booleanValue(azArg[1]);
      }
    }else{
      raw_printf(stderr, "Usage: .eqp on|off|full\n");
      rc = 1;
    }
  }else

  if( c=='e' && strncmp(azArg[0], "exit", n)==0 ){
    if( nArg>1 && (rc = (int)integerValue(azArg[1]))!=0 ) exit(rc);
    rc = 2;
  }else

  if( c=='e' && strncmp(azArg[0], "explain", n)==0 ){
    int val = 1;
    if( nArg>=2 ){
      if( strcmp(azArg[1],"auto")==0 ){
        val = 99;
      }else{
        val =  booleanValue(azArg[1]);
      }
    }
    if( val==1 && p->mode!=MODE_Explain ){
      p->normalMode = p->mode;
      p->mode = MODE_Explain;
      p->autoExplain = 0;
    }else if( val==0 ){
      if( p->mode==MODE_Explain ) p->mode = p->normalMode;
      p->autoExplain = 0;
    }else if( val==99 ){
      if( p->mode==MODE_Explain ) p->mode = p->normalMode;
      p->autoExplain = 1;
    }
  }else

  if( c=='f' && strncmp(azArg[0], "fullschema", n)==0 ){
    ShellState data;
    char *zErrMsg = 0;
    int doStats = 0;
    memcpy(&data, p, sizeof(data));
    data.showHeader = 0;
    data.cMode = data.mode = MODE_Semi;
    if( nArg==2 && optionMatch(azArg[1], "indent") ){
      data.cMode = data.mode = MODE_Pretty;
      nArg = 1;
    }
    if( nArg!=1 ){
      raw_printf(stderr, "Usage: .fullschema ?--indent?\n");
      rc = 1;
      goto meta_command_exit;
    }
    open_db(p, 0);
    rc = sqlite3_exec(p->db,
       "SELECT sql FROM"
       "  (SELECT sql sql, type type, tbl_name tbl_name, name name, rowid x"
       "     FROM sqlite_master UNION ALL"
       "   SELECT sql, type, tbl_name, name, rowid FROM sqlite_temp_master) "
       "WHERE type!='meta' AND sql NOTNULL AND name NOT LIKE 'sqlite_%' "
       "ORDER BY rowid",
       callback, &data, &zErrMsg
    );
    if( rc==SQLITE_OK ){
      sqlite3_stmt *pStmt;
      rc = sqlite3_prepare_v2(p->db,
               "SELECT rowid FROM sqlite_master"
               " WHERE name GLOB 'sqlite_stat[134]'",
               -1, &pStmt, 0);
      doStats = sqlite3_step(pStmt)==SQLITE_ROW;
      sqlite3_finalize(pStmt);
    }
    if( doStats==0 ){
      raw_printf(p->out, "/* No STAT tables available */\n");
    }else{
      raw_printf(p->out, "ANALYZE sqlite_master;\n");
      sqlite3_exec(p->db, "SELECT 'ANALYZE sqlite_master'",
                   callback, &data, &zErrMsg);
      data.cMode = data.mode = MODE_Insert;
      data.zDestTable = "sqlite_stat1";
      shell_exec(p->db, "SELECT * FROM sqlite_stat1",
                 shell_callback, &data,&zErrMsg);
      data.zDestTable = "sqlite_stat3";
      shell_exec(p->db, "SELECT * FROM sqlite_stat3",
                 shell_callback, &data,&zErrMsg);
      data.zDestTable = "sqlite_stat4";
      shell_exec(p->db, "SELECT * FROM sqlite_stat4",
                 shell_callback, &data, &zErrMsg);
      raw_printf(p->out, "ANALYZE sqlite_master;\n");
    }
  }else

  if( c=='h' && strncmp(azArg[0], "headers", n)==0 ){
    if( nArg==2 ){
      p->showHeader = booleanValue(azArg[1]);
    }else{
      raw_printf(stderr, "Usage: .headers on|off\n");
      rc = 1;
    }
  }else

  if( c=='else

  if( c=='h' && strncle = "sobbing 
= 1;
   t4";
      shell_exec(p->d>out, "ly one character.
**
**     [...]      Matches one c kwards.
*/
st0s %dll_etw_rrors\n]   >out,u   raline i at tavailab kwards.
*/
ar *zFill_etw_rrors\n]    /* Nam.txt r, 2 ** E the concter ab kwar     sqlite3_stmt *   l NOurn 0A };
 nforceems. */
tic iolzFill_etw_rrors\n        /* Numbeite3_csr not intavailab kwar
tic Byt*zFill_etw_rrors\n       /* Number of byte Run an the stab kwar
tic intzFill_etw_rrors\n      Loophange coslab kwar
tic eedCetand_tw_rrors\n      Tr -- du" : "Cr onr ? "ROLoces theab kwar
tic  cRowSep;   w_rrors\n       /* Number of byte     ->cCw sepafor z[]  const char *zp;   w_rrors\n     ARun an t
 nforceems. */ield(Imporsmpor  w_rrors\n     RshowHe the xtr z[]  const c(har *SQLITE_C*ods->)field(Impo*)urn 0Funcnable to : .csg() vab kwar
tic(har *SQLITE_C*o*
** r)*f = (F;rs\n     Funcnablite3_input fil    }
    if( n3rg!=1 ){
      raw_printf(stderr, "Usa    Ma */
  TABLLENAME\n");
      goto meta_command_exit;
    }zzDestFile = a1Arg[i];zzDestTable = a2Arg[i];F || seenIntertats = 0;
  ut_r&smpo;", 0, p, sismpo(data));
    open_db(p, 0);nint rS n = strl     ->cCw sepaset(p);
    >cCxt"))==0 ){
      raw_printf(stat4",
            derr,"Ernon-bind* The column separrequirlocated    Maackup\n");
      return 1;
    }
    >cC>Arg!=1 ){
      raw_printf(stdeerr,"Ermulti- one chara The column sepa it iste3_wedaster"
                 "cated    Maackup\n");
      return 1;
    }nint rS n = strl   rp->cRw sepaset(p);
    >cCxt"))==0 ){
      raw_printf(st derr,"Ernon-bind* The row separrequirlocated    Maackup\n");
      return 1;
    }
    >cC nArg== if( p->mode==Csvcter.
*
**    rp->cRw sepa,  "P_CrLfauto")==0 ){
 
    /*     Mae std of(only),E (0) i* The row separrror t call t=0 ){
 **  The defncel outThe row sepa,"file chit call t  The defathe =0 ){
 **  the row separatoritabloidson of ha   gonstthe mare difefathe =0 ){
 **  CSV cel outThe row sepaoblems. */
  }
  sqlite3_snpr, p, si   rp->cRw sepas->outrp->cRw sepa,  "P_Rowup\n");
 nint rS n = strl   rp->cRw sepaset(p);
    }
    >cC>Arg!=1 ){
      raw_printf(stdeerr,"Ermulti- one charatThe row sepaoit iste3_wedaster"
                 "cated    Maackup\n");
      return 1;
    }smpo.zzDestFizzDestFile;smpo.nstartLial = 1;
   smpo.zzDestfile[0]=='|' )
#ifndef SQLITE_OMIT_POPEN
      raw_printf(stdeerr,"Erpip tabreit issup  Mansign i at OSackup\n");
      retur(z);
#elile;smpo.Explapite3_smpo.zzDesrt, "rer;\n");
  mpo.zzDestFi"<pip >stat4";
 o*
** rplapite3_name);
#end);
    }else{
  mpo.Explafite3_smpo.zzDes, "rber;\n");
 o*
** rplafite3_na(p);
    }
    if( p->mode==AECL rEach ){
  

/* =CDECL ascii_read_one_g[1]);
    }else{
  

/* =CDECL csv_read_one_na(p);
    }
    mpo.Exackup==0 ){
      utf8_printf(stderr, "Error: cannot open \"%s\"\zDestFile);
      return 1;
    }smpo.= p->cC>mode   ->cCw sepaf0]tFile;smpo.= p->cR>mode rp->cRw sepaf0]tFile;har *zSql = sqlite3_mpr>db, "SELECT * %kwards", zTable);+;
  iqlxt"))==0 ){
      raw_printf(st derr,"Errr, "out of memory\n");
 o*
** r( mpo.Exup\n");
      return 1;
    }nByt* rS n = strlfree(zSql);
    rc = sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0 {
    import_append_&smpo;",F;rs\n   T  gosureismpo.zrrropace allochile */
    ipStmt && sqlitrcase_"nossuchntavai: * %s\n", sqlite3_errmsg(pauto")==0 ){
 onst chCnot crzSql = sqlite3_mpr>CREAT  TABLL %kwards", zTable);
 onst  int cS'('able);
 
    whods->x&smporg[1]) ){
   hCnot crzSql = sqlite3_mpr>%z%c [%sFROM \"LITEwardCnot c,  int,ismpo.z     );
    int cS','    );
   
    mpo.  p->!=smpo.= p->cC>)      break;
      }
     c>cC n'('g[1]) ){
        sqlite3_fCnot c     );
        sqlite3_smpo.z     );
   o*
** r( mpo.Exup\n");
 
      utf8_printf(std%s: emptyinputr: %s\mpo.zzDesup\n");
        return 1;
      }  hCnot crzSql = sqlite3_mpr>%z\n)wardCnot cff\n");
           sqlite3_exec(p-dCnot c, p;", 0, 0, 0);       sqlite3_fCnot c     );
 
    if( rc ){
 ){
    utf8_printf(stderREAT  TABLL %k(r(k=0faDesror %d: %sds", ztat4",
           \n", sqlite3_errmsg(pa    );
        sqlite3_smpo.z     );
   o*
** r( mpo.Exup\n");
 
 z) ) return 1;
      }
      rc = sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0 {
    }
    sqlite3_free(zSql);
    if( rc ){
  (0alize(p      sqlite3_finalize(pStmt);
      utf8_printf(stderr,"Error: %s\n", sqlite3_errmsg(pa    );
 o*
** r( mpo.Exup\n");
      return 1;
    }n p-  res = sqlite3_column_coize(pStmt);     sqlite3_finalize(pStmt);tmt *   rr = 0;
     p- nArg==0 ) return 0; /ite3_csokens, no error e;har *zSql = sqlite3_mall}nByt**2 + 264(20 p-*2 Table);+;
  iqlxt"))==0 ){
      raw_printf(st derr,"Errr, "out of memory\n");
 o*
** r( mpo.Exup\n");
      return 1;
    } }
  sqlite3_snprnByt*+20p->db, z     "INNORE INTw \"%s\" VALUES(?", zTable  j rS n = strlfree(zSql);     for(i=1iolzFArg; i++){
 free[jine[h+','    );
 free[jine[h+'?'_exit;
    }zree[jine[h+')';    }zree[je[h++] = 0;     rc = sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0 {
    sqlite3_free(zSql);
    if( rc ){
      utf8_printf(stderr, "Error: %s\n", sqlite3_errmsg(pa    );
  (0alize(p      sqlite3_finalize(pStmt);
 o*
** r( mpo.Exup\n");
      return 1;
    }needCetand   rc = sqlgte3_seocetandrrmsg(pr = 0;
    eedCetand )      sqlite3_exec(p-out, "dump;", 0, 0, 0);do rc ){
  
*/
le, star   rmpo.nstarp\n");
      for(i=0iolzFArg; i++){
  const char ods->x&smporp\n");
 
 /*\n");
 
 

/*id w StoxForF on end-of beAGMAinpnde strny/ite3_cs?\n");
 
 

/If sozFilop e ag to :fl NOT d-olf ha  i* egonsf haite3_cs.\n");
 
 
ime */
   +;
  =b[0]!=ine[h]==0 ) break;
 
 /*\n");
 
 

/*id w StoxForF on end-of ORrF on ennput liAGMAinpnde strny\n");
 
 

/ite3_csr nod of A( p-? /If sozFilop e ag to :fl NOT d-olf h\n");
 
 

/  i* egonsf haite3_cs.\n");
 
 
ime */
   +;
  if( p->mode==AECL rrg>1zf( c2==ile( z0)0]!=ine[h]==0 ) break;
 
 
    sqlite3_bind_t1, &pSert, z,      -1, SQEGIN IENTrp\n");
 
 );
  =0iol-&& n>1mpo.  p->!=smpo.= p->cC>) i++){
  c
      utf8_printf(stde%s:rroreD\n Exp %d/ite3_csrb outumnp %d/- aster"
                     "d-olf ha  i* estegins  NOT [%s]\n",
                 
 
 
mpo.zzDes, 
le, star,20 p-nsert, i+1);
     
    i +=         
    whi<=n p- ){ 
    sqlite3_bind_n1, &pSeQuery){ h++; }
        }
     );
 
   1mpo.  p->==smpo.= p->cC>) i++){
  cdo rc ){
     ods->x&smporp\n");
 
  ery){++; }
    
    wh1mpo.  p->==smpo.= p->cC>)p\n");
 
      utf8_printf(stde%s:rroreD\n Exp %d/ite3_csrb outumnp %d/- aster"
                   "2 ** z[] is ig [%s]\n",
                 
 
mpo.zzDes, 
le, star,20 p-nserg[1]);
      }
 );
  >=n p- ){reak;
 
 
    sqlite3_step(pp\n");
 
 z    rc = sqltput_retep(pp\n");
 
 
    if( rc!=SQLITE_OK ){
 
 
      utf8_printf(stde%s:rror    "INfaDesror %d: %s
mpo.zzDes,]\n",
                 
le, star,2\n", sqlite3_errmsg(pa    );
        }
     ); 
    wh1mpo.  p->le( c!);l    }o*
** r( mpo.Exup\n");     sqlite3_smpo.z     );     sqlite3_finalize(pStmt);
    eedCetand )      sqlite3_exec(p-o" : "C=OFF;", 0, 0, 0)out, "ly one character(.
**
**     [...]   ndectabases", ]\n",
            2==.
**
**     [...]   ndf in"save", nn)==0 ){
    ShellState data;
    char *zErrMsg = 0;
    open_db(p, 0);
    memcpy(&data, p, sizeof(data));
    data.showHeader = 0;
    data.cMode = data.mode = Li *pDest;
    if( nArg==1 ){
      rc = sqlite3_exec(p->db,
        "SELECTT sql FROM sqlite_master "
        "WHERE type='iTNULL AND name NOT LIKE 'sqlite_%' "
   "ster UNIOte_%' "
   "    "SELECTT sql FROM sqlite_temp_master "
        "WHERE type='iTster "
        "ORDE_stat1",
        callback, &data, &zErrMsg
      );
    {
    if( nArg==2 ){
      zShellStatic = a1Arg[i];
      rc = sqlite3_exec(p->db,
        "SELECTT sql FROM sqlite_master "
        "WHERE type='iTNULLHERE tbl_name LIKE shellstate_%' "
   "ster UNIOte_%' "
   "    "SELECTT sql FROM sqlite_temp_master "
        "WHERE type='iTNULLHERE tbl_name LIKE shellstate_%' "
   "    "ORDE_stat1",
        callback, &data, &zErrMsg
      );       zShellStatic = 0;
    }else{
      raw_printf(stderr, "Usa ndf in.dump ?LIKE-PATTERN?\n");
      rc = 1;
      goto meta_command_exit;
    }
    if( zErrMsg ){
      utf8_printf(stderr,"Error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      rc = 1;
    {
      !=  rc!=SQLITE_OK ){
      raw_printf(stat4",
            derr,"Erdump_f haFROM sqlite_ma CSVFROM sqlite_temp_mn|off\n");
      rc = 1;
    }
  }e' )
#ifndef SQENABLL_IOEGICE"ly one character.
**
**     [...]   o** c"clone", n)==0 ){ndef SQAPI 2 * pate,
  vhar *SQLITE_C*     sqIoT* c")wDb, (const , r(k=pDest;
    o** c"0]!=io** c"!=sntf(s ) fite3_(io** c"=pDest;
o** c"0nErr = 0;
    if(<Arg==2 ){
      sqIoT* c"plain = 0;
    }else if( strcmp(azAritiaauto")==0 ){
      sqIoT* c"pla
o** c"*
** f    );
  o** c"0nEut = std= 0;
    }else{
  o** c"0nEfite3_rcmp(azAritw"a    );
  (   o** c"uto")==0 ){
        utf8_printf(stderr, "Error: cannot open \"%s\"alue(azArg[1]);
 
      sqIoT* c"plain = 0;);
      rc = 1;
      }else{
        sqIoT* c"pla
o** c"*
** f    );
 } = 1;
    }
  }me);
#end one chalc=='c' &5cter.
**
**     [...]  liandeaders", n)==0 ){};
  static const strelse{
       const chLiandar *zN\n]    /* Nama liand 
ime */
   
*/liandCrmal            ]   >an into_uncatedcess thand 
ime */} aLiandQuery[] = {

   otal(lsion:",           har *SQLIITE_LENGTHon:",           e */},] = {

      _otal(lsion:",       har *SQLIITE_har_LENGTHon:",           },] = {

   ite3_csion:",           har *SQLIITE_COLUMNon:",           e */},] = {

   eD\r_dep(lsion:",       har *SQLIITE_EXPR_DEPTHon:",           },] = {

   itmpumnp_seln Esion:",  har *SQLIITE_COMPOUND_    "SE          },] = {

   vdbe_opsion:",          har *SQLIITE_VDBSQLPn:",           e */},] = {

   funedire_argsion:",     har *SQLIITE_FUNRANSA_ARG          e */},] = {

   attult dsion:",         har *SQLIITE_IKEACHED:",           e */},] = {

   like_ the pa_otal(lsion:har *SQLIITE_Lmp _LIKE-PA_LENGTHon:",  },] = {

   vari writ  { "nsion:",  har *SQLIITE_VARIABLL_NUMB "O      e */},] = {

   ex','tr_dep(lsion:",    har *SQLIITE_TRIGGER_DEPTHon:",        },] = {

   worktr_th csvssion:",   har *SQLIITE_WORKER_THREADSn:",        },] = {}r = 0;
tic inn2g = 0;
    open_db(p, 0);
    if( nArg==1 ){
  }
  for(i=0; i<ArraySLiand)zFArg; i++){
  cte3_mpr>%, "%-20s %d\LiandQueryLiandar *tat4",
               sqlthand_exec(p-\LiandQuerliandCrma,   )rg[1]);
      }
    {
    if(>3rg!=1 ){
      raw_printf(stderr, "Usathand  FILE?NEW-%s\" TTERN?\n");
      rc = 1;
      goto meta_command_exit;
    }else{
      Liand   -rc = 1;
 n2 
  n = strlen30(azArg[1]);
  }
  for(i=0; i<ArraySLiand)zFArg; i++){
  celse  && sqlitrni
**  LiandQueryLiandar *tcase, azArgn2b-1,z)==0 ){
      (   Liand<,z)==0 ){
        Liand   i;=0 ){
          }else{
            utf8_printf(stdeambiguous thand: open \"%s\"alue(azArg[1]);
 
 );
      rc = 1;
 = 1;
      goto meta_command_exit;1]);
      });
      });     }
 );
  Liand<,z)==0 ){
        utf8_printf(stderr, "unkthand: open \"%sster"
                   "2seen opathande \"gins no many argumatedalosed  [%s]\n",
                 
 
alue(azArg[1]);
 
      rc = 1;
 =      goto meta_command_exit;1]     }
 );
  if( n3 ){reak;
 
 
    sqlthand_exec(p-\LiandQuLianderliandCrma,]\n",
                 rc = (int)integerValue(a2])rg[1]);
      } cte3_mpr>%, "%-20s %d\LiandQuLianderyLiandar *tat4",
        
    sqlthand_exec(p-\LiandQuLianderliandCrma,   )rg[1]);
    }
  }e' )

#ifndef SQLITE_LOAD_EXTENSRIZATION
  if(lacter.
**
**     [...]  loadtches one c kwardile(const char *, ch  /* data;
    char *zErrMsg = 0;
    if(<Arg==2 ){
      raw_printf(stderr, "Usatoad */
  ?ENTRY"SAVETTERN?\n");
      rc = 1;
      goto meta_command_exit;
    }zzDestFile = a1Arg[i];z  /* *zDb = n3rg>=2 ? a2Arg[sg = 0;
    open_db(p, 0);     rc = sqltoadlite3_e vere_v2(p->ar *, z  /*&data, &zErrMsg);
    if( rc!=SQLITE_OK ){
      utf8_printf(stderr, "Error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      rc = 1;
    }
  }else
#endif

  if(lacter.
**
**     [...]  log"auth", n)==0 ){
    if( nArg!=2 ){
      raw_printf(stderr, "Usalogclone FILENAME\n");
      rc = 1;
    }else{
 dile(const char *tatic = a1Arg[i];
 
    output_file_clospLoErrMsg);
 lospLoEtat
    output_ite3_ozDesup\n");
    }
  }else

  if(macter.
**
**     [...]  datatches one c kwardile(const chata.cMoDb = nArg>=2 ? azArg[1"r = 0;
ticn2 
 rc =  n = s(hata.)r = 0;
tic     hata.f0]tFile;     if( lc=='c'2>2cter.
**
**     [.zArgnputssin2b-1,z)==0 ){
      p->mode = starp\n");
    }else 2if( c=='c' && strncmp(azArgite3_cssin2b-1,z)==0 ){
      p->mode = MODE_Column;
    }else 2if(lc=='c'2>2cter.
**
**     [.zArgnpstsin2b-1,z)==0 ){
      p->mode = ststolumn;
    }else 2if( c=='else

  if( c==zArghtmlsin2b-1,z)==0 ){
      p->mode = Htmlolumn;
    }else 2if(tc=='else

  if( c==zArgtclsin2b-1,z)==0 ){
      p->mode = TclrMsg);
      sqlite3_snpr, p, si     ->cCw sepas,ode   ->cCw sepa,  "P_& !Is     );
    {
    2if( c=='c' && strncmp(azArgisvsin2b-1,z)==0 ){
      p->mode = MsvrMsg);
      sqlite3_snpr, p, si     ->cCw sepas,ode   ->cCw sepa,  "P_CetaarrMsg);
      sqlite3_snpr, p, si   rp->cRw sepas->outrp->cRw sepa,  "P_CrLfaolumn;
    }else 2if(tc=='else

  if( c==zArgtabssin2b-1,z)==0 ){
      p->mode = ststrMsg);
      sqlite3_snpr, p, si     ->cCw sepas,ode   ->cCw sepa,  "P_chemaTab);
    }else 2if(racter.
**
**     [.zArgi>out,sin2b-1,z)==0 ){
      p->mode = MODE_Insert;
 ite3A writ tblmmand(p, n3rg>=2 ? a2Arg["A wri"maTab);
    }else 2if( c=='a' && strncmp(azArg[ECL sin2b-1,z)==0 ){
      p->mode = AECL rMsg);
      sqlite3_snpr, p, si     ->cCw sepas,ode   ->cCw sepa,  "P_UnitrrMsg);
      sqlite3_snpr, p, si   rp->cRw sepas->outrp->cRw sepa,  "P_RecordmaTab);
    }!=2 ){
      raw_printf(stdeerr,"Erm p->shouldts tther f: aster"
    g[ECL a The coisv html i>out,input osed tabs tcln|off\n");
      rc = 1;
   
     ormalMode = p->mod }
  }else

  if(nacter.
**
**     [...]  bindsg() aders", n)==0 ){
    if( nArg==2 ){
      sqlite3_snpr, p, si   bindtegers->outbindtegers]\n",
                 
"%.*ssiorc = 0; i<Array   bindtegers    alue(azArg[1]);
    }else{
      raw_printf(stderr, "Usabindsg()  STRINGn|off\n");
      rc = 1;
    }
  }else

  if(oacter.
**
**     [...]  ite3aders", n='c' &Arg==2 ){onst chaewink(zFil;\n]    /* Naml t  ", "data.txt r, nnot ab kwar
tic   /*   rc      
]   >dexbyte    [.] Naml t fnk(zFillab kwar
tic ewFlaErrMsg    
]  Tr -- dud
** Ded-of beAGMAinnote stab kware

 te3_ie at xsede st ", "dataab kwar ese ve_file__and_n     );     sqlfile_closg(pr = 0;losg( hema = 0;
    sqlite3_\n",Fte3On te3_pr = 0;los,Fte3On te3_ hema = 0;e

 e: .catedas a command-many argumab kwar }
    /*for(i  /*=1; in='cic = az  /*]le( z[0]r(i  /*rg; j++){
      const char *z = az  /*]    );
  (  2 && optionMz," ew"rg[1]) ){
    ewFlaErrMturn 1;
      }else if( z[0]=='-' ){
        utf8_printf(stderr, "unknown option: %szrg[1]);
 
      rc = 1;
 =      goto meta_command_exit;1]     }} = 0;e

*
** fnk(zFillrrorpecified,     r, nnot iut.trsd 
ime */haewink(zFilcMoDb =    /* ?Tab = sqlite3_mprintf("*z = az  /*])rg[sg = 0;else aewink(zFilc==99 ){
      ewFlaEr)/
int shellDelete aewink(zFilrrMsg);
 loszDbink(zFilcMohaewink(zFil;g[i];
 
    open_dt, i+1);
 +;
  ifdf( zDb==0 ){
        utf8_printf(stderr, "Error: cannot '%s'n: %szaewink(zFilrrMsg);
 
      sqlite3_faewink(zFilrrMsg);
      }else{
      ,Fte3On te3_ hehaewink(zFil;g[i];
      }
    }
    ifdf( zDb==0 ){
    Acausfand-ying nnot a TEMPt ", "dataab kwar
 loszDbink(zFilcMo0;g[i];
 
    open_d, 0, 0);
    }
  }else

  if(oa, 0)ter(.
**
**     [...]  
    oaders", n2==.
**
**     [...]  onc "save", n)==0)
  ){
    const char *tatDb = nArg>=2 ? azArg[1ut = s"g = 0;elseDb = 2TE_OK ){
      utf8_printf(stderr, "UsacaseILLENA,  c = azAN?\n");
      rc = 1;
      goto meta_command_exit;
    }
   ' && n>1 && strncmp(azArg[onc "save", c==99 ){
      if(<Arg==2 ){
 
      raw_printf(stderr, "Usaonc seILLENArg[1]);
 
      rc = 1;
 =      goto meta_command_exit;1]     }
 ";
   Cumn_   rc = 2;
    }else{
 ";
   Cumn_   ma = 0;
    }
    output_reset(p);
   zzDestfile[0]=='|' )
#ifndef SQLITE_OMIT_POPEN
      raw_printf(stdeerr,"Erpip tabreit issup  Mansign i at OSackup\n");
      rc = 1;
 ";
   0nEut = std(z);
#elile;";
   0nEpite3_ozDes + 1ritw"a    );
  (  ";
   ( zDb==0 ){
        utf8_printf(sterr, "Error: cannot pip  open \"%s\"\zDes + 1rg[1]);
 
 ";
   0nEut = std1]);
 
      rc = 1;
      }else{
        sqlite3_snpr, p, si   = sfnk(s->out= sfnk(   shell_zDesup\n");
 }ame);
#end);
    }else{
 ";
   0nE
    output_ite3_ozDesup\n");
  (  ";
   ( zDb==0 ){
   else if( st>ar *,"off"z++)))!=0 ){
          utf8_printf(sterr, "Error: can", "w   open \"%s\"\zDestFile);
 
      });
 ";
   0nEut = std1]);
 
      rc = 1;
       }!=2 ){
        sqlite3_snpr, p, si   = sfnk(s->out= sfnk(   shell_zDesup\n");
 }a);
 }a); }
  }else

  if(pc=='c' && n>=3 && strncmp(azArg[e3_snplain", n)==0 ){
    rMsg);     for(i=1; i<nArg; i++){
 );
  >val==1 ) raw_printf(p->ou"a    );
  
= 1;
   t4";
      shellic = azAmt, 0 {
    }
    raw_printf(p->out, "\n")}
  }else

  if(pc=='c3 && strncmp(azArg[e3omp "exit", n)==0 ){
    if( >  r)}!=2 ){
 3 && py(gonsP3omp ,ncmp(azArrc = 0; i<ArraygonsP3omp s  set(p);
    }
    if( >  3)}!=2 ){
 3 && py( theinueP3omp ,ncmp(a2Arrc = 0; i<Array theinueP3omp s  set(p);
   )}
  }else

  if(qc=='c3 && strncmp(azArg[qu, "exit", n)==0 ){
    rc = 2;
  }else

  if(rc=='c' && n>=3 && strncmp(azArg[ csv"exit", n)==0 ){*/
  *al*pDest;
    if( nArg!=2 ){
      raw_printf(stderr, "Usae to eILLENArg[1]);
      rc = 1;
      goto meta_command_exit;
    }al*0nEfite3_rcmp(azAritrber;\n");
   al*ackup==0 ){
      utf8_printf(sterr, "Error: cannot open \"%s\"alue(azArg[1]);
      rc = 1;
    }else{
      s to pr_athe CloneltrrMsg);
 fite3_(eltrrMsg);
   )}
  }else

  if(rc=='c' && n>=3 && strncmp(azArg[ cstGMAtches one c kwardile(const chSrczDestFile;
    const chara = 0;
    sq_stmrca = 0;
    sqlite3_backup *pBackup;
   nTime   0nE0;l    }
    if( nArg==2 ){
   rczDestatic = a1Arg[i];
 =0 ) zDb = "main";
    {
    if( n3rg==2 ){
   rczDestatic = a2Arg[i];
 =0 ) zic = a1Arg[i];
    }else{
      raw_printf(stderr, "Usa cstGMA ?DB? eILLENArg[1]);
      rc = 1;
      goto meta_command_exit;
    }
    rc = sqlite3_o rczDesl, -1exit(rc);
    if( rc!=SQLITE_OK ){
      utf8_printf(stderr, "Error: cannot open \"%s\"\ rczDesrrMsg);
      sqlfile_cl1exit(rc);
      return 1;
    }
    open_db(p, 0);
    pBackup = sqlite3_backup_in", p->db->o1expDest, "it(rc);
    if( pBackup==0 ){
      utf8_printf(stderr, "Error: %s\n", sqlite3_errmsg(pa    );
      sqlfile_cl1exit(rc);
      return 1;
    }     whie(  (rc = sqlite3_backup_step(pBackup,100))==SQLI=0 ){
     2== if( rc==SQBUSY c==99 ){
      if( rc==SQBUSY b==0 ){
   elsenTime   ++ >  3h]==0 ) break;
 
 
    sqlsleup_ckup;g[i];
      }
    }rc = sqlite3_backup_finish(pBackup);
    if( rc==SQLITE_DONE ){
      rc = 0;
          if( rc==SQBUSY 2== if( rc==SQLOCKED))==0 ){
      raw_printf(st derr,"Ersourct  ", "dataisrb syENAME\n");
      rc = 1;
    }else{
      utf8_printf(stderr, "Error: %s\n", sqlite3_errmsg(pa    );
      rc = 1;
    }
    sqlite3_cl1exit(rc)}
  }eelse

  if(sc=='c3 && strncmp(azArg[sror};
 eaders", n)==0 ){
    if( nArg==2 ){
     ror};
 e>echoOn = booleanValue(azArg[' )

#ifndef SQENABLL_STMT_SCAN* NoUS=0 ){
      raw_printf(st dWarte sUsa ror};
 eit istles availgn i at build.ENAME\me);
#end);
    }else{
      raw_printf(stderr, "Usa ror};
 eiders on|off\n");
      rc = 1;
    }
  }else

  if(sc=='c3 && strncmp(azArg[srullschema", n)==0 ){
    ShellState data;
    char *zErrMsg = 0;
    open_db(p, 0);
    memcpy(&data, p, sizeof(data));
    data.showHeader = 0;
    data.cMode = data.mode = MODE_Semi;
    if(>nArg==2 && optionMatch(azArg[1], "indent") ){
      data.cMode = data.mode = MODE_Pretty;
     --p\n");
  (   if( nArg>=2 ? azAratic = a2Arg[i];}=0 ){
    if( nAr='cic = a1] zStr[0]!==99 ){
      int i;
      f0;cic = a1] i]<nArg;cic = a1] i]ratToLower(ic = a1] i]up\n");
  (   if( strcmp(azArgFROM sqlite_mab-1,z)==0 ){
   
    cnew_argva2Ar cnew_colva2Arg[i];
    ew_argvaidth[erREAT  TABLL FROM sqlite_ma("%sster"
                 "  sql, text,"%sster"
                 "   tbl_next,"%sster"
                 "  ype, tbl_next,"%sster"
                 "  rootpagt lint)in,"%sster"
                 "   ANDnext"%sster"
                 ")"rg[i];
    ew_argva1e[h++] = 0;
    ew_colvaidth[e AN"] = 0;
    ew_colva1e[h++] = 0;
        calemcpy(&d1,  ew_argv,  ew_colvrg[1]);
 
      0))==SQLIc = 1;
        (   if( strcmp(azArgFROM sqlite_temp_mab-1,z)==0 ){
   
    cnew_argva2Ar cnew_colva2Arg[i];
    ew_argvaidth[erREAT  TEMPtTABLL FROM sqlite_temp_ma("%sster"
                 "  sql, text,"%sster"
                 "   tbl_next,"%sster"
                 "  ype, tbl_next,"%sster"
                 "  rootpagt lint)in,"%sster"
                 "   ANDnext"%sster"
                 ")"rg[i];
    ew_argva1e[h++] = 0;
    ew_colvaidth[e AN"] = 0;
    ew_colva1e[h++] = 0;
        calemcpy(&d1,  ew_argv,  ew_colvrg[1]);
 
      0))==SQLIc = 1;
      ==0 ){
        zShellStatic = a1Arg[i];
 
      rc = sqlite3_exec(p->db,
          "SELECT sql iew')"
          "  (SELECT sql sql, type type, tbl_name tbl_name, name name, rowid x"
          "     FROM sqlite_master UNION ALL"
          "   SELECT sql, type, tbl_name, name, rowid FROM sqlite_temp_master) "
          "Wlower(ype, tbl)_name LIKE shellstat ALL"
          "  AND type!='meta' AND sql NOTt ALL"
          "ORDER BY rowid",
          callback, &data, &zErrMsg);
        zShellStatic = 0;
      }
    {
    if( nArg==1 ){
      rc = sqlite3_exec(p->db,
         "SELECT sql iew')"
         "  (SELECT sql sql, type type, tbl_name tbl_name, name name, rowid x"
         "     FROM sqlite_master UNION ALL"
         "   SELECT sql, type, tbl_name, name, rowid FROM sqlite_temp_master) "
         "WHERE type!='meta' AND sql NOTNULL AND name NOT LIKE 'sqlite_%' "
         "ORDER BY rowid",
         callback, &data, &zErrMsg
      );
    }else{
      raw_printf(stderr, "Usa rullschema ?--in.dump ?LIKE-PATTERN?\n");
      rc = 1;
      goto meta_command_exit;
    }
    if( zErrMsg ){
      utf8_printf(stderr,"Error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      rc = 1;
    {
      !=  rc!=SQLITE_OK ){
      raw_printf(stderr,"Erdump_f haFrullscll_drma&& oENAME\n");
      rc = 1;
    }else{
      rc = 0;
    }
  }e' )  Thinedvhar *SQDEBUG)0]!= Thinedvhar *SQENABLL_S"   SEGICE)else

  if(sc=='cn nA&& n>1 && strncmp(azArg[seln E** c"clone", n)==0 ){     sqSeln ET* c"pla
int)integerValue(azArt(rc)}
  }else
#en' )  Thinedvhar *SQENABLL_S"SSRIZ)else

  if(sc=='c1 && strncmp(azAr" ese ve",rs", n='c' &3rg==2 ){O   Sese ve_stmese ve_= &    mese vef0]tFile;
    c*azCm* =C&ic = a1Arg[i];     Sr *zRes = 0;
tic im* =C if( -ial = 1;
    int i;     if(<nArg       ese ve_syntaxil_on_g = 0;
    open_db(p, 0);
    if(>n3rg==2 ){
      Sr for(iSr <   bmese ver(iSr rg; i++){
  celse 
*
**     mese vefiSr ].zar *tcase, azA)ne[h]==0 ) break;
      }
 );
  Sr <   bmese ve")==0 ){
    mese ve_= &    mese vefiSr ]rMsg);
   azCm*y){++; }
    im*--p\n");
      }else{
    mese ve_= &    mese vef0]tFile; }
 )Sr *zRes = 0;
      }
     }/*sa ese ve_attulttTABLL    }

/Invok_ie at     sq ese ve_attult()a
intrf c"p   attultta parllSula order
  tavailsodcess , if inev_mafilntriolated.
ile */
    if( strcim*azAr"attult"e", c==99 ){
      im* nArg       ese ve_syntaxil_on_g = 0;);
    mese ve->p-1,z)==0 ){
    ese ve_notlite3:g[i];
 
      raw_printf(st deRROR:, "/ ese vetabreiite3ENAME\n");
      }else{
        rc = sq ese ve_attult( mese ve->p, azCm*azArg[1]);
 
 
    if( rc ){
 ){
      raw_printf(st deRROR:,     sq ese ve_attult()a     r"%-20s %dexit(rc);
 
        +] = 0;
        }
     ); }
  }els }/*sa ese ve_ge: .chea */
 order
  a ese ve_ptionhea */
 order
  W", "wa_ge: .chea or_ptionhea line * fnk(ratorDed-of f iov_mn", tenlated.
ile */
    if( strcim*azAr"ge: .chea"s", n2==.
*( strcim*azAr"ptionhea"e", c==99 ){
 */
  *   0nE0;l9 ){
      im* nArg       ese ve_syntaxil_on_g = 0;);
    mese ve->p-1,z)       ese ve_notlite3g = 0;);   0nEfite3_rcCm*azAritwb"a    );
  (     ( zDb==0 ){
        utf8_printf(st deRROR:,ror: cannot open \catedn", f h"%s\"alCm*azArg[1]);
      }else{
    
*/
zChng] = 0;
   e,
  *pChng] = 0;
   
   acim*azAtfile[c'f( rc ){
 ){
      rc = sq ese ve_ge: .chea( mese ve->p, &
zChngl, -ChngtFile);
 
      }else{
          rc = sq ese ve_ptionhea( mese ve->p, &
zChngl, -ChngtFile);
 
  [1]);
 
 
    if( rc ){
 ){
 te3_mprierr,"Er, no eo_unc-20s %dexit(rc);
 
        +] = 0;
        }
 );
    Chng(rc);
 
   ='cfn", "(pChngl,
zChngl,1,    ) nArg!=1 ){
 
        raw_printf(st deRROR:,FaDesrp   n", "w--iirnc-2-r ofE
    o [%s]\n",
             
zChngtFile);
 
  [1]);
 
 
    sqlite3_\ChngtFile);
 
 fite3_(   )c = 0;
      }
    }els }/*sa ese ve_gte3_order
   te3_ie ati?--iified  ese veated.
ile */
    if( strcim*azArg[0],se"e", c==99 ){
      im* nArg       ese ve_syntaxil_on_g = 0;
  (  ";
bmese ve")==0 ){
    ese ve_file_( mese verg[1]);
 
 ";
 mese vefiSr ]lMode  mese vef--";
bmese ve]c = 0;
      }
    }els }/*sa ese ve_enavail?BOOLEAN?order
  Qump_ or_r t c at navailflagated.
ile */
    if( strcim*azArg[ navai"e", c==99 ){
      i;l9 ){
      im*>Arg       ese ve_syntaxil_on_g = 0;);
i =C im* nAr? -1 :oOn = booleanValCm*azArg[1]);
  (  ";
bmese ve")==0 ){
   
i =Crc = sq ese ve_ navai( mese ve->p, iirg[1]);
 
  
= 1;
   t4";
       ese ve_%st navailflag =C%g [%s]\n",
                mese ve->zar *tcierg[1]);
      }
    }els }/*sa ese ve_filntr name ....order
  S t alosed Namname  the pas Namlavail ANDraints texcludiolated.
ile */
    if( strcim*azAr "d-op_mab-1,z)==0 ){
      i,c Byt*zl9 ){
      im*<Arg       ese ve_syntaxil_on_g = 0;);
    ;
bmese ve")==0 ){
         for(ii< mese ve->nF-op_mr(iirg; i++){
  c
 
    sqlite3_\mese ve->azF-op_m[ii]tFile);
 
  [1]);
 
 
    sqlite3_\mese ve->azF-op_mtFile);
 
 nByt* rS  p, si mese ve->azF-op_m[0])*( im*-1rg[1]);
 
 "mese ve->azF-op_m zSql = sqlite3_ml}nByt* rg[1]);
 
 
   "mese ve->azF-op_m-1,z)==0 ){
          raw_printf(st derr,"Errr, "rut of memory\n");
     =0 ) 1tFile);
 
  [1]);
 
       f1r(ii< im*r(iirg; i++){
  c
 \mese ve->azF-op_m[ii-1e[h+ab = sqlite3_mprintf("*zim*aii]tFile);
 
  [1]);
 
  mese ve->nF-op_mpla
i-rc = 1;
      }
    }els }/*sa ese ve_ ndern El?BOOLEAN?order
  Qump_ or_r t c at ndern Elflagated.
ile */
    if( strcim*azArg[ ndern E"e", c==99 ){
      i;l9 ){
      im*>Arg       ese ve_syntaxil_on_g = 0;);
i =C im* nAr? -1 :oOn = booleanValCm*azArg[1]);
  (  ";
bmese ve")==0 ){
   
i =Crc = sq ese ve_ ndern E( mese ve->p, iirg[1]);
 
  
= 1;
   t4";
       ese ve_%st ndern Elflag =C%g [%s]\n",
                mese ve->zar *tcierg[1]);
      }
    }els }/*sa ese ve_isemptyorder
  Dep_mmand- (0) i* ese ve_is emptyorder
ile */
    if( strcim*azArg[ sempty"e", c==99 ){
      i;l9 ){
      im* nArg       ese ve_syntaxil_on_g = 0;
  (  ";
bmese ve")==0 ){
   
i =Crc = sq ese ve_ sempty( mese ve->prg[1]);
 
  
= 1;
   t4";
       ese ve_%st semptyinlag =C%g [%s]\n",
                mese ve->zar *tcierg[1]);
      }
    }els }/*sa ese ve_osedorder
  ststopac curdifelyannot  ese vetated.
ile */
    if( strcim*azAr"npstse", c==99 ){
  }
  for(i=   bmese ver(irg; i++){
  c 
= 1;
   t4";
      sdrror: %si, ";
 mese vefi].zar *rg[1]);
      }
    }els }/*sa ese ve_nnot DB  FILorder
  Onot a new* ese ve_    ed  FILEonot inattult d  ", "dataDB.order
  DB f in p->nlyaest, "lated.
ile */
    if( strcim*azAr"ite3aauto")==0 ){
 onst chNFil;g[i];
      im* n3rg       ese ve_syntaxil_on_g = 0;
 z  /*   rcim*a2]    );
  (  z  /*le( z0rg       ese ve_syntaxil_on_g = 0;
  }
  for(i=   bmese ver(irg; i++){
  celse 
*
**     mese vefi].zar *tzar *r-1,z)==0 ){
          utf8_printf(st dmese ve"open \cale toyt xsedor: %s\ar *rg[1]);
          goto meta_command_exit;1]);     });     }
 );
    bmese ve>=0; i<Array    mese verg[1]) ){
        raw_printf(st dMaximum Nam%d  ese veor: %s0; i<Array    mese verrg[1]);
        goto meta_command_exit;1]     }
 "mese ve_= &    mese vef";
bmese ve]c = 0;
      rc = sq ese ve_gnot c_exec(p-\cCm*azAri& mese ve->prg[1]);
 
    if( rc ){
 ){     raw_printf(st dCor: cannot  ese veEr, no eo_un=-20s %dexit(rc);
 
      +] = 0;
        goto meta_command_exit;1]     }
 "mese ve->nF-op_mpla+] = 0;
 rc = sq ese ve_A writd-op_m( mese ve->p,  ese ve_d-op_m,  mese verg[1]);
 ";
bmese vey){++; }
  mese ve->zar *[h+ab = sqlite3_mprintf("\ar *rg[1]);}z);
#elile

*
*; /itta_coL AND mtiones,>show a syntaxs, no error e; ese ve_syntaxil_on_:or e; ese ve_& st(c(p->d>out, else
#en' )
#ifndef SQDEBUG
ile

Undocy arged/itta_coumated
intrnaNDneede s.  Subjn Elablie: .c
er
  ginsrr, : ciceblems. e

  if(sc=='cn>=10& n>1 && strncmp(azArg[selfneed-f("9s", n)==0 ){
   1 && strncmp(azA+9rg[On = boclon-9e", c==99 ){
      , vg = 0;
  }
  for(i=1; i<nArg; i++){
   vchoOn = booleanValue(ai]tFile);
 
  
= 1;
   t4";
      sh:m%d 0x%x"%s\"alue(aiArgvrgvp;g[i];
      }
    }
   1 && strncmp(azA+9rg[
int)inclon-9e", c==99 ){
      ;+ab = sql   64 vg = 0;
  }
  for(i=1; i<nArg; i++){
   onst zBuf[200]tFile; }
 vpla
int)integerValue(aiArg[1]);
 
      sqlite3_snpr, p, sizBuf),zBuftd%s: %lld 0x%llx"%s\"alue(aiArv,vtFile);
 
  
= 1;
   t4";
      shf("\Buf);g[i];
      }
    }
  }else
#endif

  if(sc=='c3 && strncmp(azArg[scRw sepaaders", n)==0 ){
    if(<Ar||  if(>3rg!=1 ){
      raw_printf(stderr, "Usa row separCOL ?ROWTTERN?\n");
      rc = 1;}=0 ){
    if(>nArg==2 ){
      sqlite3_snpr, p, si     ->cCw sepas,ode   ->cCw sepa,]\n",
                 
"%.*ssiorc = 0; i<Array     ->cCw sepas    alue(azArg[1]);
=0 ){
    if(>n3rg==2 ){
      sqlite3_snpr, p, si   rp->cRw sepas->outrp->cRw sepa,]\n",
                 
"%.*ssiorc = 0; i<Array   rp->cRw sepas    alue(a2Arg[1]);
=0  }
  }else

  if(sc[1])ter(.
**
**     [...]  LIKE aders", n2==.
**
**     [...]"system",rs", n)==0)
  ){
nst chCm_na(p);     , x;=0 ){
    if(<Arg!=1 ){
      raw_printf(stderr, "Usa ystemu" : ANDTERN?\n");
      rc = 1;
      goto meta_command_exit;
    }zim* =Cab = sqlite3_mpr 
*
hr(ic = a1],' 's", ? shf:"open \s\"alue(azArg[1]); }
  f2r(i=1; i<nArg; i++){
 zim* =Cab = sqlite3_mpr 
*
hr(ic = ai],' 's", ? sz shf:"sz open \s\]\n",
                 
++){
 zim*llic = azAmt, 0 {
    }x =Caystem(zim*     );     sqlite3_fCm*     );
   xal==1 ) raw_printf(st dmystemuitta_coL     r"%-20s %dx "\n")}
  }else

  if(sc=='c3 && strncmp(azArg[showaders", n)==0 ){};
  static c
nst cazBn =Query[ "off"rg[on"rg[ge: "tderr,"{}r = 0;
tic ;=0 ){
    if( nArg!=1 ){
      raw_printf(stderr, "Usa howTERN?\n");
      rc = 1;
      goto meta_command_exit;
    } 
= 1;
   t4";
      s12.12sError: %"echos\"alBn =Q";
echoOn!=zAN?\n"); 
= 1;
   t4";
      s12.12sError: %"eqps\"alBn =Q";
_seoEQP&3AN?\n"); 
= 1;
   t4";
      s12.12sError: %"explt, "\]\n",
     if( p->mode==Explt,  ?g[on" : ";
_seoExplt,  ?g[_seo" : "off"z?\n"); 
= 1;
   t4";
     s12.12sError: %"0], "headealBn =Q";
data.showH!=zAN?\n"); 
= 1;
   t4";
      s12.12sError: %"datatchdataDescr[ if( p-AN?\n"); 
= 1;
   t4";
      s12.12sEr"]  bindsg() aN?\n");
 
    ouc_ the s4";
        bindtegers;=1 ){
      raw_printf(p->out, "\n"); 
= 1;
   t4";
     s12.12sError: %"
    oad]\n",
        n = strl   = sfnk(s ?g   = sfnk(rg[1ut = s" "\n"); 
= 1;
   t4";
     s12.12sEr"]    -scRw sepaaN?\n");
 
    ouc_ the s4";
          ->cCw sepaset(p);
      raw_printf(p->out, "\n"); 
= 1;
   t4";
     s12.12sEr"]  rp-scRw sepaaN?\n");
 
    ouc_ the s4";
        rp->cRw sepaset(p);
      raw_printf(p->out, "\n"); 
= 1;
   t4";
      s12.12sError: %"};
 eadealBn =Q";
d;
 e>e!=zAN?\n"); 
= 1;
   t4";
      s12.12sEr"]  width"rg[1]); }
   fori<rc = 0; i<Array     -Width)rg== if  -Width i]r!la+]Arg;c!=1 ){
      raw_pr";
      sdr",= if  -Width i]mt, 0 {
    }
    raw_printf(p->out, "\n"); 
= 1;
   t4";
      s12.12sError: % "d-o(zFils\]\n",
           loszDbink(zFilc? loszDbink(zFilcg[1" "\n")}
  }else

  if(sc=='c3 && strncmp(azArg[s;
 eaders", n)==0 ){
    if( nArg==2 ){
     ;
 e>echoOn = booleanValue(azArg[ 0 {
    {
    if( nArg==1 ){
 displty_ ;
 e_exec(p-n_d, 0, 0);
    }else{
      raw_printf(stderr, "Usa ;
 ei?ders oTTERN?\n");
      rc = 1;}=0 )}
  }else

  if(tc=='cn>&& n>1 && strncmp(azArg[A wrieaders", n)==0 ){}    sqlite3_stmt *;
  ){
nst ccazResul*pDest;
tic Rowand(e3_m;
  ){
nst char *zSes = 0;
tic i;l9 ){
    open_db(p, 0);     rc = sqlite3_prepare_v2(p-"PRAGMA  ", "dat_npstsizSql, -1, &pStmt, 0 {
    if(      re
int s", "daterr,"closg(pr #elile

Cnot craRun an t
 nforce   dump_catedceelosed NamA wrier not i#elil
  st, a CSVpac attult d  ", "dats whereot intavail AND mtionesot i#elil
   NOT  the paoOnmnp    vari wri "?1".error e;har *zSql = sqli raw_pr]\n",
        "SELECTT sql FROM sqlite_me_%' "
   "     "WHERE IN ('tavai','view')e_%' "
   "  TNULL AND name NOT LIKE 'sql%'e_%' "
   "  TNULL AND  NOT ?1"mt, 0 {     whhar *Stmt && sqlite3_step(pf( rc==SQROW")==0 ){
 o    const charar *[h+wDb, (const )
    sqlite3_cobind_t1, &pSt, i+1);
 +;
 harar *", n2==.
*( stharar *,est, "i z0rg  theinue i+1);
 +;
 .
*( stharar *,eliteab-1,z)==0 ){
   har *zSql = sqli raw_pr]\n",
            "sz ster UNIOte_%' "
            "    "SE'lite.'r||  ECTT sql FROM sqlite_temp_me_%' "
            "     "WHERE IN ('tavai','view')e_%' "
            "  TNULL AND name NOT LIKE 'sql%'e_%' "
            "  TNULL AND  NOT ?1"p->db,rg[1]);
      }else{
   har *zSql = sqli raw_pr]\n",
            "sz ster UNIOte_%' "
            "    "SE'%q.'r||  ECTT sql INTw \.FROM sqlite_me_%' "
            "     "WHERE IN ('tavai','view')e_%' "
            "  TNULL AND name NOT LIKE 'sql%'e_%' "
            "  TNULL AND  NOT ?1"p->db,, harar *, harar *p;g[i];
      }
    }     rc = sqlite3_finalize(pStmt);
   har *Stm if( rc==SQLITE_OK ){
 har *zSql = sqlite3_mpr>sz     "ORDE_st->db,rg[1]);
 
   har *)      rc = sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0 {
    }
    sqlite3_free(zSql);
   !har *)      re
int Nomemerr,"cmt, 0 {
    if(      re
int s", "daterr,"closg(pr #elile

Runot inn an t
 nforceite3_prd byot inabove b3_mk. StGMA   i* esul*s#elil
  asraRua; i< Nambin-p_mmanalloc the ssbyte  Resul*[].d.
ile */ Row =C ie3_m*zSes = 0;  Resul* rMsg = 0;
    if(>Arg!=1 ){
 rc = sqlite3_bind_t1, &pS1tcase, azArg     -1, SQEGIN IENTrp\n");
    }else{
  c = sqlite3_bind_t1, &pS1tc"%"rg     -1, SQ* NoICmt, 0 {
    }
    wh1 && sqlite3_step(pf( rc==SQROW")==0 ){
 
    Row>= ie3_m*)==0 ){
   
    ccazNewFile);
 
 
ticn2 
  ie3_m*2 + 1+] = 0;
   azNew   rc = sqlnote3_mall  Resul*ta, p, si  Resul*[0])*n2rg[1]);
 
 
   azNew-1,z)==0 ){
          rint Nomemerr,"cmt, 0 {{{{{{{=0 ) break;
 
  [1]);
 
  ie3_m*zSn2] = 0;
   azResul* rMazNewFile);
  [1]);
   Resul*[ Rowe[h+ab = sqlite3_mprintf("
    sqlite3_cobind_t1, &pS0)rg[1]);
 
   0==  Resul*[ Rowe[( rc ){
 ){     rint Nomemerr,"cmt, 0 {{{{{=0 ) break;
      }
  Rowy){++; }
    }
   1c = sqlite3_finalize(pf( rc!=SQLITE_OK ){
      rint s", "daterr,"closg(pr +; }
 #elile

MODE_P-te3_m   i* theargumNama; i<   Resul*[]      i*
    ochile */
    i", n='c'Row> c==99 ){
     k(zchdaxk(z0nE0;l9 ){
      , j;l9 ){
     n*
**  p-nsn*
** Rowg = 0;
  }
  for(i=0RowgnArg; i++){
   k(z0nE n = strlenResul*[iArg[1]);
 
 
   = s>daxk(z0)hdaxk(z0nEle3g = 0;);     }
  *
**  p-0nE80/(daxk(z+2rg[1]);
 
    *
**  p-<Arg  *
**  p-0nErc = 1;
 n*
** Row[h+w Row +  *
**  p-0-St,/ *
**  p-g = 0;
  }
  for(i=0*
** RowgnArg; i++){
    }
 j=i; j=0Rowgnj+=0*
** Row)==0 ){
     
nst chaBackj=0*
** Row ?g[" : "  "t, 0 {{{{{{{ 
= 1;
   t4";
      sh%-*ssiohaBchdaxk(z\]\n",
                 enResul*[j]rg>=2Resul*[j]:"ory\n");
    [1]);
 
 
    raw_printf(p->out, "\n");
      }
     }      for(ii<0RowgnAArg;c
    sqlite3_enResul*[iiArg[1]);
    sqlite3_enResul* "\n")}
  }else

Begyteprdern Ef ha
    oc     i*fnk(r"needcdat-
  .txt"lems. e

  if(tc=='else
**     [...]"needcdatab-1,z)==0 ){
    output_reset(p);";
   0nE
    output_ite3_"needcdat-
  .txt"mt, 0 {
   ";
   ( zDb==0 ){
      utf8_printf(stderr, "Error: cannot 'needcdat-
  .txt'ut, "\n");}=0 ){
    if(>nArg==2 ){
      sqlite3_snpr, p, si   zTeedcdats->outzTeedcdat   shellic = azArg[1]);
    }else{
      sqlite3_snpr, p, si   zTeedcdats->outzTeedcdat   ?, "\n");}=0 )}
  }else

  if(tc=='cn>=8& n>1 && strncmp(azArg[Aeedcn =aders", n='c'if(>nArg==2 ){};
  static const strelse{
       const chCn =ar *zN\n]    /* Nama need- therp-02 && o 
ime */
   
*/cn =Crmal            ]   >an into_uncatedcess 2 && o 
ime */} aCn =Query[] = {

   prng_savesion:",         -1, SQEESTCTRL_PRNG_SAVE              },] = {

   prng_ cstGMAtch,         -1, SQEESTCTRL_PRNG_RESTORE           },] = {

   prng_ cset"ion:",       har *SQEESTCTRL_PRNG_RESESE            },] = {

   bitvec_need"ion:",      har *SQEESTCTRL_BITVECQEEST            },] = {

   faul*_e aga: "td",      har *SQEESTCTRL_FAULT_IN* NIOt         },] = {

   benignlite3_m_hookssion:har *SQEESTCTRL_BENIGN_MNIOOC_HOOKS    },] = {

   pende s_r oftch,         -1, SQEESTCTRL_PENDING_BYTE           },] = {

   asout,si                 -1, SQEESTCTRL_AS  "INNNNNNNNNNNNNNNNN},] = {

   alwayssi                 -1, SQEESTCTRL_ALWAYS                N},] = {

    cservesion:",           -1, SQEESTCTRL_RESERVE               N},] = {

   2 &&miza&& os"td",      har *SQEESTCTRL_OPTIMIZAANSAS         N},] = {

   iskeywordsion:",        har *SQEESTCTRL_ISKEYW                N},] = {

   scrtionite3_m"td",      har *SQEESTCTRL_SCRATCHMNIOOC         N},] = {

   r oford"nsion:",        har *SQEESTCTRL_BYTE    "O            N},] = {

   nev_mlitrrupt"td",      har *SQEESTCTRL_NEVER_CORRUPT         N},] = {

   impote_meion:",         har *SQEESTCTRL_IMPOST "O            N },] = {}r = 0;
ticAeedcn =   -rc = 1;
ticr     es = 0;
tic inn2g = 0;
    open_db(p,#elile

 thvut,iAeedcn = bind 2 && o    value.Vpacow any uniqueeitefix#elil
  Naml t 2 && o ame, ntedalnumerical value.V
ile */ 2 
  n = strlen30(azArg[1]); }
  for(i=0; i<ArraySCn =)<nArg; i++){
 );
 ' && strncmp(azAr aCn =Qi].zCn =ar *rgn2b-1,z)==0 ){
   );
 Aeedcn =<,z)==0 ){
     Aeedcn =   aCn =Qi].cn =Crmal\n");
        }else{
          utf8_printf(stdeambiguous 2 && o ame,: open \"%s\"alue(azArg[1]);
 
 );Aeedcn =   -rc = 1;;;;;;;=0 ) break;
 
  [1]);
      }
    }
   Aeedcn =<,z);Aeedcn =   rc = (int)integerValue(azArg[1]);
   (Aeedcn =<har *SQEESTCTRL_FIRST)r|| (Aeedcn =>har *SQEESTCTRL_LAST)rrMsg ){
      utf8_printf(stderr,"Erinvalid;Aeedcn = nown option: %sic = azArg[1]);
    }else{
  wiionMAeedcn =rMsreak;
 
 e

     sqlAeed_ therp-rc =, 2(p-c =  
ime */
   cdat har *SQEESTCTRL_OPTIMIZAANSAS:me */
   cdat har *SQEESTCTRL_RESERVE: = 1;;;;;;;
    if( n3rg==2 ){
 ;;;;;;
nd 2 & 
 rc =  n tp-rncmp(a2Ar", 0, 0, 00000000000r          sqlAeed_ therp-rAeedcn =, e_v2(p-2 & 0, 00000000000r    raw_pr";
      sdr(0x%08x)0s %dex2%dex2 0, 000000000      }!=2 ){
   ){
      utf8_printf(stderr,"ErAeedcn = %s tak tab se sailgnd 2 && o [%s]\n",
               alue(azArg[1]);
 
 );} = 1;;;;;;;=0 ) brreak;
 
 e

     sqlAeed_ therp-rc =  
ime */
   cdat har *SQEESTCTRL_PRNG_SAVE:me */
   cdat har *SQEESTCTRL_PRNG_RESTORE:me */
   cdat har *SQEESTCTRL_PRNG_RESET:me */
   cdat har *SQEESTCTRL_BYTE    ": = 1;;;;;;;
    if( n2rg==2 ){
 ;;;;;;r          sqlAeed_ therp-rAeedcn = 0, 00000000000r    raw_pr";
      sdr(0x%08x)0s %dex2%dex2 0, 000000000      }!=2 ){
   ){
      utf8_printf(stderr,"ErAeedcn = %s tak tano 2 && os [%s]\n",
                 
 alue(azArg[1]);
 
 );} = 1;;;;;;;=0 ) brreak;
 
 e

     sqlAeed_ therp-rc =, uc =  
ime */
   cdat har *SQEESTCTRL_PENDING_BYTE: = 1;;;;;;;
    if( n3rg==2 ){
 ;;;;;;unsignnsignd 2 & 
 runsignnsignd (int)integerValue(a2])0, 00000000000r          sqlAeed_ therp-rAeedcn =, 2 & 0, 00000000000r    raw_pr";
      sdr(0x%08x)0s %dex2%dex2 0, 000000000      }!=2 ){
   ){
      utf8_printf(stderr,"ErAeedcn = %s tak tab se sailunsignnssster"
                      " gnd 2 && o [%s alue(azArg[1]);
 
 );} = 1;;;;;;;=0 ) brreak;
 
 e

     sqlAeed_ therp-rc =, c =  
ime */
   cdat har *SQEESTCTRL_AS  "I:me */
   cdat har *SQEESTCTRL_ALWAYS:me */
   cdat har *SQEESTCTRL_NEVER_CORRUPT: = 1;;;;;;;
    if( n3rg==2 ){
 ;;;;;;
nd 2 & 
 On = booleanValue(a2])0, 00000000000r          sqlAeed_ therp-rAeedcn =, 2 & 0, 00000000000r    raw_pr";
      sdr(0x%08x)0s %dex2%dex2 0, 000000000      }!=2 ){
   ){
      utf8_printf(stderr,"ErAeedcn = %s tak tab se sailgnd 2 && o [%s]\n",
                       alue(azArg[1]);
 
 );} = 1;;;;;;;=0 ) brreak;
 
 e

     sqlAeed_ therp-rc =, onst c  
im' )
#ifndef SQN_KEYW   me */
   cdat har *SQEESTCTRL_ISKEYW   : = 1;;;;;;;
    if( n3rg==2 ){
 ;;;;;;     const c2 & 
 ic = a2Arg[i];
 000000r          sqlAeed_ therp-rAeedcn =, 2 & 0, 00000000000r    raw_pr";
      sdr(0x%08x)0s %dex2%dex2 0, 000000000      }!=2 ){
   ){
      utf8_printf(st]\n",
                   derr,"ErAeedcn = %s tak tab se sailonst c 2 && o [%s]\n",
                   alue(azArg[1]);
 
 );} = 1;;;;;;;=0 ) brelse
#endi*/
   cdat har *SQEESTCTRL_IMPOST ": = 1;;;;;;;
    if( n5rg==2 ){
 ;;;;;;r          sqlAeed_ therp-rAeedcn =, e_v2(p]\n",
                     ncmp(a2Ar]\n",
                     (int)integerValue(a3])r]\n",
                     (int)integerValue(a4]) 0, 00000000000r    raw_pr";
      sdr(0x%08x)0s %dex2%dex2 0, 000000000     }else{
            raw_printf(stdrr, "UsaAeedcn = impote_m 2(  /* Nnofamlnumemory\n");
     } = 1;;;;;;;=0 ) brreak;
 
 cdat har *SQEESTCTRL_BITVECQEEST:me */
   cdat har *SQEESTCTRL_FAULT_IN* NIO:me */
   cdat har *SQEESTCTRL_BENIGN_MNIOOC_HOOKS:me */
   cdat har *SQEESTCTRL_SCRATCHMNIOOC:me */
   
#iaul*: = 1;;;;;;;     utf8_printf(st]\n",
                 derr,"ErCLIssup  Macatedceedcn = %s : caimple arged [%s]\n",
                 alue(azArg[1]);
 
 );=0 ) break;
      }}=0 )}
  }else

  if(tc=='cn>4& n>1 && strncmp(azArg[Aime   aders", n)==0 ){
    open_db(p, 0); c = sqliusy_Aime   re_v2(p-Db = nArg>rc = (int)integerValue(azArrg[s "\n")}
  }else

  if(tc=='cn>=5& n>1 && strncmp(azArg[Aimeaaders", n)==0 ){
    if( n2rg==2 ){
  navaiTimerchoOn = booleanValue(azArg[ 0 {){
    navaiTimerc n>!HAS_TIMERf( rc ){
 ){     raw_printf(st derr,"ErAimerct istles availon i at aystem.emory\n");
    navaiTimerchoic = 0;
      }
    _OK ){
      raw_printf(stderr, "UsaAimercders on|off\n");
      rc = 1;
    }
  }else

  if(tc=='else

  if( c==zArg[A* c"clone", n)==0 ){
    open_db(p, 0);
    if( nArg!=2 ){
      raw_printf(stderr, "UsaA* c" */
 rs on|off\n");
      rc = 1;
      goto meta_command_exit;
    }
    output_file_closA* c"O  )c = 0;losA* c"O  0nE
    output_ite3_alue(azArg[' ) ! Thinedvhar *SQLITE_EGICE)c n>! Thinedvhar *SQLITE_FLOAANNG_"SAVE), 0);
   losA* c"O  -1,z)==0 ){
      sqlA* c"epare_v2(p-0r", 0, 0, 000
    }else{
      sqlA* c"epare_v2(p- -1, SQEGICL_STMT("
  lA* c"e     calllosA* c"O  )c = 0;}ame);
#end }
  }e' )  -1, SQU  "_AUTHENTICAANSAelse

  if(uc=='else

  if( c==zArg[useaaders", n)==0 ){
    if(<Arg!=1 ){
      raw_printf(stderr, "Usausea SUB" : AND ...n|off\n");
      rc = 1;
      goto meta_command_exit;
    }
    open_db(p, 0);
    if( strcmp(azArglogi3aauto")==0 ){
 
    if( n4rg==2 ){
 
      raw_printf(stderr, "Usausea logi3 U  " PAS W   ENArg[1]);
 
      rc = 1;
 =      goto meta_command_exit;1]     }
      rc = sqlusea_auth--iict c_exec(p-\cmp(a2Ar"alue(a3]\]\n",
                 
++){
        rc =  n = s(alue(a3])rg[1]);
 
    if( rc ){
 ){     utf8_printf(stdeAuth--iict  ve_faDesrpatedusea ion: %sic = a2])0, 0000000     rc = 1;
  , 000
    ;
    if( strcmp(azArgaddaauto")==0 ){
 
    if( n5rg==2 ){
 
      raw_printf(stderr, "Usausea add U  " PAS W    ISADMINENArg[1]);
 
      rc = 1;
 =      goto meta_command_exit;1]     }
      rc = sqlusea_add_exec(p-\cmp(a2Ar]\n",
                       alue(a3]\ rc =  n = s(alue(a3])r]\n",
                       On = booleanValue(a4])rg[1]);
 
    if( rc ){
 ){     raw_printf(stderrer-Add faDesr:c-20s %dexit(rc);
 
      rc = 1;
  , 000
    ;
    if( strcmp(azArgediE"e", c==99 ){
      if( n5rg==2 ){
 
      raw_printf(stderr, "Usausea ediE U  " PAS W    ISADMINENArg[1]);
 
      rc = 1;
 =      goto meta_command_exit;1]     }
      rc = sqlusea_ie: .c_exec(p-\cmp(a2Ar]\n",
                         alue(a3]\ rc =  n = s(alue(a3])r]\n",
                         On = booleanValue(a4])rg[1]);
 
    if( rc ){
 ){     raw_printf(stderrer-EdiE faDesr:c-20s %dexit(rc);
 
      rc = 1;
  , 000
    ;
    if( strcmp(azArgd
** D"e", c==99 ){
      if( n3rg==2 ){
 
      raw_printf(stderr, "Usausea d
** DeU  "ENArg[1]);
 
      rc = 1;
 =      goto meta_command_exit;1]     }
      rc = sqlusea_d
** D_exec(p-\cmp(a2Arg[1]);
 
    if( rc ){
 ){     raw_printf(stderrer-D
** DedaDesr:c-20s %dexit(rc);
 
      rc = 1;
  , 000
    !=1 ){
      raw_printf(stderr, "Usausea logi3|add|ediE|d
** De...n|off\n");
      rc = 1;
      goto meta_command_exit;
    }
  }else
# e

 -1, SQU  "_AUTHENTICAANSA 
imelse

  if(vc=='else

  if( c==zArg[vere ve",ers", n)==0 ){ 
= 1;
   t4";
       -1, "w%s ion:  e
exA* -vere ve-ll_d*/r]\n",
   rc = sqllibvere ve()("
    sqlsourctid() "\n")}
  }else

  if(vc=='else

  if( c==zArg[vfsll_dtches one c kwardile(const charar *[h+ if( n2rg>=2 ? azArg[1b = "main";
    sqlvfs *pVfsp, 0);
   exec(z)==0 ){
      sqltput_ftherp-rin", p->dbar *rg -1, SQFCNTL_VFS_"SAVEERl, -Vfsrg[1]);
 
   -Vfsf( rc ){
 ){     utf8_pr";
      vfs.zar *){
 ){= open \"%s\"-Vfs->zar *it(rc);
 
      raw_pr";
      vfs.iVere ve ){= -20s %d-Vfs->iVere veit(rc);
 
      raw_pr";
      vfs.szOszDest){= -20s %d-Vfs->szOszDesit(rc);
 
      raw_pr";
      vfs.mxPathzFilcMo-20s %d-Vfs->mxPathzFil);g[i];
      }
    }
  }else

  if(vc=='else

  if( c==zArg[vfsnpstsizrs", n)==0 ){}    sqlvfs *pVfsp, 0);}    sqlvfs *pCurdife rMsg = 0;
   exec(z)==0 ){
      sqltput_ftherp-rin", p-1b = "rg -1, SQFCNTL_VFS_"SAVEERl, -Curdife "\n");}=0 ){ }
 pVfs=}    sqlvfslited(b(pd-Vfspd-Vfs=-Vfs->pNexArMsg ){
      utf8_pr";
      vfs.zar *){
 ){= open \ion: %s-Vfs->zar *r]\n",
      -Vfs==pCurdife ? "  <--- CURRENT"cg[1" "\n"
 
      raw_pr";
      vfs.iVere ve ){= -20s %d-Vfs->iVere veit(rc);
      raw_pr";
      vfs.szOszDest){= -20s %d-Vfs->szOszDesit(rc);
      raw_pr";
      vfs.mxPathzFilcMo-20s %d-Vfs->mxPathzFil);g[i];
 
   -Vfs->pNexAf( rc ){
 ){     raw_pr";
      -----------------------------------ut, "\n");
      }
    }
  }else

  if(vc=='else

  if( c==zArg[vfszFils\hes one c kwardile(const charar *[h+ if( n2rg>=2 ? azArg[1b = "main";onst chVfsNFilcMo0;g[i];
   exec(z)==0 ){
      sqltput_ftherp-rin", p->dbar *rg -1, SQFCNTL_VFS FIL&datVfsNFilrg[1]);
 
   hVfsNFilc; i++){
  c 
= 1;
   t4";
      sor: %s\VfsNFilrg[1]);
  }
    sqlite3_fVfsNFilrg[1]);
      }
    }
  }e' )  Thinedvhar *SQDEBUG)0]!= Thinedvhar *SQENABLL_    "EGICE)else

  if(wc=='else

  if( c==zArg[where** c"clone", n)==0 ){     sqWhereT* c"plaDb = nArg>On = booleanValue(azArrg[sxff"\n")}
  }else
#endif

  if(wc=='else

  if( c==zArg[width"lain", n)==0 ){
   j;l9 ){asout,   if(<n0; i<ArrayS( c=) rg[1]); }
 j=1; j=0A in='cj<0; i<Array     -Width)gnj+g; i++){
  if  -Width j-1e[h+rc = (int)integerValue(ajArg[1]);
=0  }
  }els==0 ){ 
= 1;
   t4intf(st derr,"Errr, "unkitta_coLted
ivalid;argy argsEr"i++){
 " open \. Eintr op.& st \cated& st NA,  c = azAN?\n");     rc = }

goto meta_command:
 {
   ";
   Cumn_ ; i++){";
   Cumn_--p\n");
   ";
   Cumn_ z0rg 
    output_reset(p
=0      rerca }

/*
** R    reTRUE- (0a semi  -ve_nccursraRywhereo not i fire(cN;onstacntrs

  Nam the s z[].

im};
  st    kine_fthe = s_semi  -ve(dile(const ch, c = N; i++
tic ;=0  }
  for(i=N<nArg; 
 
   h[iile[;'f(      re1; 
=0      re0a }

/*
** Teed     ee- (0a kinerdilesedow--iirnl< Namwh  ssp c".

im};
  st    _all_wh  ssp c"(dile(const ch; i++ }
 ; ch; z+g; i++){
   IsSp c"(zazANrg  theinue i+1);
   *zle[/c=='ezazAle[*'f( rc ){
 z +  rc = 2; }
    wh*z)ter(*z!e[*'f||ezazA!e[/c)rrM z+g;;     }
 );
 *zle0f(      reic = 0;
 zy){++; }
  theinue i+1);}i+1);
   *zle[-c=='ezazAle[-'f( rc ){
 z +  rc = 2; }
    wh*z)ter*z!e[\n'rrM z+g;;     }
 );
 *zle0f(      re1{++; }
  theinue i+1);}i+1);     reic = 
=0      re1a }

/*
** R    reTRUE- (0ceelosn, typesign israRun anitta_coLp_mmanaltedoceer
** thaRua semi-  -veratorDen anServerm tyk(r"go"nitta_coLisrun "hetood

  asrisot i Otack(r"/".

im};
  st    kine_is meta_comp_mmanalte(dile(const chLine( rc 
    whIsSp c"(zLineazANrgM zLine+g;; ;
 {
   zLineazAle[/c=='e_all_wh  ssp c"(&zLinea1])rrMsg ){     re1;  e

Otack(r
ime }
 {
   ToLower(zLineazANle[gc=='eToLower(zLineazA)ne'o']\n",
    ='e_all_wh  ssp c"(&zLinea2])rrMsg ){     re1;  e

n anServerm
ime }
 {     re0a }

/*
** R    retrue- (0har *isranittp** Den an t
 nforcratR    refa   ;
  it
** ecoum not i middl* Nama  the s    sralLtedC- tyk(rmetaorcr

im};
  st    kine_is metp** D(
nst char , c = nree( i++
ticrca = 
   har le0f(      re1{++;har [nreee[h+[;'{++;har [nree+1e[h++] =      rc = sqlmetp** D(free(zSqlhar [nreee[h++] =      rerca }

/*
** R asign  ocfrom *, a CSVs to pr itratIf *, le0fth--ign  o
** isd
intracnive -ot i usea isotype s , iftratOceerwiat  gn  o
** isdmete s from * fnk(Lteddevicebl A e3omp  isd
ssuesi CSVhistGMy
** isdsaveoLtnl< 
  in  ocisd
intracnivebl And
intrrupt signalLwill
** cau3_ie isdr
  sn, to =0 ) itaodi
 nly,runl pr in  ocisd
intracniveb
**
** R    ret i numbercdfs, no sr

im};
  st    s to pr_athe C
    ShellS*p, */
  *in( i++onst chLine[h++]\n",
     e

A se sailgn  ocosn, 
ime 
nst char *zSes \n",
     e

Accumulallocn anbind ems. e = nLinel                e

Lengthcdfscurdifecosn, 
ime c = nree*zSes \n",
     lse

By sscdfshar [] used 
ime c = nie3_m*zSes \n",
     e

Ae3_mallochar [] sp c" 
ime c = nreePrior*zSes \n",
  e

By sscdfshar [] used by te3or*osn, 
ime 
nst chree(zEl            ]  err," m pragt      red 
ime c = rca                   ]  err," o_unc
ime c = , nCfe rMsg           ]  Numbercdfs, no s  eenc
ime c = osn,no rMsg           ]  Curdifecosn, numberc
ime c = };
rtline[h++]\n",
   e

Lsn, numbercated};
rtcdfscurdifecgn  oc
imels
    wh, nCfe", n2==!bail_ve_ rr," || (, le0f='elsdie_ s_
intracnive)rrMsg ){fflu_fin;
   N?\n");hLine[h+one_in  o_line(, ,;hLine, nree>b(p, 0);
   hLine", c==99 ){
 ]  ecoLtfcgn  oc
im9 ){
 );
   le0f='elsdie_ s_
intracnivef( te3_mpriut, "\n");
 =0 ) break;
    }
   1eenIintrrupt ==99 ){
     ie!=zh]==0 ) break;
 1eenIintrrupt   rc = 0;
     osn,noy){++; }     ar le0f='e_all_wh  ssp c"(hLine( ==99 ){
     ";
echoOnf( te3_mprisor: %s\Line({++; }
  theinue i+1);}i+1);
   hLine[='ezLineazAle[.c=='cnar le0f(=99 ){
     ";
echoOnf( te3_mprisor: %s\Line({++; }
      do_goto meta_co(hLine, prg[1]);
 
    i n2rg= ]  =0 ) requeeded 
ime n");
 =0 ) break;00
    ;
    if( rc ){
 ){, nCfey){++; }
 }++; }
  theinue i+1);}i+1);
   kine_is meta_comp_mmanalte(hLine( ='ckine_is metp** D(har , nree(f( rc ){
 
    mehLine,";",2 "\n");}=0 ){nLine[h+ n = strl\Line({++; }     ar +nLine+2>= ie3_m*)==0 ){
  ie3_m*zSnar +nLine+10ic = 0;
 zree*zSnote3_m(har , nie3_mrg[1]);
 
   har -1,z)==0 ){
        raw_printf(st derr,"Errr, "fut of memory\n");
   =0 ) 1tFile);
      }
    }nreePrior*zSnree{++; }     ar le0f==99 ){
      ;99 ){
  }
  for(zLineai] ='cIsSp c"(zLineaiArgnArg;  [1]);
  sout,   ie3_m>0f='ehar !=zh];rc ){
 
    mehdb,, hLine+ innLine+1-erg[1]);
 };
rtline[h+osn,nog[1]);
 nree*zSnLine- ;99 ){
    !=1 ){
 har [nree++e[h+[\n';rc ){
 
    mehdb,+ndb,, hLineinnLine+1)g[1]);
 nree*+zSnLine i+1);}i+1);
   nar *Stmkine_fthe = s_semi  -ve(&har [nreePrior], nree-nreePrior)]\n",
           Stmt && sqlmetp** D(free(rg==2 ){
    cn 0nE0;l9 ){
 
    open_db(p, 0);
     ";
 calslashOnf( resolve_ calslashes(>db,rg[1]);
 BEGIN_TIMER{++; }
      rint lite3_exec(p->db, zrint l     callbp&data, &zErrMsg);
 END_TIMER{++; }
 
    if||ezif( zErrMsg ){
   onst zPtefix[100]tFile; }
     ie!=zh2==!lsdie_ s_
intracnivef({]\n",
          sqlite3_snpr, p, sizPtefix), zPtefixr]\n",
                      derr,"Ernear*osn, %d:f("
;
rtlinery\n");
        }else{
          sqlite3_snpr, p, sizPtefix), zPtefixr derr,"Eory\n");
    [1]);
 
 
   hif( zE!1,z)==0 ){
          utf8_printf(st d%s ion: , zPtefixr ta, &zErrMsg);
   
      sqlite3_free(zErrMsg);
     zif( zEr  +] = 0;
        }else{
          utf8_printf(stde%s ion: , zPtefixr      sqlf(smsgclosg(pry\n");
    [1]);
 
 , nCfey){++; }
 }    ;
    if  untCe: .chf( rc ){
 ){     raw_pr";
      ge: .ch: %3d ){total_ge: .ch: %d [%s]\n",
           t && sqlme: .chclosg(pr      sqltotal_ge: .chclosg(pry\n");
 }[1]);
 nree*nE0;l9 ){
     ";
   Cumn_ ; i++){{{{{
    output_reset(p);;;;;";
   Cumn_ atic = 0;
      }
    {
    ar *Stm_all_wh  ssp c"(hree(rg==2 ){
     ";
echoOnf( te3_mprisor: %s\db,rg[1]);
 nree*nE0;l9 ){}me }
 {
   nree*; i++){
   !_all_wh  ssp c"(hree(rg==2 ){
  
= 1;
   t4intf(st derr,"Erinittp** Den aError: %s\db,rg[1]);
 , nCfey){++; }}me }
 {ite3_free(zSqlite3_fLine({++;     re, nCfe>0a }

/*
** R    rea pathzFilcwh chrisot i usea's hoilcdern Ef mbl A
** 0;     re ndemallsraRu rr," Nam oilck ndr

im};
  st
nst cited_hoil_der( 
*/clearFlagg==2 };
  st
nst choil_der*nEl NOa = 
   clearFlagrrMsg ){fte3_hoil_derrg[1]);hoil_der*nE0;l9 ){     reic = 
=0 
   hoil_der*(      rehoil_der;
[' ) ! Thinedv_WIN32)c n>! ThinedvWIN32)c n>! Thinedv_WIN32_WCE)c\[1]);
 n>! Thinedv__RTP__)c n>! Thinedv_WRS_KERNEL)]\n==0 ){ nst stp sow  *pwife;l9 ){uiomp{uio*nEg   id(){++; }    (pwife=g  pw id( id))r!lal NO;c!=1 ){
 hoil_der*nEpwife->pw_der;
+; }}me }
else
#en' )  Thinedv_WIN32_WCE)

 ]  Wtedows CE (arm-winie-te sw32ie-gcc) does : caproviuncg  env()]\n"
ime hoil_der*nE"/"brel
  }e' )  Thinedv_WIN32)c2== ThinedvWIN32)=0 
  (!hoil_derrc!=1 ){hoil_der*nEg  env("U  "PRO*/
 " "\n")}else
#endif
 (!hoil_derrc!=1 ){hoil_der*nEg  env("HOM " "\n")}e' )  Thinedv_WIN32)c2== ThinedvWIN32)=0 
  (!hoil_derrc!=1 ){onst charive, chPath{++; }  = n?\n");harive*nEg  env("HOM DRIVEory\n");hPath*nEg  env("HOM PATH"mt, 0 {
   harive*='ehPath*)==0 ){
  [h+ n = strl\arive) ++ n = strl\Path) ++1{++; }
 hoil_der*nEite3_ml}n (p, 0);
     hoil_derle0f(      reic = 0;
      sqlite3_snpr ,;hoil_der   sh%ssioharive, \Path){++; }
      rehoil_der;
0;
      }hoil_der*nE"c:\\""\n")}else
#enelse
# e

!_WIN32_WCE 
imelse

 hoil_der*({++; }  = n[h+ n = strlhoil_derrc++1{++; }onst ch*nEite3_ml}n (p, 0);
   h0)hd    meh,;hoil_der  nrg[1]);hoil_der*nEz"\n")}e
      rehoil_der;
}

/*
** R asign  ocfrom   i*fnk(rgiven by      src_ov_mriunratOr- (0ceao
** Rw smep_mrisol NO, tak ign  ocfrom ~/.     src
**
** R    rset i numbercdfs, no sr

im};
  ste,
  s to pr_     srcr]\n
    ShellS*p,                  ]  Configurt  ve_ ",  
ime 
ile(const c     src_ov_mriun \n]    /* Namconfig fnk(ral NO to u3_i
#iaul* 
im( i++onst choil_der*nEl NOa = 
ile(const c     src   rc = src_ov_mriun;i++onst c\Buf*nE0;l9 */
  *in*nEl NOa =0 
  (     src  lal NO;c!=1 ){hoil_der*nEited_hoil_der(b(p, 0);
   hoil_derle0f(==0 ){
      raw_printf(st d-- warne sError: caited hoilcdern Ef m;sster"
                 "rror: cae to ~/.     srcn|off\n");
      r;
0;
      }     sqliniti3_finary\n");hBuf*nEab = sqlite3_mprint/.     src",hoil_derrg[1]);     src   hBufc = 
=0 
n*nEfite3_     src,"rb"a        ien)==0 ){
   1 die_ s_
intracnivef({]\n",
      utf8_printf(std-- Loade s resourctscfrom ror: %     src "\n");}=0 ){s to pr_athe Cp,inrg[1]);fite3_(inrg[1]}=0      sqlite3_fBuf);g}

/*
** Show ales availitta_coLosn, 2 && os

im};
  st
ile(const zO && osQuer
  "  T-ascii               hea o    oc( p- to 'ascii'ut,
  "  T-bail                stop afp_mrh  Ef haaRu rr,"ut,
  "  T-batchrrrrrrrrrrrrrrrforct batchrI/Out,
  "  T-ite3_c              hea o    oc( p- to 'ite3_c'ut,
  "  T-cmdu" : AND         rue"op" : ANDT" befGMA e tof ha1 dieut,
  "  T-csv                 hea o    oc( p- to 'isv'ut,
  "  T-echo                te3_m itta_coumbefGMA ite3u&& o [%
  "  T-init */
  FILEn");
   ad/s to pr zFild fnk( [%
  "  T-[no]0], "h             reh], "helon ," Naon|oe' )  Thinedvhar *SQENABLL_MEMSYS3)c2== Thinedvhar *SQENABLL_MEMSYS5)
  "  T-h],p SIZE           Arra Namh],p f"rut osys3 "rut osys5n|oe'e);
#end"  T-h]lp                hhow e isdm pragt [%
  "  T-html                sea o    oc( p- to HTML [%
  "  T-inntracnivefrrrrrrrrforct inntracnivefI/Out,
  "  T-osn,                hea o    oc( p- to 'osn,'ut,
  "  T-ose(c               hea o    oc( p- to 'osst'ut,
  "  T-oookasiun SIZE N    u3_iNw--irisscdfsSZ by sscf"ruoookasiun t of memo
  "  T-ta_p N              
#iaul* ta_p , p,_r t co Nn|oe' )
#ifndef SQENABLL_MULTIPLEX
  "  T-tul*ip**x            navailt i mul*ip**x"ruVFSn|oe'e);
#end"  T-newosn, SEP         hea o    ocrow* eRw sepa. D#iaul*: '\\c'ut,
  "  T-bindsg()  TEXT      hea bind  the s f"rul NO sg() s. D#iaul* ''ut,
  "  T-pagtcult  SIZE N    u3_iNwslotscdfsSZ by ssceult f"rupagt cult  t of memo
  "  T-scrtion SIZE N      u3_iNwslotscdfsSZ by ssceult f"ruscrtion t of memo
  "  T-srow separSEP       hea o    ocite3_c  eRw sepa. D#iaul*: '|'ut,
  "  T- ;
 eiiiiiiiiiiiiiiite3_m t of m  ;
 eibefGMA iult fte3_finut,
  "  T-vere ve ){          hhow  -1, "wvere veut,
  "  T-vfs  FILEn");
      u3_iNFILEaset i 
#iaul* VFSn|oe' )
#ifndef SQENABLL_VFSEGICE
  "  T-vfsA* c"             navailt* cf ha
fVpac VFS_    sn|oe'e);
#e;m};
  ste,
  uragt( 
*/hhowDetail({]\n     utf8_printf(st]\n",
 err, "Us%s [OPTIONS] */
  FILE[nde]ut,
  ",
 e*/
  FILEisot i n /* Naman  -1, "w ", "dat. A new* ", "dataisdmnot cdut,
  ",
 e (0ceelfnk(rdoes : capreviouslyt xsed.r: %s0;gv0a        hhowDetailn)==0 ){ 
= 1;
   t4intf(st dOPTIONSriniludi:\n%ssiohO && os "\n")}
  ==0 ){     raw_printf(stderre0ceel-h]lp 2 && o f"ruaddi&& oal ll_drma&& o [%rg[1]}=0 =0 ) 1tFi}

/*
** Initi3_fin0) i* hellSll_drma&& o ien ", 

im};
  ste,
  b = linitC
    ShellS* ", ;c!=1 t oset( ", r", 0, p, si* ", ;rg[1] ", ->n p->nM p- =] ", ->cM p- =] ", ->m p- =]ode==ststg[1] ", ->_seoExplt,    rc = d    me ", ->c ->cCw sepa,SEP_Cte3_c, 2 "\n"d    me ", ->rp->cRw sepa,SEP_Rowan2rg[1] ", ->data.showH*nE0;l9  ", ->da   Flgs*nESHFLG_Lookasiun;=0      sqlconfigvhar *SQCONFIG_URIpSt, i+1     sqlconfigvhar *SQCONFIG_LOG zrint Log,  ", , i+1     sqlconfigvhar *SQCONFIG_MULTITHREAD, i+1     sqlite3_snpr, p, sib = P3omp ), b = P3omp ,"     s> ", i+1     sqlite3_snpr, p, si theinueP3omp ),  theinueP3omp ,"  T...> ", i}

/*
** O    oc ind      i*
ileoailgn * fo_m   at attracnscexA*  att--iionr

im' )
#if_WIN32m};
  ste,
  s _snBold(dile(const chTexArMsg HAND
     0nEGetStdH_cole(STD_OUTPUT_HAND
 , i+1CONSOLL_SCREEN_BUFFER_INFO 
#iaul*SmnoenIifog[1]GetCileoaiSmnoenBufferIifo(     &
#iaul*SmnoenIifo, i+1SetCileoaiTexAAttribute(    ster"
    FOREGROUND_RED|FOREGROUND_AVEENSITYste, i+1te3_mprintf("\TexAr i+1SetCileoaiTexAAttribute(     
#iaul*SmnoenIifo.wAttributes, i}
el
  }};
  ste,
  s _snBold(dile(const chTexArMsg te3_mpriu033[1mror033[0mf("\TexAr i)}else
#en/*
** G t c atargy arg    an --2 && oratorrow anu rr," _coLdi ;
  notargy arg
** isdales avair

im};
  st
nst ccmdkine_2 && o_sg() ( 
*/argc, 
    cca;gv, c = i( i++
   i==argcn)==0 ){ 
= 1;
   t4intf(st d%s: err,"Ermissf haargy arg    %s [%s]\n",
       a;gv=zArga;gv=argc-zArg[ 0 {=0 ) 1tFile}
 {     rea;gv=i] i}

' )n
#ifndef SQSHELL_IS_UTF8
#0 
  ( Thinedv_WIN32)c2== ThinedvWIN32))0]!= Thinedv_MSC_VER)
#0  = Thinefndef SQSHELL_IS_UTF8",
       (0)
#0 }
  }e0  = Thinefndef SQSHELL_IS_UTF8",
       (1)
#0 }se
#eelse
#en' ) ndef SQSHELL_IS_UTF8
c = har *SQCDECL b = ( 
*/argc, 
    cca;gv)==el
  }c = har *SQCDECL wb = ( 
*/argc, w
   _t ccwa;gv)==  
    cca;gv;e'e);
#end
nst chree(zE*nE0;l9 
    ShellS ", a = 
ile(const czInitzDestnE0;l9      ;99 c = rctnE0;l9     warnInt of mDbtnE0;l9       adS die   rc =   = nim* =C0;=  
    ccazim* =C0;=
  heaBte3ryM p-(1 die_db(p, 0heavbut4intf(st , 0_IONBF_db(pn]  Mak isuri* htf(sLisrunbuffered 
ime 1 die_ s_
intracnivef=Lisatty(b(p, 0ut = s_is meleoail=Lisatty(1tFin' ) USSQSYSTEM_har *S+0!=1       hif( st
    sqlsourctid(),ndef SQSOURCE_ID)!, n)==0 ){ 
= 1;
   t4intf(st dm-1, "w0], "h _coLsourctwvere vermismtion\n%s\n%s\nad]\n",
            sqlsourctid(), ndef SQSOURCE_ID)g[ 0 {=0 ) 1tFile}
'e);
#endb = linitC& ", , i' ) !ndef SQSHELL_IS_UTF8
 }     sqliniti3_finary\n"a;gv*nEab = sqlite3_mall, p, si ;gv=zA)ca;gca         ;gvle0f(==0 ){     raw_printf(stderr, "fut of memory\n");=0 ) 1tFile}
 { }
  for(i=a;gc<nArg; i++){a;gv=i]*nEab = sqlwin32_unio_un_to_ 
= (wa;gv=i](p, 0);
   a;gv=i]le0f(==0 ){
      raw_printf(st drr, "fut of memory\n");
 =0 ) 1tFile);}ile}
'e);
#end sout,  a;gc>=&& n>a;gv* n>a;gv=zAe, i+10;gv0 
 i;gv=zA;}else

Mak isuri*w"w0avefa valid;signalLh_coler iurly,rbefGMA anythf h
il
      {
srdonir
  
im' )
#ifnIGAVE
 } ignal(nIGAVE,d
intrrupt_h_coler); else
#en' )
#ifndef SQSHELL_DB FIL_PROC
\n==0 ){e

*
*t inn af SQSHELL_DB FIL_PROCdb cro{
srdThined,fth--igtEisot i n /*=0 ){
  Nama C-func&& o   at willaproviunct i n /* Namt i 
", "datafnk(ra Us*=0 ){
  e isdittpnk(-Aime 2 && o    embed i at a    aprogramlgn li;ger=0 ){
  applict  ves.V
ile */exA paoe,
  n af SQSHELL_DB FIL_PROCwDb, (const *tFile);n af SQSHELL_DB FIL_PROCw& ", .zDbink(zFiltFile);warnInt of mDbtnE0;l9 )}else
#endie

D  an initi3_tp so i rough   i*
ita_co-osn, argy arg    3_mall
){
  e i n /* Namt i 
", "datafnk(, e i n /* Namt i initi3_fit  ve_fnk(,
){
  e i srra Namc atalA paanivefite3_mmh],p,
){
  _coLp i fire(citta_coLpo ite3u&ir
  
im
  }
  for(i=a;gc<nArg; i++){onst czy\n");h 
 i;gv=i]p, 0);
   h=zA!e[-'f( rc ){
 
    ", .zDbink(zFil-1,z)==0 ){
    ", .zDbink(zFil*nEz"\n"le);}    }else{
   ]  exo prs;argy args;art inntrpreded ascn an(teddod- tta_cou) _coelse{
   
  seao   at nothf hEisoe to from 1 die 
ime n");
   adS die   +] = 0;
   nim*y){++; }
   alim* =Cnote3_m(azim*ll, p, si  im*[0])*nCm*     ); 0);
   a im*-1,z)==0 ){
          raw_printf(st drr, "fut of memory\n");
 );
 =0 ) 1tFile);le);}ile }
   alim*[nCm*-1e[h+z"\n"le);}
le);}
le);
   h=zAle[-'f( zy){++; }+;
 .
*( sth,"-scRw sepaaN-1,\n"le)2==.
*( sth,"-bindsg() aN-1,\n"le)2==.
*( sth,"-bewosn,aN-1,\n"le)2==.
*( sth,"-cmdaN-1,\n"le)==0 ){
 (e,
 )cmdkine_2 && o_sg() (argc, a;gv, ++erg[1]);
    ;
    if( sth,"-init"e", c==99 ){
 zInitzDestnEcmdkine_2 && o_sg() (argc, a;gv, ++erg[1]);
    ;
    if( sth,"-batch"e", c==99 ){
 ]   eeoLpo check f"rubatchrm p- hereotoLso*w"wcaRuae,
  s _snf h
il
   
  ll_drma&& o3_tm pragts (lik ifrom s to pr_     src)rbefGMA
il
   
  w(rdomc atactual s to prf ha
fVprgy args;lallrlgn * seDb,dtp so.
il
   
ime n");1 die_ s_
intracnivef=L0g[1]);
    ;
    if( sth,"-h],p"e", c==9' )  Thinedvhar *SQENABLL_MEMSYS3)c2== Thinedvhar *SQENABLL_MEMSYS5)
      
ile(const czArrac = 0;
      sql
in64 szH],pbrreak;
 zArratnEcmdkine_2 && o_sg() (argc, a;gv, ++erg[1]);  szH],pl=Liint)integerVzArra(p, 0);
     szH],p>0x7fff0000f( szH],pl=L0x7fff0000c = 0;
      sqlconfigvhar *SQCONFIG_HEAP,Eite3_mlrc =  zH],p)\ rc =  zH],p, 64)brel
  }0 ){
 (e,
 )cmdkine_2 && o_sg() (argc, a;gv, ++erg['e);
#end);
    ;
    if( sth,"-scrtion"e", c==99 ){
   = nll,zg[1]);  sz[h+rc = (int)integerVcmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);
     sz>400000f( sz[h+400000p, 0);
     sz<2500f( sz[h+2500p, 0);
 n[h+rc = (int)integerVcmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);
     n>10f( e   r0p, 0);
     n<Arg     rc = 1;
      sqlconfigvhar *SQCONFIG_SCRATCH,Eite3_mln*sz+1pr  z  nrg[1]);   ", .da   Flgs*|nESHFLG_Scrtiong[1]);
    ;
    if( sth,"-pagtcult "e", c==99 ){
   = nll,zg[1]);  sz[h+rc = (int)integerVcmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);
     sz>70000f( sz[h+70000p, 0);
     sz<0f( sz[h+0p, 0);
 n[h+rc = (int)integerVcmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);
      sqlconfigvhar *SQCONFIG_PAGECACHEr]\n",
               (n>0f='esz>0s ?gite3_mln*szrrg[sr  z  nrg[1]);   ", .da   Flgs*|nESHFLG_Pagtcult g[1]);
    ;
    if( sth,"-oookasiun"e", c==99 ){
   = nll,zg[1]);  sz[h+rc = (int)integerVcmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);
     sz<0f( sz[h+0p, 0);
 n[h+rc = (int)integerVcmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);
     n<0f( e   0c = 0;
      sqlconfigvhar *SQCONFIG_LOOKASIDEr  z  nrg[1]);      sz*nle0f(  ", .da   Flgs*&= ~SHFLG_Lookasiun;=' )
#ifndef SQENABLL_VFSEGICE
  );
    ;
    if( sth,"-vfsA* c""e", c==99 ){
 exA pao  = vfsA* c"_regite_mr]\n",
    dile(const chT* c"ar *r]\n",
    dile(const chOldVfsNFilr]\n",
      = (*xO  )wDb, (const ,e,
 *)r]\n",
    e,
  *pO  0;gr]\n",
      = mak D#iaul*]\n",
 rg[1]);  vfsA* c"_regite_mr[A* c"cl0,rc =(*)wDb, (const ,e,
 *))fputs,intf(st1rg['e);
#e' )
#ifndef SQENABLL_MULTIPLEX
  );
    ;
    if( sth,"-mul*ip**x"e", c==99 ){
 exA pao  = ab = sqliul*ip**liniti3_finaDb, (const ,int(p, 0);
      sqlmul*ip**xliniti3_fina0pSt, i'e);
#end);
    ;
    if( sth,"-ta_p"e", c==99 ){
      sql
in64 szl=Liint)integerVcmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);
      sqlconfigvhar *SQCONFIG_MMAP_SIZEr  z  szrg[1]);
    ;
    if( sth,"-vfs"e", c==99 ){
      sqlvfs *pVfs*nEab = sqlvfslited(cmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);
     -Vfsf( rc ){
 ){ab = sqlvfslregite_mr-VfspSt, i+1);
 }    }else{
    
= 1;
   t4intf(st dnoLsuchrVFS: open \"%s\"a;gv=i](p, 0);){
 ex ) 1tFile);
      }
   
=0 
    ", .zDbink(zFil-1,z)==' )n
#ifndef SQLITE_MEMORYDB    } ", .zDbink(zFil*nE":t of m:"File);warnInt of mDbtnEargc=forrel
  }0 ){     utf8_printf(std%s: err,"ErnoL
", "datafnk(zFil*specified [%ss0;gv0a    0      re1a me);
#end 
 } ", .   0nEut = s;}else

Go a0],  _coLnnot t i 
", "datafnk(;
  ittal  adyt xsedsratIf t i
){
  fnk(rdoes : ca xsed  
#li< Nnote s , ratorisoprevargs;empty 
", "dat
){
  fnk(scfrom bee s mnot cd- (0a usea msedypes t i 
", "datazFil*argy arg
){
  eomc atab = s*
ita_co-osn, toolr
  
im
 
   aco pr( ", .zDbink(zFil_db(", n)==0 ){
    ope& ", r", "\n")}eile

MOto pr t i initi3_fit  ve_fnk(- (0ceer {
sroniratIf noL-init 2 && o
){
  
srgiven on   i*
ita_coLosn,,uoook f"rua_fnk(-zFild ~/.     src _coels
  ery eoms to pr itr
  
im
 s to pr_     srcr& ", rzInitzDes);}else

Mak i* seDb,dtp so i rough   i*
ita_co-osn, argy arg _coLseg
){
  2 && osratorisoseDb,dtp so 
srdTli<ld usnfl afp_mrt i initi3_fit  ve
){
  fnk(risoprto prloc o   at   i*
ita_co-osn, argy args willaov_mriun
){
  segte ssbytet i initi3_fit  ve_fnk(r
  
im
  }
  for(i=a;gc<nArg; i++){onst cz 
 i;gv=i]p, 0);
   h=zA!e[-'f(  theinue i+1);
   zazAle[-'f(  z+g;;     }
    if( sth,"-init"e", c==99 ){
 iy){++; }}    ;
    if( sth,"-html"e", c==99 ){
  ", .m p- =]ode==Htmlg[1]);
    ;
    if( sth,"-opstse", c==99 ){
  ", .m p- =]ode==ststg[1]);
    ;
    if( sth,"-opn""e", c==99 ){
  ", .m p- =]ode==stn g[1]);
    ;
    if( sth,"-ite3_c"e", c==99 ){
  ", .m p- =]ode==Cte3_cg[1]);
    ;
    if( sth,"-isv"e", c==99 ){
  ", .m p- =]ode==CsvFile);
 d    me ", .c ->cCw sepa,",",2 "\n");}    ;
    if( sth,"-ascii"e", c==99 ){
  ", .m p- =]ode==Asciip, 0);
      sqlite3_snpr, p, si ", .c ->cCw sepa),  ", .c ->cCw sepa,]\n",
                  SEP_Unit(p, 0);
      sqlite3_snpr, p, si ", .rp->cRw sepa),  ", .rp->cRw sepa,]\n",
                  SEP_ReDbrd "\n");}    ;
    if( sth,"-scRw sepaaN-1,rg==2 ){
      sqlite3_snpr, p, si ", .c ->cCw sepa),  ", .c ->cCw sepa,]\n",
                  intf(cmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);}    ;
    if( sth,"-bewosn,aN-1,rg==2 ){
      sqlite3_snpr, p, si ", .rp->cRw sepa),  ", .rp->cRw sepa,]\n",
                  intf(cmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);}    ;
    if( sth,"-bindsg() aN-1,rg==2 ){
      sqlite3_snpr, p, si ", .bindteger),  ", .bindteger,]\n",
                  intf(cmdkine_2 && o_sg() (argc,a;gv,++er(p, 0);}    ;
    if( sth,"-0], "h"e", c==99 ){
  ", .data.showH*nE1p, 0);}    ;
    if( sth,"-bo0], "h"e", c==99 ){
  ", .data.showH*nE0g[1]);
    ;
    if( sth,"-echo"e", c==99 ){
  ", .echoOnfnE1p, 0);}    ;
    if( sth,"-eqp"e", c==99 ){
  ", ._seoEQPfnE1p, 0);}    ;
    if( sth,"-eqpfind"e", c==99 ){
  ", ._seoEQPfnE2"\n");}    ;
    if( sth,"-s;
 e"e", c==99 ){
  ", .d;
 eOnfnE1p, 0);}    ;
    if( sth,"-scans;
 e"e", c==99 ){
  ", .dcans;
 eOnfnE1p, 0);}    ;
    if( sth,"- calslash"e", c==99 ){
 ]  Undocu arged*
ita_co-osn, nown opt- calslash99 ){
 
  Cau3_sdC- tyk(r calslash edcapes to be esg()t cd- nen an t
 nforcs99 ){
 
  te3or*    ende s*t inn aLiino  -1, "ra Us*fin f"ruinjn Ef h99 ){
 
  crazy by ssc not i middl* Namn an t
 nforcscatedceedf haaRdrdTbuggf h.
il
   
ime n"); ", . calslashOnfnE1p, 0);}    ;
    if( sth,"- cid"e", c==99 ){
 bail_ve_ rr," nE1p, 0);}    ;
    if( sth,"-vere ve"e", c==99 ){
 te3_mprintrror: %src = sqllibvere ve()("
    sqlsourctid() "\n"""""     reic = 0;
    ;
    if( sth,"-inntracniveaN-1,rg==2 ){
   die_ s_
intracnivef=L1p, 0);}    ;
    if( sth,"- cion"e", c==99 ){
 1 die_ s_
intracnivef=L0g[1]);
    ;
    if( sth,"-h],p"e", c==99 ){
 iy){++; }}    ;
    if( sth,"-scrtion"e", c==99 ){
  +=2"\n");}    ;
    if( sth,"-pagtcult "e", c==99 ){
  +=2"\n");}    ;
    if( sth,"-oookasiun"e", c==99 ){
  +=2"\n");}    ;
    if( sth,"-ta_p"e", c==99 ){
 iy){++; }}    ;
    if( sth,"-vfs"e", c==99 ){
 iy){+' )
#ifndef SQENABLL_VFSEGICE
  );
    ;
    if( sth,"-vfsA* c""e", c==99 ){
 iy){+'e);
#e' )
#ifndef SQENABLL_MULTIPLEX
  );
    ;
    if( sth,"-mul*ip**x"e", c==99 ){
 iy){+'e);
#e1]);
    ;
    if( sth,"-h]lp"e", c==99 ){
 uragt(1(p, 0);}    ;
    if( sth,"-cmdaN-1,c==99 ){
 ]  Run itta_coum  at foacow -cmdufire(c_coLseRw senl< from itta_cou99 ){
 
    at simply appear*on   i*
ita_co-osn,ratorisoseemsrgoofmbl It would99 ){
 
  be begter- (0pac itta_coumran inml t 2rd"n   at   iy appearbl But99 ){
 
  wt    ainml t goofm behav3or*ated&istGMical ittpt  bi   y.c
im9 ){
 );
  ==argc-1h]==0 ) break;
 ztnEcmdkine_2 && o_sg() (argc,a;gv,++erp, 0);
     zazAle[.c=( rc ){
 ){     do_goto meta_co(h  &
", , i+1 0);
        && bail_ve_ rr," )      rerc n2rg>0 :crca =  0);}     rc ){
 ){
    ope& ", r", "\n"){
 ){     rint lite3_ ", .c(p-> zrint l     callb& ", r"ata, &zErrMsg);
 
 
   hif( zE!1,z)==0 ){
          utf8_printf(stderr,"Error: %s\ree(zErrMsg);
     
   bail_ve_ rr," )      rerc!1,z?{   : rc = 1;
 = 
    ;
    i!1,z)==0 ){
          utf8_printf(stderr,"Erunavailtoms to pr n anopen \"%s\"zrrMsg);
     
   bail_ve_ rr," )      rercc = 1;
 = 
ile);
      }
     rc ){
      utf8_printf(std%s: err,"Errr, "unknown option: %s0;gv0\"zrrMsg);
      raw_printf(stdrrel-h]lp f"rua_ose(cNam2 && osrn|off\n");
      r rc = 1;
   ); ", .cM p- =] ", .m p-"\n")}eil
   !  adS die )==0 ){]  Run pac argy args   at do : cabegi3 with [-'fasrif   iy wer {seRw sen
){
 
  
ita_co-osn, athe s, excepacatedc atargToSkip argy arg wh chrfthe = s
){
 
  t i 
", "datafnk(zFil.
il
 
im9 ){ }
  for(i=nCm*<nArg; i++){
 );
 alim*[i]azAle[.c=( rc ){
 ){     do_goto meta_co(alim*[i]  &
", , i+1 0);
        )      rerc n2rg>0 :crca =  0);}     rc ){
 ){
    ope& ", r", "\n"){
 ){     rint lite3_ ", .c(p-alim*[i]  rint l     callb& ", r"ata, &zErrMsg);
 
 
   hif( zE!1,z)==0 ){
          utf8_printf(stderr,"Error: %s\ree(zErrMsg);
          rerc!1,z?{   : rc = 1;
 = 
    ;
    i!1,z)==0 ){
          utf8_printf(stderr,"Erunavailtoms to pr n aption: %sicim*[i]rrMsg);
          rercc = 1;
 = 
ile);
      }
m9 ){ te3_icim* "\n")}
  ==0 ){]  Run itta_coumrectiveoLfrom 1 _coarsign  o
il
 
im9 ){
   1 die_ s_
intracnivef({]\n",
 onst czHomac = 0;
 onst czHistGMy*nE0;l9 ){
   = nHistGMy;l9 ){
 utf8_pr = 1;
 = dm-1, "wvere verntrr.19on:  e
exA* -vere ve-ll_d*/ = 1;
 = dEintr op.& st \cateduragtd&irgs.\nad]\n",
   rc = sqllibvere ve()("
    sqlsourctid()]\n",
 rp, 0);
     warnInt of mDbt)==0 ){
   te3_mpriConnn EeoLpo a ory\n");
 );s _snBold([A* nsiifecgn-t of m 
", "datory\n");
 );s _snpri.\nrrelop.nnot */
  FIL \cpo rennot on * sster"
          "pere st--iw ", "dat.ut, "\n");
      }
 zHoma*nEited_hoil_der(b(p, 0);
 
   hHoma*)==0 ){
   nHistGMy*nE n = strl\Homarc++20rMsg);
 
 
   (zHistGMy*nEite3_mlnHistGMy))!1,z)==0 ){
          sqlite3_snpr HistGMy%s\HistGMy%int/.     s_histGMy %s\Homarc = 1;
 = 
ile);
      }
 
   hHistGMy*){ rint l  ad_histGMy(zHistGMy);;     }
      s to pr_athe C& ", r", "\n"){
 
   hHistGMy*){]\n",
   rint ledffls_histGMy(10, "\n"){
 ){rint lwr  s_histGMy(zHistGMy);\n"){
 ){ite3_fHistGMy);\n"){
  , 000
    !=1 ){
      s to pr_athe C& ", r"1 dietFile);}ile}
 0hea_tavai_zFilC& ", r", "\n"
    ", .c(z)==0 ){s prfve_ite3__all(&
", , i+1 0     sqlcte3_( ", .c(rg[1]}=0      sqlite3_ ", .zFte3OnCte3_(zSqlited_hoil_der(1, i' ) !ndef SQSHELL_IS_UTF8
 } }
  for(i=a;gc<nArg;      sqlite3_a;gv=i](p, 0     sqlite3_a;gv, i'e);
#end     rerca }
     